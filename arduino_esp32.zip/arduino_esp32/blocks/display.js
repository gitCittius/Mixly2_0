'use strict';

goog.provide('Blockly.Blocks.display');

goog.require('Blockly.Blocks');
var MATRIX_TYPES =[['MAX7219', 'MAX7219']];
