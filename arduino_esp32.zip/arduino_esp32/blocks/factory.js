'use strict';

goog.provide('Blockly.Blocks.factory');
goog.require('Blockly.Blocks');
Blockly.Blocks.factory.HUE = 65;
