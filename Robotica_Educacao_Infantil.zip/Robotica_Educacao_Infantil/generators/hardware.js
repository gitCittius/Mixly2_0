'use strict';

goog.provide('Blockly.Python.hardware');

goog.require('Blockly.Python');

Blockly.Python.hardware_arduino_start=function(){
  Blockly.Python.definitions_['import_s4alib'] = 'import s4alib';
  var v = Blockly.Python.valueToCode(this, 'SUB', Blockly.Python.ORDER_ATOMIC);
  // var code= v + '.start()\n';  
  var code = v + ' = s4alib.s4a_start("'+JSFuncs.getCom()+'")\n'; 
  return code;
};

Blockly.Python.inout_highlow = function () {
    // Boolean values HIGH and LOW.
    var code = (this.getFieldValue('BOOL') == 'HIGH') ? '1' : '0';
    return [code, Blockly.Python.ORDER_ATOMIC];
};

Blockly.Python.hardware_arduino_digital_write = function () {
    Blockly.Python.definitions_['import_s4alib'] = 'import s4alib';
    var v = Blockly.Python.valueToCode(this, 'SUB', Blockly.Python.ORDER_ATOMIC);
    var dropdown_pin = Blockly.Python.valueToCode(this, 'PIN', Blockly.Python.ORDER_ATOMIC);
    var dropdown_stat = Blockly.Python.valueToCode(this, 'STAT', Blockly.Python.ORDER_ATOMIC);
    var code = "";
    code += ''+v+'.digital_write('+dropdown_pin+','+ dropdown_stat +')\n'
    return code;
};

Blockly.Python.hardware_arduino_digital_read = function () {
    Blockly.Python.definitions_['import_s4alib'] = 'import s4alib';
    var v = Blockly.Python.valueToCode(this, 'SUB', Blockly.Python.ORDER_ATOMIC);
    var dropdown_pin = Blockly.Python.valueToCode(this, 'PIN', Blockly.Python.ORDER_ATOMIC);
    var code = "";
    code =''+v+'.digital_read('+dropdown_pin+')';
    return [code, Blockly.Python.ORDER_ATOMIC];
};

Blockly.Python.hardware_arduino_analog_read = function () {
    Blockly.Python.definitions_['import_s4alib'] = 'import s4alib';
    var v = Blockly.Python.valueToCode(this, 'SUB', Blockly.Python.ORDER_ATOMIC);
    var dropdown_pin = Blockly.Python.valueToCode(this, 'PIN', Blockly.Python.ORDER_ATOMIC);
    var code = "";
    code =''+v+'.analog_read('+dropdown_pin+')';
    return [code, Blockly.Python.ORDER_ATOMIC];
};

Blockly.Python.hardware_arduino_analog_write = function () {
    Blockly.Python.definitions_['import_s4alib'] = 'import s4alib';
    var v = Blockly.Python.valueToCode(this, 'SUB', Blockly.Python.ORDER_ATOMIC);
    var dropdown_pin = Blockly.Python.valueToCode(this, 'PIN', Blockly.Python.ORDER_ATOMIC);
    var value_num = Blockly.Python.valueToCode(this, 'NUM', Blockly.Python.ORDER_ATOMIC);
    var code = "";
    code += ''+v+'.analog_write('+dropdown_pin+','+ value_num +')\n'
    return code;
};

Blockly.Python.StartRobot_ = function () {
    Blockly.Python.definitions_['import_s4alib'] = 'import serial.tools.list_ports';

    var code = "def list_serial_ports(x):\n"+
    "    ports = list(serial.tools.list_ports.comports())\n"+
    "    for port in ports:\n"+
    "        try:\n"+
    "            if(x==0):\n"+
    "              return(port.device)\n"+
    "            elif(x==1):\n"+
    "                return(port.vid)\n"+
    "            elif(x==2):\n"+
    "                return(port.manufacturer)\n"+
    "            elif(x==3):\n"+
    "                return(port.pid)\n"+
    "            elif(x==4):\n"+
    "                return(port.serial_number)\n"+
    "            elif(x==5):\n"+
    "                return(port.location)\n"+
    "            elif(x==6):\n"+
    "                return(port.product)\n"+
    "            elif(x==7):\n"+
    "                return(port.interface)\n"+
    "            elif(x==8):\n"+
    "                return(port.description)\n"+

    "        except AttributeError:\n"+
    '            print("Intalar a versão 3.4 do pySerial")\n'+
    '            sys.exit(0)\n\n'+
    'print("------- DADOS DA PORTA SERIAL --------")\n'+
    'print("Fabricante: " +list_serial_ports(2))\n'+
    'print("Conectada na porta: " + list_serial_ports(0))\n'+
    'print("USB Vendor ID: " + str(list_serial_ports(1)))\n'+
    'print("USB product ID: " + str(list_serial_ports(3)))\n'+
    'print("USB serial number: " + str(list_serial_ports(4)))\n'+
    'print("USB device location: " + str(list_serial_ports(5)))\n'+
    'print("USB product: " + str(list_serial_ports(6)))\n'+
    'print("Interface specific description: " + str(list_serial_ports(7)))\n'+
    'print("description: " + str(list_serial_ports(8)))\n'+
    'print("------- FIM DOS DADOS DA PORTA SERIAL --------")\n\n\n';
    return code;
};
