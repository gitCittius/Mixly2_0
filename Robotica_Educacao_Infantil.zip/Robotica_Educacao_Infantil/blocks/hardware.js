'use strict';

goog.provide('Blockly.Blocks.hardware');

goog.require('Blockly.Blocks');

Blockly.Blocks.hardware.HUE = 40

Blockly.Blocks.hardware_arduino_start = {
    init: function () {
        this.setColour(Blockly.Blocks.hardware.HUE);
        this.appendDummyInput("")
            .appendField(Blockly.MIXLY_HARDWARE)
        this.appendValueInput('SUB')
            .setCheck("var");
        this.appendDummyInput()
            .appendField(Blockly.MIXLY_HARDWARE_START)
        this.setInputsInline(true);
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
    }
};

Blockly.Blocks['inout_highlow'] = {
   init: function() {
    this.setColour(Blockly.Blocks.hardware.HUE);
    this.appendDummyInput("")
        .appendField(new Blockly.FieldDropdown([[Blockly.MIXLY_HIGH, "HIGH"], [Blockly.MIXLY_LOW, "LOW"]]), 'BOOL')
    this.setOutput(true, Boolean);
    this.setTooltip(Blockly.MIXLY_TOOLTIP_INOUT_HIGHLOW);
  }
};

Blockly.Blocks.hardware_arduino_digital_write = {
  init: function() {
    this.setColour(Blockly.Blocks.hardware.HUE);
    this.appendValueInput('SUB')
        .appendField(Blockly.MIXLY_HARDWARE)
        .setCheck("var");
    this.appendValueInput("PIN",Number)
        .appendField(Blockly.MIXLY_Digital_PINMODEOUT)
        .appendField(Blockly.MIXLY_PIN)
        .setCheck(Number);
    this.appendValueInput("STAT")
        .appendField(Blockly.MIXLY_STAT)
        .setCheck([Number,Boolean]);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setInputsInline(true);
    this.setTooltip(Blockly.LANG_INOUT_DIGITAL_WRITE_TOOLTIP);
  }
};

Blockly.Blocks.hardware_arduino_digital_read = {
  init: function() {
    this.setColour(Blockly.Blocks.hardware.HUE);
    this.appendValueInput('SUB')
        .appendField(Blockly.MIXLY_HARDWARE)
        .setCheck("var");
    this.appendValueInput("PIN", Number)
        .appendField(Blockly.MIXLY_Digital_PINMODEIN)
        .appendField(Blockly.MIXLY_PIN)
        .setCheck(Number);
    this.appendDummyInput()
        .appendField(Blockly.MIXLY_ESP32_MACHINE_VALUE)
    this.setInputsInline(true);
    this.setOutput(true, [Boolean,Number]);
    this.setTooltip(Blockly.MIXLY_TOOLTIP_INOUT_DIGITAL_READ);
  }
};

Blockly.Blocks.hardware_arduino_analog_write = {
  init: function() {
    this.setColour(Blockly.Blocks.hardware.HUE);
    this.appendValueInput('SUB')
        .appendField(Blockly.MIXLY_HARDWARE)
        .setCheck("var");
    this.appendValueInput("PIN",Number)
        .appendField(Blockly.MIXLY_Analog_PINMODEOUT)
        .appendField(Blockly.MIXLY_PIN)
        .setCheck(Number);
    this.appendValueInput("NUM", Number)
        .appendField(Blockly.MIXLY_VALUE2)
        .setCheck(Number);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setInputsInline(true);
    this.setTooltip(Blockly.MIXLY_TOOLTIP_INOUT_ANALOG_WRITE);
  }
};

Blockly.Blocks.hardware_arduino_analog_read = {
  init: function() {
    this.setColour(Blockly.Blocks.hardware.HUE);
    this.appendValueInput('SUB')
        .appendField(Blockly.MIXLY_HARDWARE)
        .setCheck("var");
    this.appendValueInput("PIN", Number)
        .appendField(Blockly.MIXLY_Analog_PINMODEIN)
        .appendField(Blockly.MIXLY_PIN)
        .setCheck(Number);
    this.appendDummyInput()
        .appendField(Blockly.MIXLY_ESP32_MACHINE_VALUE)
    this.setInputsInline(true);
    this.setOutput(true, [Boolean,Number]);
    this.setTooltip(Blockly.MIXLY_TOOLTIP_INOUT_ANALOG_READ);
  }
};


Blockly.Blocks.StartRobot = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 41.svg", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");
  this.setNextStatement(true, null);
  this.setColour("#ec782d");
this.setTooltip("");
this.setHelpUrl("");
}
};

Blockly.Blocks.MoveForward = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 4.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#82c17a");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.MoveRight = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 3.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#33b6d7");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.MoveLeft = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 2.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#f6d742");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.MoveBack = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 5.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#cd3135");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Mult2x = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 6.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#8fcdbf");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Mult3x = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 7.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#35b38d");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Mult4x = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 8.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#46ae4c");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Mult5x = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 9.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#097335");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Timer1s = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 10.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#f2a84c");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Timer3s = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 12.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#4b66ae");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Timer5s = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 12_1.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#ffcc00");
   this.setTooltip("");
   this.setHelpUrl("");
}
};


Blockly.Blocks.StartRobot_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 41.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");
  this.setNextStatement(true, null);
  this.setColour("#F5B041");
this.setTooltip("");
this.setHelpUrl("");
}
};

Blockly.Blocks.EndRobot_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/fim.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");
      this.setPreviousStatement(true, null);
  this.setNextStatement(false, null);
  this.setColour("#F5B041");
this.setTooltip("");
this.setHelpUrl("");
}
};

Blockly.Blocks.MoveForward_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 4.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#808080");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.MoveRight_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 3.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#808080");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.MoveLeft_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 2.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#808080");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.MoveBack_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 5.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#808080");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Move180_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Girar pra tras.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#808080");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Mult2x_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 6.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(230);
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Mult3x_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 7.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(230);
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Mult4x_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 8.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(230);
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Mult5x_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 9.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(230);
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Timer1s_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 10.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#ffcc00");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Timer3s_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 12.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#ffcc00");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Timer5s_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 12_1.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#ffcc00");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Som1_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 13.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#D65CD6");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Som1_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 13.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#D65CD6");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Som1_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 13.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#D65CD6");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Som2_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 14.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#D65CD6");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Som3_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 15.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#D65CD6");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Som4_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 16.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#D65CD6");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Som5_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 39.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#D65CD6");
   this.setTooltip("");
   this.setHelpUrl("");
}
};

Blockly.Blocks.Som6_ = {
  init: function() {
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/Robotica_Educacao_Infantil/common/media/cards/Prancheta 40.png", 200, 100, { alt: "*", flipRtl: "FALSE" }))
      .appendField(" ");

      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#D65CD6");
   this.setTooltip("");
   this.setHelpUrl("");
}
};