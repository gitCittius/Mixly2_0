var conf = conf || {};
conf.lastEditorTheme = 'ace/theme/xcode';