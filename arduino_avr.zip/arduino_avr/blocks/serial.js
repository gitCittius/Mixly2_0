'use strict';

goog.provide('Blockly.Blocks.serial');

goog.require('Blockly.Blocks');
Blockly.Blocks.serial.HUE = "#7ED321";
Blockly.Blocks['serial_begin'] = {
  init: function() {
    this.setColour(Blockly.Blocks.serial.HUE);
    this.appendValueInput("CONTENT", Number)
    .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
    .appendField(Blockly.MIXLY_SERIAL_BEGIN)
    .setCheck(Number);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setInputsInline(true);
    this.setTooltip(Blockly.MIXLY_TOOLTIP_SERIAL_BEGIN);
    
  }
};

Blockly.Blocks['serial_write'] = {
  init: function () {
    this.setColour(Blockly.Blocks.serial.HUE);
    this.appendValueInput("CONTENT", String)
    .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
    .appendField(Blockly.MIXLY_SERIAL_WRITE);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip(Blockly.Msg.TEXT_WRITE_TOOLTIP);
  }
};

Blockly.Blocks['serial_print'] = {
  init: function() {
   this.setColour(Blockly.Blocks.serial.HUE);
   this.appendValueInput("CONTENT", String)
   .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")

   .appendField(Blockly.MIXLY_SERIAL_PRINT);
   this.appendDummyInput()
   .appendField(new Blockly.FieldDropdown([[Blockly.MIXLY_PRINT_INLINE, "print"],[Blockly.Msg.TEXT_PRINT_Huanhang_TOOLTIP, "println"]]), "new_line");
    
   this.setPreviousStatement(true, null);
   this.setNextStatement(true, null);
   this.setTooltip(Blockly.Msg.TEXT_PRINT_TOOLTIP);
 }
};

Blockly.Blocks['serial_println'] =  {
  init: function() {
   this.setColour(Blockly.Blocks.serial.HUE);
   this.appendValueInput("CONTENT", String)
   .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
   .appendField(Blockly.MIXLY_SERIAL_PRINT)
    .appendField(new Blockly.FieldDropdown([[Blockly.Msg.TEXT_PRINT_Huanhang_TOOLTIP, "println"],[Blockly.MIXLY_PRINT_INLINE, "print"]]), "new_line");
   this.setPreviousStatement(true, null);
   this.setNextStatement(true, null);
   this.setTooltip(Blockly.Msg.TEXT_PRINT_TOOLTIP);
 }
};


Blockly.Blocks['serial_print_num'] = {
 init: function() {
  this.setColour(Blockly.Blocks.serial.HUE);
  this.appendDummyInput()
  .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
  .appendField(Blockly.MIXLY_SERIAL_PRINT)
  .appendField(new Blockly.FieldDropdown([[Blockly.MIXLY_PRINT_INLINE, "print"],[Blockly.Msg.TEXT_PRINT_Huanhang_TOOLTIP, "println"]]), "new_line")
  .appendField(Blockly.MIXLY_NUMBER);
  this.appendValueInput("CONTENT", Number)
  .appendField(new Blockly.FieldDropdown([[Blockly.Msg.MATH_HEX, "HEX"],[Blockly.Msg.MATH_BIN, "BIN"],[Blockly.Msg.MATH_OCT, "OCT"],[Blockly.Msg.MATH_DEC, "DEC"]]), "STAT")
  .setCheck(Number);
  this.setPreviousStatement(true, null);
  this.setNextStatement(true, null);
  this.setInputsInline(true);
  this.setTooltip(Blockly.Msg.TEXT_PRINT_HEX_TOOLTIP);
}
};

Blockly.Blocks['serial_print_hex']=Blockly.Blocks['serial_print_num'];

Blockly.Blocks['serial_available'] = {
  init: function() {
    this.setColour(Blockly.Blocks.serial.HUE);
    this.appendDummyInput()
    .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
    .appendField(Blockly.MIXLY_SERIAL_AVAILABLE);
    this.setOutput(true, Boolean);
    this.setTooltip(Blockly.MIXLY_TOOLTIP_BLOCKGROUP_SERIAL_AVAILABLE);
  }
};

Blockly.Blocks['serial_readstr'] = {
  init: function() {
    this.setColour(Blockly.Blocks.serial.HUE);
    this.appendDummyInput()
    .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
    .appendField(Blockly.MIXLY_SERIAL_READSTR);
    this.setOutput(true, String);
    this.setTooltip(Blockly.MIXLY_TOOLTIP_BLOCKGROUP_SERIAL_READ_STR);
  }
};

Blockly.Blocks['serial_readstr_until'] = {
  init: function() {
    this.setColour(Blockly.Blocks.serial.HUE);
    this.appendValueInput("CONTENT", Number)
    .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
    .appendField(Blockly.MIXLY_SERIAL_READSTR_UNTIL)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setOutput(true, String);
    this.setTooltip(Blockly.MIXLY_TOOLTIP_SERIAL_READSTRUNITL.replace('%1',Blockly.Arduino.valueToCode(this, 'CONTENT',Blockly.Arduino.ORDER_ATOMIC)));
  }
};

Blockly.Blocks['serial_parseInt_Float'] = {
  init: function() {
    this.setColour(Blockly.Blocks.serial.HUE);
    this.appendDummyInput()
    .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
        //.appendField(Blockly.MIXLY_SERIAL_READ)
        .appendField(new Blockly.FieldDropdown([["read", "read"],["peek", "peek"],["parseInt", "parseInt"], ["parseFloat", "parseFloat"]]), "STAT");
        this.setOutput(true, Number);
        var thisBlock = this;
        this.setTooltip(function() {
          var op = thisBlock.getFieldValue('STAT');
          var TOOLTIPS = {
            'parseInt': Blockly.MIXLY_TOOLTIP_BLOCKGROUP_SERIAL_READ_INT,
            'parseFloat': Blockly.MIXLY_TOOLTIP_BLOCKGROUP_SERIAL_READ_FLOAT
          };
          return TOOLTIPS[op];
        });
      }
    };

    Blockly.Blocks['serial_flush'] = {
      init: function() {
       this.setColour(Blockly.Blocks.serial.HUE);
       this.appendDummyInput()
       .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
       .appendField(Blockly.MIXLY_SERIAL_FLUSH);
       this.setPreviousStatement(true, null);
       this.setNextStatement(true, null);
       this.setTooltip(Blockly.MIXLY_TOOLTIP_SERIAL_FLUSH);
     }
   };
   Blockly.Blocks['serial_softserial'] = {
    init: function() {
      this.setColour(Blockly.Blocks.serial.HUE);
      this.appendDummyInput("")
      .appendField(Blockly.MIXLY_SETUP)
      .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select");
      this.appendValueInput("RX", Number)
      .setCheck(Number)
      .appendField("RX#")
      .setAlign(Blockly.ALIGN_RIGHT);
      this.appendValueInput("TX", Number)
      .appendField("TX#")
      .setCheck(Number)
      .setAlign(Blockly.ALIGN_RIGHT);
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setInputsInline(true);
      this.setTooltip(Blockly.MIXLY_TOOLTIP_SOFTSERIAL.replace('%1',Blockly.Arduino.valueToCode(this, 'RX',Blockly.Arduino.ORDER_ATOMIC))
        .replace('%2',Blockly.Arduino.valueToCode(this, 'TX',Blockly.Arduino.ORDER_ATOMIC)));
    }
  };

  Blockly.Blocks['serial_event'] = {
    init: function () {
      this.setColour(Blockly.Blocks.serial.HUE);
      this.appendDummyInput()
      .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
      .appendField(Blockly.MIXLY_SERIAL_EVENT);
      this.appendStatementInput('DO')
      .appendField(Blockly.MIXLY_DO);
      this.setPreviousStatement(true);
      this.setNextStatement(true);
      this.setTooltip(Blockly.MIXLY_TOOLTIP_SERIALEVENT);
    }
  };

  /********/

Blockly.Blocks['controls_if_cmd'] = {
  /**
   * Block for if/elseif/else condition.
   * @this Blockly.Block
   */
   init: function() {
    //this.setHelpUrl(Blockly.Msg.CONTROLS_IF_HELPURL);
    this.setColour("#7ED321");
    this.appendDummyInput()
    .appendField("Streamer de Dados:");
   // this.appendStatementInput('DO0')
   // .appendField("Canal 1 Enviar:");
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setHelpUrl("https://mixly.readthedocs.io/zh_CN/latest/arduino/03.Control.html#if");
    this.wiki = {
      'zh-hans': {
        page: ['Arduino AVR', '控制', 'if 选择']
      }
    };
    this.setMutator(new Blockly.Mutator(['controls_if_elseif_cmd',
     'controls_if_else_cmd']));
    // Assign 'this' to a variable for use in the tooltip closure below.
    var thisBlock = this;
    this.setTooltip(function() {
      if (!thisBlock.elseifCount_ && !thisBlock.elseCount_) {
        return Blockly.Msg.CONTROLS_IF_TOOLTIP_1;
      } else if (!thisBlock.elseifCount_ && thisBlock.elseCount_) {
        return Blockly.Msg.CONTROLS_IF_TOOLTIP_2;
      } else if (thisBlock.elseifCount_ && !thisBlock.elseCount_) {
        return Blockly.Msg.CONTROLS_IF_TOOLTIP_3;
      } else if (thisBlock.elseifCount_ && thisBlock.elseCount_) {
        return Blockly.Msg.CONTROLS_IF_TOOLTIP_4;
      }
      return '';
    });
    this.elseifCount_ = 0;
    this.elseCount_ = 0;
  },
/**
   * Crie XML para representar o número de entradas else-if e else.
   * @return {Element} elemento de armazenamento XML.
   * @this Blockly.Block
   */
   mutationToDom: function() {
    if (!this.elseifCount_ && !this.elseCount_) {
      return null;
    }
    var container = document.createElement('mutation');
    if (this.elseifCount_) {
      container.setAttribute('elseif', this.elseifCount_);
    }
    if (this.elseCount_) {
      container.setAttribute('else', 1);
    }
    return container;
  },
  /**
   * Parse XML to restore the else-if and else inputs.
   * @param {!Element} xmlElement XML storage element.
   * @this Blockly.Block
   */
   domToMutation: function(xmlElement) {
    var containerBlock = this;
    var valueConnections = [];
    var statementConnections = [];
    var elseStatementConnection = null;
    if (this.elseCount_) {
      if(containerBlock.getInputTargetBlock('ELSE') && containerBlock.getInputTargetBlock('ELSE').previousConnection)
        elseStatementConnection = containerBlock.getInputTargetBlock('ELSE').previousConnection;
      this.removeInput('ELSE');
    }
    for (var i = this.elseifCount_; i > 0; i--) {
      if(containerBlock.getInputTargetBlock('IF' + i) && containerBlock.getInputTargetBlock('IF' + i).previousConnection)
        valueConnections[i] = (containerBlock.getInputTargetBlock('IF' + i).previousConnection);
      else
        valueConnections[i] = null;
      this.removeInput('IF' + i);
      if(containerBlock.getInputTargetBlock('DO' + i) && containerBlock.getInputTargetBlock('DO' + i).previousConnection)
        statementConnections[i] = (containerBlock.getInputTargetBlock('DO' + i).previousConnection);
      else
        statementConnections[i] = null;
      this.removeInput('DO' + i);
    }
    this.elseifCount_ = parseInt(xmlElement.getAttribute('elseif'), 10);
    this.elseCount_ = parseInt(xmlElement.getAttribute('else'), 10);
    //this.compose(containerBlock);
    for (var i = 1; i <= this.elseifCount_; i++) {
      this.appendValueInput('IF' + i)
      .setCheck([Boolean,Number])
      .appendField("Canal "+ i +":");
     // .appendField("OLA");
  //    this.appendStatementInput('DO' + i)
   //   .appendField(Blockly.Msg.CONTROLS_IF_MSG_THEN);
    }
    if (this.elseCount_) {
      this.appendStatementInput('ELSE')
      .appendField(Blockly.Msg.CONTROLS_IF_MSG_ELSE);
    }
    for(var i = valueConnections.length - 2; i > 0; i--){
      if(valueConnections[i])
        Blockly.Mutator.reconnect(valueConnections[i], this, 'IF' + i);
    }
    for(var i = statementConnections.length - 2; i > 0; i--){
      if(statementConnections[i])
        Blockly.Mutator.reconnect(statementConnections[i], this, 'DO' + i);
    }
  },
  /**
   * Populate the mutator's dialog with this block's components.
   * @param {!Blockly.Workspace} workspace Mutator's workspace.
   * @return {!Blockly.Block} Root block in mutator.
   * @this Blockly.Block
   */
   decompose: function(workspace) {
    var containerBlock = workspace.newBlock('controls_if_if_cmd');
    containerBlock.initSvg();
    var connection = containerBlock.getInput('STACK').connection;
    for (var i = 1; i <= this.elseifCount_; i++) {
      var elseifBlock = workspace.newBlock('controls_if_elseif_cmd');
      elseifBlock.initSvg();
      connection.connect(elseifBlock.previousConnection);
      connection = elseifBlock.nextConnection;
    }
    if (this.elseCount_) {
      var elseBlock = workspace.newBlock('controls_if_else_cmd');
      elseBlock.initSvg();
      connection.connect(elseBlock.previousConnection);
    }
    return containerBlock;
  },
  /**
   * Reconfigure this block based on the mutator dialog's components.
   * @param {!Blockly.Block} containerBlock Root block in mutator.
   * @this Blockly.Block
   */
   compose: function(containerBlock) {
    // Disconnect the else input blocks and remove the inputs.
    if (this.elseCount_) {
      this.removeInput('ELSE');
    }
    this.elseCount_ = 0;
    // Disconnect all the elseif input blocks and remove the inputs.
    for (var i = this.elseifCount_; i > 0; i--) {
      this.removeInput('IF' + i);
   //   this.removeInput('DO' + i);
    }
    this.elseifCount_ = 0;
    // Rebuild the block's optional inputs.
    var clauseBlock = containerBlock.getInputTargetBlock('STACK');
    var valueConnections = [null];
    var statementConnections = [null];
    var elseStatementConnection = null;
    while (clauseBlock) {
      switch (clauseBlock.type) {
        case 'controls_if_elseif_cmd':
        this.elseifCount_++;
        valueConnections.push(clauseBlock.valueConnection_);
        statementConnections.push(clauseBlock.statementConnection_);
        break;
        case 'controls_if_else_cmd':
        this.elseCount_++;
        elseStatementConnection = clauseBlock.statementConnection_;
        break;
        default:
        throw TypeError('Unknown block type: ' + clauseBlock.type);
      }
      clauseBlock = clauseBlock.nextConnection &&
      clauseBlock.nextConnection.targetBlock();
    }

    this.updateShape_();
    // Reconnect any child blocks.
    this.reconnectChildBlocks_(valueConnections, statementConnections, elseStatementConnection);

  },
/**
   * Armazene ponteiros para qualquer bloco filho conectado.
   * @param {!Blockly.Block} containerBlock Bloco raiz no modificador.
   * @this Blockly.Block
   */
   saveConnections: function(containerBlock) {
    var clauseBlock = containerBlock.getInputTargetBlock('STACK');
    var i = 1;
    while (clauseBlock) {
      switch (clauseBlock.type) {
        case 'controls_if_elseif_cmd':
        var inputIf = this.getInput('IF' + i);
      //  var inputDo = this.getInput('DO' + i);
        clauseBlock.valueConnection_ =
        inputIf && inputIf.connection.targetConnection;
        clauseBlock.statementConnection_ =
        inputDo && inputDo.connection.targetConnection;
        i++;
        break;
        case 'controls_if_else_cmd':
        var inputDo = this.getInput('ELSE');
        clauseBlock.statementConnection_ =
        inputDo && inputDo.connection.targetConnection;
        break;
        default:
        throw 'Unknown block type.';
      }
      clauseBlock = clauseBlock.nextConnection &&
      clauseBlock.nextConnection.targetBlock();
    }
  },
/**
   * Reconstrói o bloco com todos os blocos filho anexados.
   */
   rebuildShape_: function() {
    var valueConnections = [null];
    var statementConnections = [null];
    var elseStatementConnection = null;

    if (this.getInput('ELSE')) {
      elseStatementConnection = this.getInput('ELSE').connection.targetConnection;
    }
    var i = 1;
    while (this.getInput('IF' + i)) {
      var inputIf = this.getInput('IF' + i);
      var inputDo = this.getInput('DO' + i);
      console.log(inputIf.connection.targetConnection);
      valueConnections.push(inputIf.connection.targetConnection);
      statementConnections.push(inputDo.connection.targetConnection);
      i++;
    }
    this.updateShape_();
    this.reconnectChildBlocks_(valueConnections, statementConnections,elseStatementConnection);
  },
  /**
   * Modify this block to have the correct number of inputs.
   * @this Blockly.Block
   * @private
   */
   updateShape_: function() {
    // Delete everything.
    if (this.getInput('ELSE')) {
      this.removeInput('ELSE');
    }
    var i = 1;
    while (this.getInput('IF' + i)) {
      this.removeInput('IF' + i);
  //    this.removeInput('DO' + i);
      i++;
    }
// Reconstruir bloco.
    for (var i = 1; i <= this.elseifCount_; i++) {
      this.appendValueInput('IF' + i)
      .setCheck([Number,Boolean])
      .appendField("Canal "+ i +":");
    //  this.appendStatementInput('DO' + i)
    //  .appendField("TESTE");
    }
    if (this.elseCount_) {
      this.appendDummyInput()
      .appendField("Compactando dados a ser enviado\n");
    }
  },
/**
   * Reconecte os blocos infantis.
   * @param {!Array<?Blockly.RenderedConnection>} valueConnections Lista de valores
   * conexões para if input.
   * @param {!Array<?Blockly.RenderedConnection>} instruçãoConexões Lista de
   * conexões de instrução para entrada fazer.
   * @param {?Blockly.RenderedConnection} instrução elseStatementConnection
   * ligação a outra entrada.
   */
   reconnectChildBlocks_: function(valueConnections, statementConnections,
    elseStatementConnection) {
    for (var i = 1; i <= this.elseifCount_; i++) {
      Blockly.Mutator.reconnect(valueConnections[i], this, 'IF' + i);
    //  Blockly.Mutator.reconnect(statementConnections[i], this, 'DO' + i);
    }
   // Blockly.Mutator.reconnect(elseStatementConnection, this, 'ELSE');
  }
};

Blockly.Blocks['controls_if_if_cmd'] = {
  /**
   * Mutator block for if container.
   * @this Blockly.Block
   */
   init: function() {
    this.setColour("#7ED321");
    this.appendDummyInput()
    .appendField("Coleta de Dados para Excel");
    this.appendStatementInput('STACK');
    this.setTooltip(Blockly.Msg.CONTROLS_IF_IF_TOOLTIP);
    this.contextMenu = false;
  }
};

Blockly.Blocks['controls_if_elseif_cmd'] = {
  /**
   * Mutator bolck for else-if condition.
   * @this Blockly.Block
   */
   init: function() {
    this.setColour("#7ED321");
    this.appendDummyInput()
    .appendField("Adicionar mais um Canal");
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip(Blockly.Msg.CONTROLS_IF_ELSEIF_TOOLTIP);
    this.contextMenu = false;
  }
};

Blockly.Blocks['controls_if_else_cmd'] = {
  /**
   * Mutator block for else condition.
   * @this Blockly.Block
   */
   init: function() {
    this.setColour("#7ED321");
    this.appendDummyInput()
    .appendField("Compactar e enviar dados");
    this.setPreviousStatement(true);
    this.setTooltip(Blockly.Msg.CONTROLS_IF_ELSE_TOOLTIP);
    this.contextMenu = false;
  }
};
