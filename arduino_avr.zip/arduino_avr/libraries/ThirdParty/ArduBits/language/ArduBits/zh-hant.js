Blockly.MAKER17_LAMP = '閃燈';
Blockly.MAKER17_BUZZER = '蜂鳴器';
Blockly.MAKER17_DHT11 = 'DHT11溫濕度傳感器';
Blockly.MAKER17_RESISTOR_SCRATCH = '電阻偵測傳感器';
Blockly.MAKER17_TEMP = '溫度傳感器';
Blockly.MAKER17_SOUND = '聲音傳感器';
Blockly.MAKER17_MOISTURE = '土壤濕度傳感器';
Blockly.MAKER17_STEAM = '水滴傳感器';
Blockly.MAKER17_LINEFINDER = '紅外尋跡傳感器'
Blockly.MAKER17_KNOB = '旋鈕傳感器';
Blockly.MAKER17_MAGNETIC = '磁敏傳感器';
Blockly.MAKER17_VIBRATION = '震動傳感器';
Blockly.MAKER17_OBSTACLE = '紅外測障傳感器';
Blockly.MAKER17_TILT = '單向傾角傳感器';
Blockly.MAKER17_TOUCH = '觸摸傳感器';
Blockly.MAKER17_SLIDER = '滑桿傳感器';
Blockly.MAKER17_COLLISION = '碰撞傳感器';
Blockly.MAKER17_BUTTON = '按鈕傳感器';
Blockly.MAKER17_RELAY = '繼電器';
Blockly.MAKER17_LIGHT = '光敏傳感器';
Blockly.MAKER17_LCD1602 = '液晶顯示屏';

// RGB
Blockly.MAKER17_RGB = 'RGB燈';
Blockly.MAKER17_RGB_NUM = '燈號(1~4)';
Blockly.MAKER17_RGB_R= 'R值';
Blockly.MAKER17_RGB_G= 'G值';
Blockly.MAKER17_RGB_B= 'B值';

//四位数码管
Blockly.MAKER17_4DIGITDISPLAY = '四位數碼管';
Blockly.MAKER17_4DIGITDISPLAY_DISPLAYSTRING='顯示字符串';
Blockly.MAKER17_4DIGITDISPLAY_NOMBER1='第';
Blockly.MAKER17_4DIGITDISPLAY_NOMBER2='個';
Blockly.MAKER17_4DIGITDISPLAY_DOT='小數點';
Blockly.MAKER17_4DIGITDISPLAY_ON='亮';
Blockly.MAKER17_4DIGITDISPLAY_OFF='滅';