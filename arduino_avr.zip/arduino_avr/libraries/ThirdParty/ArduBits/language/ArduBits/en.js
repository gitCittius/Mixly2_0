Blockly.MAKER17_LAMP = 'Lamp';
Blockly.MAKER17_BUZZER = 'Buzzer';
Blockly.MAKER17_DHT11 = 'DHT11';
Blockly.MAKER17_RESISTOR_SCRATCH = 'Resistor scratch';
Blockly.MAKER17_TEMP = 'Temperature';
Blockly.MAKER17_SOUND = 'Sound';
Blockly.MAKER17_MOISTURE = 'Moisture';
Blockly.MAKER17_STEAM = 'Steam';
Blockly.MAKER17_LINEFINDER = 'Line finder'
Blockly.MAKER17_KNOB = 'Knob';
Blockly.MAKER17_MAGNETIC = 'Magnetic';
Blockly.MAKER17_VIBRATION = 'Vibration';
Blockly.MAKER17_OBSTACLE = 'Obstacle';
Blockly.MAKER17_TILT = 'Tilt';
Blockly.MAKER17_TOUCH = 'Touch';
Blockly.MAKER17_SLIDER = 'Slider';
Blockly.MAKER17_COLLISION = 'Collision';
Blockly.MAKER17_BUTTON = 'Button';
Blockly.MAKER17_RELAY = 'Relay';
Blockly.MAKER17_LIGHT = 'Light';
Blockly.MAKER17_LCD1602 = 'LCD1602';

// RGB
Blockly.MAKER17_RGB = 'RGB Light';
Blockly.MAKER17_RGB_NUM = 'Light number(1~4)';
Blockly.MAKER17_RGB_R= 'R value';
Blockly.MAKER17_RGB_G= 'G value';
Blockly.MAKER17_RGB_B= 'B value';

//四位数码管
Blockly.MAKER17_4DIGITDISPLAY = 'Digitdisplay';
Blockly.MAKER17_4DIGITDISPLAY_DISPLAYSTRING='displayString';
Blockly.MAKER17_4DIGITDISPLAY_NOMBER1='No.';
Blockly.MAKER17_4DIGITDISPLAY_NOMBER2='';
Blockly.MAKER17_4DIGITDISPLAY_DOT='Dot';
Blockly.MAKER17_4DIGITDISPLAY_ON='On';
Blockly.MAKER17_4DIGITDISPLAY_OFF='Off';