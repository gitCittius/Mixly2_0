var $builtinmodule = function(name)
{
  var matplotlib = {};

  return matplotlib;
};
