var $builtinmodule = function (name) {
	let pgzhelper= {__name__: new Sk.builtin.str("pgzhelper")};
    
	return pgzhelper;
}
