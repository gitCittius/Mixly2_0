(() => {

goog.require('Mixly');
goog.require('Mixly.Config');
goog.require('Mixly.MJSON')
goog.provide('Mixly.Command');

const { Config, Command, MJSON } = Mixly;

const { SOFTWARE } = Config;

Command.DEFAULT = {
    obj: '',
    func: '',
    args: []
}

Command.parse = (commandStr) => {
    return MJSON.decode(MJSON.parse(commandStr));
}

Command.run = (commandObj) => {
    if (SOFTWARE?.debug)
        console.log('收到指令：', commandObj);
    if (typeof commandObj !== 'object') return;
    commandObj = {
        ...Command.DEFAULT,
        ...commandObj
    };
    const { obj, func, args } = commandObj;
    const objList = obj.split('.');
    if (objList.length === 0) return;
    let nowObj = window[objList[0]];
    if (!nowObj) return;
    objList.shift();
    for (let i of objList) {
        nowObj = nowObj[i];
        if (!nowObj) return;
    }
    try {
        if (nowObj[func])
            nowObj[func](...args);
    } catch (e) {
        console.log(e);
    }
}

})();