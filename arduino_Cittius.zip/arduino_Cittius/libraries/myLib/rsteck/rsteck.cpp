#include"rsteck.h"
#include <SoftwareSerial.h>
#include <OneWireMod.h>

#include <EV3UARTSensor.h>

#define P1 1
#define P2 2
#define P3 3
#define P4 4
#define P5 5
#define P6 6
#define P7 7
#define P8 8
#define PA 9
#define PB 10
#define PC 11
#define PD 12

#define LIDO 13
#define R 14
#define G 15
#define B 16

#define ROLO 0
#define GUINADA 1
#define INCLINACAO 2

#define P1_BRANCO A3
#define P2_BRANCO A4
#define P3_BRANCO A5
#define P4_BRANCO A6
#define P5_BRANCO A15
#define P6_BRANCO A12
#define P7_BRANCO A13
#define P8_BRANCO A14
#define PA_BRANCO A8
#define PB_BRANCO A9
#define PC_BRANCO A10
#define PD_BRANCO A11

#define P1_AZUL 22
#define P2_AZUL 23
#define P3_AZUL 24
#define P4_AZUL 25
#define P5_AZUL 4
#define P6_AZUL 53
#define P7_AZUL 28
#define P8_AZUL 29
#define PA_AZUL 2
#define PB_AZUL 3
#define PC_AZUL 18
#define PD_AZUL 19

uint8_t cmd1 [2] = {0x12, 0x15}; //comando para configurar o sensor de cor
uint8_t cmd2 [2] = {0x13, 0x15}; //comando para pedir os valores do código da cor e a cor vermelha em rgb
uint8_t cmd3 [2] = {0x14, 0x15}; //comando para pedir os valores das cores verde e azul em rgb


OneWireMega _P1(A3);
OneWireMega _P2(A4);
OneWireMega _P3(A5);
OneWireMega _P4(A6);
OneWireMega _P5(A15);
OneWireMega _P6(A12);
OneWireMega _P7(A13);
OneWireMega _P8(A14);
OneWireMega _PA(A8);
OneWireMega _PB(A9);
OneWireMega _PC(A10);
OneWireMega _PD(A11);

EV3UARTSensor sens_cor2(A15,4);
EV3UARTSensor sens_cor(A12,53);
EV3UARTSensor sensor7(A13,28);
EV3UARTSensor sensor8(A14,29);



SoftwareSerial I1_Serial(A3, 22); // RX, TX
SoftwareSerial I2_Serial(A14, 24); // RX, TX
SoftwareSerial I3_Serial(A13, 23); // RX, TX
SoftwareSerial I4_Serial(A12, 22); // RX, TX
//SoftwareSerial I5_Serial(A14, 24); // RX, TX
//SoftwareSerial I6_Serial(A14, 24); // RX, TX
//SoftwareSerial I7_Serial(A14, 24); // RX, TX
//SoftwareSerial I8_Serial(A14, 24); // RX, TX
SoftwareSerial M1_Serial(A2, 2); // RX, TX
SoftwareSerial M2_Serial(A9, 3); // RX, TX
SoftwareSerial M3_Serial(A10, 18); // RX, TX
SoftwareSerial M4_Serial(A11, 19); // RX, TX


static u8 txBuff[8]={0xA5,0x01,0x03,0x00,0x00,0x00,0x00,0xC3};

uint8_t strFlag0 = 0;
uint8_t strFlag1 = 0;
uint8_t strFlag2 = 0;
uint8_t strFlag3 = 0;
uint8_t strFlag4 = 0;
uint8_t strFlag5 = 0;
uint8_t strFlag6 = 0;
uint8_t strFlag7 = 0;
uint8_t strFlag8 = 0;
uint8_t strFlag9 = 0;
uint8_t strFlag10 = 0;
uint8_t strFlag11 = 0;
uint8_t strFlag12 = 0;




uint16_t rgb565(unsigned long rgb)
{
  uint16_t R_ = (rgb >> 16) & 0xFF;
  uint16_t G_ = (rgb >>  8) & 0xFF;
  uint16_t B_ = (rgb      ) & 0xFF;

  uint16_t ret  = (R_ & 0xF8) << 8;  // 5 bits
           ret |= (G_ & 0xFC) << 3;  // 6 bits
           ret |= (B_ & 0xF8) >> 3;  // 5 bits
       
  return( ret);
}

void setLed(byte port, uint32_t color){

   byte r = color >> 16;
   byte g = color >> 8 & 0xFF;
   byte b = color & 0xFF;

  txBuff[3]=r; txBuff[4]=g; txBuff[5]=b;
  
  switch(port){
    case 0:
        if(strFlag0==0)
        {
          strFlag0 = 1;
          I1_Serial.begin(9600);
        }
        I1_Serial.listen();
        for(byte i=0;i<8;i++) {I1_Serial.write(txBuff[i]);delay(3);}       
    break;

    case 1:
        if(strFlag1==0)
        {
          strFlag1 = 1;
          I2_Serial.begin(9600);
        }
        I2_Serial.listen();
        for(byte i=0;i<8;i++) {I2_Serial.write(txBuff[i]);delay(3);}     
    break;

    case 2:
        if(strFlag2==0)
        {
          strFlag2 = 1;
          I3_Serial.begin(9600);
        }
        I3_Serial.println(color);
        for(byte i=0;i<8;i++) {I3_Serial.write(txBuff[i]);}       
    break;

    case 3:
        if(strFlag3==0)
        {
          strFlag3 = 1;
          I4_Serial.begin(9600);
        }
        I4_Serial.println(color);
        for(byte i=0;i<8;i++) {I4_Serial.write(txBuff[i]);}       
    break;

    case 4:
        if(strFlag4==0)
        {
          strFlag4 = 1;
          M1_Serial.begin(9600);
        }
        M1_Serial.println(color);
        for(byte i=0;i<8;i++) {M1_Serial.write(txBuff[i]);}       
    break;

    case 5:
        if(strFlag5==0)
        {
          strFlag5 = 1;
          M2_Serial.begin(9600);
        }
        M2_Serial.println(color);
        for(byte i=0;i<8;i++) {M2_Serial.write(txBuff[i]);}       
    break;

    case 6:
        if(strFlag6==0)
        {
          strFlag6 = 1;
          M3_Serial.begin(9600);
        }
        M3_Serial.println(color);
        for(byte i=0;i<8;i++) {M3_Serial.write(txBuff[i]);}       
    break;

    case 7:
        if(strFlag7==0)
        {
          strFlag7 = 1;
          M4_Serial.begin(9600);
        }
        M4_Serial.println(color);
        for(byte i=0;i<8;i++) {M4_Serial.write(txBuff[i]);}       
    break;
  }
}


//Motores
uint8_t MotorFlag1 = 0;
uint8_t MotorFlag2 = 0;
uint8_t MotorFlag3 = 0;
uint8_t MotorFlag4 = 0;

uint8_t PWMB1 = 12;
uint8_t PWMB2 = 11;

uint8_t PWMA1 = 9;
uint8_t PWMA2 = 10;

uint8_t PWMC1 = 13;
uint8_t PWMC2 = 46;

uint8_t PWMD1 = 45;
uint8_t PWMD2 = 44;

void setMotorPin(byte motor, int value){
  
  if(value > 100) value = 100;
  else if(value < -100) value = -100;

  //-----------------------------------------------
    switch (motor)
    {
    case A:
      if (MotorFlag1 == 0)
      {
        MotorFlag1 = 1;
        pinMode(PWMA1, OUTPUT);
        pinMode(PWMA2, OUTPUT);             
      }
      break;

    case B:
      if (MotorFlag2 == 0)
      {
        MotorFlag2 = 1;
        pinMode(PWMB1, OUTPUT);
        pinMode(PWMB2, OUTPUT);             
      }
      break;

    case C:
      if (MotorFlag3 == 0)
      {
        MotorFlag3 = 1;
        pinMode(PWMC1, OUTPUT);
        pinMode(PWMC2, OUTPUT);           
      }
      break;

    case D:
      if (MotorFlag4 == 0)
      {
        MotorFlag4 = 1;
        pinMode(PWMD1, OUTPUT);
        pinMode(PWMD2, OUTPUT);           
      }
      break;

    default:break;
    }
  //-----------------------------------------------------

    
    switch (motor)
    {
      case A:
        if (value == 0)
        {
          analogWrite(PWMA1, 255);
          analogWrite(PWMA2, 255);
        }
        else if (value>0)
        {
          analogWrite(PWMA1, map(value,0,100,0,255));
          analogWrite(PWMA2, 0);
          
          
        }
        else if (value<0)
        {
          analogWrite(PWMA2, map(value,-100,0,255,0));
          analogWrite(PWMA1, 0); 
        }
        break;

      case B:
        if (value == 0)
        {
          analogWrite(PWMB1, 255);
          analogWrite(PWMB2, 255);
        }
        else if (value>0)
        {
          analogWrite(PWMB1, map(value,0,100,0,255));
          analogWrite(PWMB2, 0);
        }
        else if (value<0)
        {
          analogWrite(PWMB2, map(value,-100,0,255,0));
          analogWrite(PWMB1, 0);
        }
        break;

      case C:
        if (value == 0)
        {
          analogWrite(PWMC1, 255);
          analogWrite(PWMC2, 255);
        }
        else if (value>0)
        {
          analogWrite(PWMC1, map(value,0,100,0,255));
          analogWrite(PWMC2, 0);
        }
        else if (value<0)
        {
          analogWrite(PWMC2, map(value,-100,0,255,0));
          analogWrite(PWMC1, 0);
        }
        break;

      case D:
        if (value == 0)
        {
          analogWrite(PWMD1, 255);
          analogWrite(PWMD2, 255);
        }
        else if (value>0)
        {
          analogWrite(PWMD1, map(value,0,100,0,255));
          analogWrite(PWMD2, 0);
        }
        else if (value<0)
        {
          analogWrite(PWMD2, map(value,-100,0,255,0));
          analogWrite(PWMD1, 0);
        }
        break;

      default:break;
    }
}

uint8_t CodeFlag1  = 0; 	
uint8_t CodeFlag2  = 0;	
uint8_t CodeFlag3  = 0; 
uint8_t CodeFlag4  = 0; 

long  MotorCodeCnt1= 0;	
long  MotorCodeCnt2= 0;	
long  MotorCodeCnt3= 0;	
long  MotorCodeCnt4= 0;	

int getDigitalPin(uint8_t pin)									
{
	pinMode(pin,INPUT_PULLUP);
	return digitalRead(pin);
}

void getCode1Interrupt()	
{
	uint8_t m_ISR,m_Dir;	
	m_ISR = getDigitalPin(2);	
	m_Dir = getDigitalPin(A8);	
	if(m_ISR^m_Dir)			
		MotorCodeCnt1++;	
	else
		MotorCodeCnt1--;	 
} 
void getCode2Interrupt()	
{
	uint8_t m_ISR,m_Dir;	
	m_ISR = getDigitalPin(3);	
	m_Dir = getDigitalPin(A9);	
	if(m_ISR^m_Dir)			
		MotorCodeCnt2++;	
	else
		MotorCodeCnt2--;	
}
void getCode3Interrupt()	
{
	uint8_t m_ISR,m_Dir;	
	m_ISR = getDigitalPin(18);	
	m_Dir = getDigitalPin(A10);	
	if(m_ISR^m_Dir)			
		MotorCodeCnt3++;	
	else
		MotorCodeCnt3--;	
}
void getCode4Interrupt()	
{
	uint8_t m_ISR,m_Dir;	
	m_ISR = getDigitalPin(19);	
	m_Dir = getDigitalPin(A11);	
	if(m_ISR^m_Dir)			
		MotorCodeCnt4++;	
	else
		MotorCodeCnt4--;	
}  



void setCodeInit(uint8_t interrupt) //uint8_t
{	
	switch(interrupt)
	{
		case m1: attachInterrupt(0, getCode1Interrupt, CHANGE); break;
		case m2: attachInterrupt(1, getCode2Interrupt, CHANGE); break;
		case m3: attachInterrupt(5, getCode3Interrupt, CHANGE); break;
		case m4: attachInterrupt(4, getCode4Interrupt, CHANGE); break;
		default:break;		
	}
}

long getCodePin(uint8_t code)
{	
	if(CodeFlag1==0 && code==m1)
	{
		CodeFlag1 = 1;
		setCodeInit(code);		
	}
	else if(CodeFlag2==0 && code==m2)
	{
		CodeFlag2 = 1;
		setCodeInit(code);				
	}
	else if(CodeFlag3==0 && code==m3)
	{
		CodeFlag3 = 1;
		setCodeInit(code);				
	}
	else if(CodeFlag4==0 && code==m4)
	{
		CodeFlag4 = 1;
		setCodeInit(code);				
	}
	switch(code)
	{
		case m1: return	MotorCodeCnt1; break; 
		case m2: return	MotorCodeCnt2; break; 
		case m3: return	MotorCodeCnt3; break; 
		case m4: return	MotorCodeCnt4; break; 
		default:break;
	}
}

void setClearCodePin(uint8_t code)	
{	
	switch(code)
	{
		case m1: MotorCodeCnt1 = 0; break; 
		case m2: MotorCodeCnt2 = 0; break; 
		case m3: MotorCodeCnt3 = 0; break; 
		case m4: MotorCodeCnt4 = 0; break; 
		default:break;		
	}
}

void setCloseCodeInterruptPin(uint8_t code)
{
	switch(code)
	{
		case m1: detachInterrupt(0); MotorCodeCnt1 = 0; CodeFlag1 = 0; break; 	
		case m2: detachInterrupt(1); MotorCodeCnt2 = 0; CodeFlag2 = 0; break; 	
		case m3: detachInterrupt(5); MotorCodeCnt3 = 0; CodeFlag3 = 0; break; 
		case m4: detachInterrupt(4); MotorCodeCnt4 = 0; CodeFlag4 = 0; break; 	
		default:break;
	}		
}



void _loop(){
  
}

//Função simples para deley sem travamento
void _delay(float seconds) {                  //Valores em Segundos
  long endTime = millis() + seconds * 1000;   //Converter valores Segundos em millis
  while(millis() < endTime) _loop();          //Chamar funções dos eventos a todos momento.
}


int16_t GetRolo(uint8_t *Giro){
  uint16_t dado = (Giro[0] << 8) + Giro[1];
  if((dado & 63488) == 0){
    return (dado & 2047);
    }
  else{
    return (~dado & 2047)*-1;
    
    }
  }

int16_t GetInclinacao(uint8_t *Giro){
  uint16_t dado = (Giro[2] << 8) + Giro[3];
  if((dado & 63488) == 0){
    return (dado & 2047);
    }
  else{
    return (~dado & 2047)*-1;
    }
  }

int16_t GetGuinada(uint8_t *Giro){
  uint16_t dado = (Giro[4] << 8) + Giro[5];
  if((dado & 63488) == 0){
    return (dado & 2047);
    }
  else{
    return (~dado & 2047)*-1;
    }
  }


int16_t lerSensor_Acelerometro(byte pin, byte get_){
  uint8_t Giro [6] = {0xC0, 0x01, 0x01, 0xFF, 0xC0, 0x01};
  switch (pin){
    case P1:
      if(_P1.reset_acelerometroCmd()){
        _P1.write_ace100us(0x13);
        if(_P1.reset_acelerometroDado()){
          _P1.read_bytes_acelerometro(Giro, 6);
          switch (get_){
            case ROLO:
            return GetRolo(Giro);
            break;
            case INCLINACAO:
            return GetInclinacao(Giro);
            break;
            case GUINADA:
            return GetGuinada(Giro);
            break;
          }
        }
        else{
          delayMicroseconds(100);
          if(_P1.reset_acelerometroCmd()){
            _P1.write_ace100us(0x13);
            if(_P1.reset_acelerometroDado()){
              _P1.read_bytes_acelerometro(Giro, 6);
              switch (get_){
                case ROLO:
                return GetRolo(Giro);
                break;
                case INCLINACAO:
                return GetInclinacao(Giro);
                break;
                case GUINADA:
                return GetGuinada(Giro);
                break;
              }
            }
          }
          else{
            switch (get_){
              case ROLO:
              return 0x3FFF;
              break;
              case INCLINACAO:
              return 0x3FFF;
              break;
              case GUINADA:
              return 0x3FFF;
              break;
            }
          }
        }
      }
      else{
        delayMicroseconds(100);
        if(_P1.reset_acelerometroCmd()){
          _P1.write_ace100us(0x13);
          if(_P1.reset_acelerometroDado()){
            _P1.read_bytes_acelerometro(Giro, 6);
            switch (get_){
              case ROLO:
              return GetRolo(Giro);
              break;
              case INCLINACAO:
              return GetInclinacao(Giro);
              break;
              case GUINADA:
              return GetGuinada(Giro);
              break;
            }
          }
        }
        else{
          switch (get_){
            case ROLO:
            return 0x3FFF;
            break;
            case INCLINACAO:
            return 0x3FFF;
            break;
            case GUINADA:
            return 0x3FFF;
            break;
          }
        }
      }
    break;
    case P2:
      if(_P2.reset_acelerometroCmd()){
        _P2.write_ace100us(0x13);
        if(_P2.reset_acelerometroDado()){
          _P2.read_bytes_acelerometro(Giro, 6);
          switch (get_){
            case ROLO:
            return GetRolo(Giro);
            break;
            case INCLINACAO:
            return GetInclinacao(Giro);
            break;
            case GUINADA:
            return GetGuinada(Giro);
            break;
          }
        }
        else{
          delayMicroseconds(100);
          if(_P2.reset_acelerometroCmd()){
            _P2.write_ace100us(0x13);
            if(_P2.reset_acelerometroDado()){
              _P2.read_bytes_acelerometro(Giro, 6);
              switch (get_){
                case ROLO:
                return GetRolo(Giro);
                break;
                case INCLINACAO:
                return GetInclinacao(Giro);
                break;
                case GUINADA:
                return GetGuinada(Giro);
                break;
              }
            }
          }
          else{
            switch (get_){
              case ROLO:
              return 0x3FFF;
              break;
              case INCLINACAO:
              return 0x3FFF;
              break;
              case GUINADA:
              return 0x3FFF;
              break;
            }
          }
        }
      }
      else{
        delayMicroseconds(100);
        if(_P2.reset_acelerometroCmd()){
          _P2.write_ace100us(0x13);
          if(_P2.reset_acelerometroDado()){
            _P2.read_bytes_acelerometro(Giro, 6);
            switch (get_){
              case ROLO:
              return GetRolo(Giro);
              break;
              case INCLINACAO:
              return GetInclinacao(Giro);
              break;
              case GUINADA:
              return GetGuinada(Giro);
              break;
            }
          }
        }
        else{
          switch (get_){
            case ROLO:
            return 0x3FFF;
            break;
            case INCLINACAO:
            return 0x3FFF;
            break;
            case GUINADA:
            return 0x3FFF;
            break;
          }
        }
      }
    break;
    case P3:
      if(_P3.reset_acelerometroCmd()){
        _P3.write_ace100us(0x13);
        if(_P3.reset_acelerometroDado()){
          _P3.read_bytes_acelerometro(Giro, 6);
          switch (get_){
            case ROLO:
            return GetRolo(Giro);
            break;
            case INCLINACAO:
            return GetInclinacao(Giro);
            break;
            case GUINADA:
            return GetGuinada(Giro);
            break;
          }
        }
        else{
          delayMicroseconds(100);
          if(_P3.reset_acelerometroCmd()){
            _P3.write_ace100us(0x13);
            if(_P3.reset_acelerometroDado()){
              _P3.read_bytes_acelerometro(Giro, 6);
              switch (get_){
                case ROLO:
                return GetRolo(Giro);
                break;
                case INCLINACAO:
                return GetInclinacao(Giro);
                break;
                case GUINADA:
                return GetGuinada(Giro);
                break;
              }
            }
          }
          else{
            switch (get_){
              case ROLO:
              return 0x3FFF;
              break;
              case INCLINACAO:
              return 0x3FFF;
              break;
              case GUINADA:
              return 0x3FFF;
              break;
            }
          }
        }
      }
      else{
        delayMicroseconds(100);
        if(_P3.reset_acelerometroCmd()){
          _P3.write_ace100us(0x13);
          if(_P3.reset_acelerometroDado()){
            _P3.read_bytes_acelerometro(Giro, 6);
            switch (get_){
              case ROLO:
              return GetRolo(Giro);
              break;
              case INCLINACAO:
              return GetInclinacao(Giro);
              break;
              case GUINADA:
              return GetGuinada(Giro);
              break;
            }
          }
        }
        else{
          switch (get_){
            case ROLO:
            return 0x3FFF;
            break;
            case INCLINACAO:
            return 0x3FFF;
            break;
            case GUINADA:
            return 0x3FFF;
            break;
          }
        }
      }
    break;
    case P4:
      if(_P4.reset_acelerometroCmd()){
        _P4.write_ace100us(0x13);
        if(_P4.reset_acelerometroDado()){
          _P4.read_bytes_acelerometro(Giro, 6);
          switch (get_){
            case ROLO:
            return GetRolo(Giro);
            break;
            case INCLINACAO:
            return GetInclinacao(Giro);
            break;
            case GUINADA:
            return GetGuinada(Giro);
            break;
          }
        }
        else{
          delayMicroseconds(100);
          if(_P4.reset_acelerometroCmd()){
            _P4.write_ace100us(0x13);
            if(_P4.reset_acelerometroDado()){
              _P4.read_bytes_acelerometro(Giro, 6);
              switch (get_){
                case ROLO:
                return GetRolo(Giro);
                break;
                case INCLINACAO:
                return GetInclinacao(Giro);
                break;
                case GUINADA:
                return GetGuinada(Giro);
                break;
              }
            }
          }
          else{
            switch (get_){
              case ROLO:
              return 0x3FFF;
              break;
              case INCLINACAO:
              return 0x3FFF;
              break;
              case GUINADA:
              return 0x3FFF;
              break;
            }
          }
        }
      }
      else{
        delayMicroseconds(100);
        if(_P4.reset_acelerometroCmd()){
          _P4.write_ace100us(0x13);
          if(_P4.reset_acelerometroDado()){
            _P4.read_bytes_acelerometro(Giro, 6);
            switch (get_){
              case ROLO:
              return GetRolo(Giro);
              break;
              case INCLINACAO:
              return GetInclinacao(Giro);
              break;
              case GUINADA:
              return GetGuinada(Giro);
              break;
            }
          }
        }
        else{
          switch (get_){
            case ROLO:
            return 0x3FFF;
            break;
            case INCLINACAO:
            return 0x3FFF;
            break;
            case GUINADA:
            return 0x3FFF;
            break;
          }
        }
      }
    break;
    case P5:
      if(_P5.reset_acelerometroCmd()){
        _P5.write_ace100us(0x13);
        if(_P5.reset_acelerometroDado()){
          _P5.read_bytes_acelerometro(Giro, 6);
          switch (get_){
            case ROLO:
            return GetRolo(Giro);
            break;
            case INCLINACAO:
            return GetInclinacao(Giro);
            break;
            case GUINADA:
            return GetGuinada(Giro);
            break;
          }
        }
        else{
          delayMicroseconds(100);
          if(_P5.reset_acelerometroCmd()){
            _P5.write_ace100us(0x13);
            if(_P5.reset_acelerometroDado()){
              _P5.read_bytes_acelerometro(Giro, 6);
              switch (get_){
                case ROLO:
                return GetRolo(Giro);
                break;
                case INCLINACAO:
                return GetInclinacao(Giro);
                break;
                case GUINADA:
                return GetGuinada(Giro);
                break;
              }
            }
          }
          else{
            switch (get_){
              case ROLO:
              return 0x3FFF;
              break;
              case INCLINACAO:
              return 0x3FFF;
              break;
              case GUINADA:
              return 0x3FFF;
              break;
            }
          }
        }
      }
      else{
        delayMicroseconds(100);
        if(_P5.reset_acelerometroCmd()){
          _P5.write_ace100us(0x13);
          if(_P5.reset_acelerometroDado()){
            _P5.read_bytes_acelerometro(Giro, 6);
            switch (get_){
              case ROLO:
              return GetRolo(Giro);
              break;
              case INCLINACAO:
              return GetInclinacao(Giro);
              break;
              case GUINADA:
              return GetGuinada(Giro);
              break;
            }
          }
        }
        else{
          switch (get_){
            case ROLO:
            return 0x3FFF;
            break;
            case INCLINACAO:
            return 0x3FFF;
            break;
            case GUINADA:
            return 0x3FFF;
            break;
          }
        }
      }
    break;
    case P6:
      if(_P6.reset_acelerometroCmd()){
        _P6.write_ace100us(0x13);
        if(_P6.reset_acelerometroDado()){
          _P6.read_bytes_acelerometro(Giro, 6);
          switch (get_){
            case ROLO:
            return GetRolo(Giro);
            break;
            case INCLINACAO:
            return GetInclinacao(Giro);
            break;
            case GUINADA:
            return GetGuinada(Giro);
            break;
          }
        }
        else{
          delayMicroseconds(100);
          if(_P6.reset_acelerometroCmd()){
            _P6.write_ace100us(0x13);
            if(_P6.reset_acelerometroDado()){
              _P6.read_bytes_acelerometro(Giro, 6);
              switch (get_){
                case ROLO:
                return GetRolo(Giro);
                break;
                case INCLINACAO:
                return GetInclinacao(Giro);
                break;
                case GUINADA:
                return GetGuinada(Giro);
                break;
              }
            }
          }
          else{
            switch (get_){
              case ROLO:
              return 0x3FFF;
              break;
              case INCLINACAO:
              return 0x3FFF;
              break;
              case GUINADA:
              return 0x3FFF;
              break;
            }
          }
        }
      }
      else{
        delayMicroseconds(100);
        if(_P6.reset_acelerometroCmd()){
          _P6.write_ace100us(0x13);
          if(_P6.reset_acelerometroDado()){
            _P6.read_bytes_acelerometro(Giro, 6);
            switch (get_){
              case ROLO:
              return GetRolo(Giro);
              break;
              case INCLINACAO:
              return GetInclinacao(Giro);
              break;
              case GUINADA:
              return GetGuinada(Giro);
              break;
            }
          }
        }
        else{
          switch (get_){
            case ROLO:
            return 0x3FFF;
            break;
            case INCLINACAO:
            return 0x3FFF;
            break;
            case GUINADA:
            return 0x3FFF;
            break;
          }
        }
      }
    break;
    case P7:
      if(_P7.reset_acelerometroCmd()){
        _P7.write_ace100us(0x13);
        if(_P7.reset_acelerometroDado()){
          _P7.read_bytes_acelerometro(Giro, 6);
          switch (get_){
            case ROLO:
            return GetRolo(Giro);
            break;
            case INCLINACAO:
            return GetInclinacao(Giro);
            break;
            case GUINADA:
            return GetGuinada(Giro);
            break;
          }
        }
        else{
          delayMicroseconds(100);
          if(_P7.reset_acelerometroCmd()){
            _P7.write_ace100us(0x13);
            if(_P7.reset_acelerometroDado()){
              _P7.read_bytes_acelerometro(Giro, 6);
              switch (get_){
                case ROLO:
                return GetRolo(Giro);
                break;
                case INCLINACAO:
                return GetInclinacao(Giro);
                break;
                case GUINADA:
                return GetGuinada(Giro);
                break;
              }
            }
          }
          else{
            switch (get_){
              case ROLO:
              return 0x3FFF;
              break;
              case INCLINACAO:
              return 0x3FFF;
              break;
              case GUINADA:
              return 0x3FFF;
              break;
            }
          }
        }
      }
      else{
        delayMicroseconds(100);
        if(_P7.reset_acelerometroCmd()){
          _P7.write_ace100us(0x13);
          if(_P7.reset_acelerometroDado()){
            _P7.read_bytes_acelerometro(Giro, 6);
            switch (get_){
              case ROLO:
              return GetRolo(Giro);
              break;
              case INCLINACAO:
              return GetInclinacao(Giro);
              break;
              case GUINADA:
              return GetGuinada(Giro);
              break;
            }
          }
        }
        else{
          switch (get_){
            case ROLO:
            return 0x3FFF;
            break;
            case INCLINACAO:
            return 0x3FFF;
            break;
            case GUINADA:
            return 0x3FFF;
            break;
          }
        }
      }
    break;
    case P8:
      if(_P8.reset_acelerometroCmd()){
        _P8.write_ace100us(0x13);
        if(_P8.reset_acelerometroDado()){
          _P8.read_bytes_acelerometro(Giro, 6);
          switch (get_){
            case ROLO:
            return GetRolo(Giro);
            break;
            case INCLINACAO:
            return GetInclinacao(Giro);
            break;
            case GUINADA:
            return GetGuinada(Giro);
            break;
          }
        }
        else{
          delayMicroseconds(100);
          if(_P8.reset_acelerometroCmd()){
            _P8.write_ace100us(0x13);
            if(_P8.reset_acelerometroDado()){
              _P8.read_bytes_acelerometro(Giro, 6);
              switch (get_){
                case ROLO:
                return GetRolo(Giro);
                break;
                case INCLINACAO:
                return GetInclinacao(Giro);
                break;
                case GUINADA:
                return GetGuinada(Giro);
                break;
              }
            }
          }
          else{
            switch (get_){
              case ROLO:
              return 0x3FFF;
              break;
              case INCLINACAO:
              return 0x3FFF;
              break;
              case GUINADA:
              return 0x3FFF;
              break;
            }
          }
        }
      }
      else{
        delayMicroseconds(100);
        if(_P8.reset_acelerometroCmd()){
          _P8.write_ace100us(0x13);
          if(_P8.reset_acelerometroDado()){
            _P8.read_bytes_acelerometro(Giro, 6);
            switch (get_){
              case ROLO:
              return GetRolo(Giro);
              break;
              case INCLINACAO:
              return GetInclinacao(Giro);
              break;
              case GUINADA:
              return GetGuinada(Giro);
              break;
            }
          }
        }
        else{
          switch (get_){
            case ROLO:
            return 0x3FFF;
            break;
            case INCLINACAO:
            return 0x3FFF;
            break;
            case GUINADA:
            return 0x3FFF;
            break;
          }
        }
      }
    break;
    case PA:
      if(_PA.reset_acelerometroCmd()){
        _PA.write_ace100us(0x13);
        if(_PA.reset_acelerometroDado()){
          _PA.read_bytes_acelerometro(Giro, 6);
          switch (get_){
            case ROLO:
            return GetRolo(Giro);
            break;
            case INCLINACAO:
            return GetInclinacao(Giro);
            break;
            case GUINADA:
            return GetGuinada(Giro);
            break;
          }
        }
        else{
          delayMicroseconds(100);
          if(_PA.reset_acelerometroCmd()){
            _PA.write_ace100us(0x13);
            if(_PA.reset_acelerometroDado()){
              _PA.read_bytes_acelerometro(Giro, 6);
              switch (get_){
                case ROLO:
                return GetRolo(Giro);
                break;
                case INCLINACAO:
                return GetInclinacao(Giro);
                break;
                case GUINADA:
                return GetGuinada(Giro);
                break;
              }
            }
          }
          else{
            switch (get_){
              case ROLO:
              return 0x3FFF;
              break;
              case INCLINACAO:
              return 0x3FFF;
              break;
              case GUINADA:
              return 0x3FFF;
              break;
            }
          }
        }
      }
      else{
        delayMicroseconds(100);
        if(_PA.reset_acelerometroCmd()){
          _PA.write_ace100us(0x13);
          if(_PA.reset_acelerometroDado()){
            _PA.read_bytes_acelerometro(Giro, 6);
            switch (get_){
              case ROLO:
              return GetRolo(Giro);
              break;
              case INCLINACAO:
              return GetInclinacao(Giro);
              break;
              case GUINADA:
              return GetGuinada(Giro);
              break;
            }
          }
        }
        else{
          switch (get_){
            case ROLO:
            return 0x3FFF;
            break;
            case INCLINACAO:
            return 0x3FFF;
            break;
            case GUINADA:
            return 0x3FFF;
            break;
          }
        }
      }
    break;
    case PB:
      if(_PB.reset_acelerometroCmd()){
        _PB.write_ace100us(0x13);
        if(_PB.reset_acelerometroDado()){
          _PB.read_bytes_acelerometro(Giro, 6);
          switch (get_){
            case ROLO:
            return GetRolo(Giro);
            break;
            case INCLINACAO:
            return GetInclinacao(Giro);
            break;
            case GUINADA:
            return GetGuinada(Giro);
            break;
          }
        }
        else{
          delayMicroseconds(100);
          if(_PB.reset_acelerometroCmd()){
            _PB.write_ace100us(0x13);
            if(_PB.reset_acelerometroDado()){
              _PB.read_bytes_acelerometro(Giro, 6);
              switch (get_){
                case ROLO:
                return GetRolo(Giro);
                break;
                case INCLINACAO:
                return GetInclinacao(Giro);
                break;
                case GUINADA:
                return GetGuinada(Giro);
                break;
              }
            }
          }
          else{
            switch (get_){
              case ROLO:
              return 0x3FFF;
              break;
              case INCLINACAO:
              return 0x3FFF;
              break;
              case GUINADA:
              return 0x3FFF;
              break;
            }
          }
        }
      }
      else{
        delayMicroseconds(100);
        if(_PB.reset_acelerometroCmd()){
          _PB.write_ace100us(0x13);
          if(_PB.reset_acelerometroDado()){
            _PB.read_bytes_acelerometro(Giro, 6);
            switch (get_){
              case ROLO:
              return GetRolo(Giro);
              break;
              case INCLINACAO:
              return GetInclinacao(Giro);
              break;
              case GUINADA:
              return GetGuinada(Giro);
              break;
            }
          }
        }
        else{
          switch (get_){
            case ROLO:
            return 0x3FFF;
            break;
            case INCLINACAO:
            return 0x3FFF;
            break;
            case GUINADA:
            return 0x3FFF;
            break;
          }
        }
      }
    break;
    case PC:
      if(_PC.reset_acelerometroCmd()){
        _PC.write_ace100us(0x13);
        if(_PC.reset_acelerometroDado()){
          _PC.read_bytes_acelerometro(Giro, 6);
          switch (get_){
            case ROLO:
            return GetRolo(Giro);
            break;
            case INCLINACAO:
            return GetInclinacao(Giro);
            break;
            case GUINADA:
            return GetGuinada(Giro);
            break;
          }
        }
        else{
          delayMicroseconds(100);
          if(_PC.reset_acelerometroCmd()){
            _PC.write_ace100us(0x13);
            if(_PC.reset_acelerometroDado()){
              _PC.read_bytes_acelerometro(Giro, 6);
              switch (get_){
                case ROLO:
                return GetRolo(Giro);
                break;
                case INCLINACAO:
                return GetInclinacao(Giro);
                break;
                case GUINADA:
                return GetGuinada(Giro);
                break;
              }
            }
          }
          else{
            switch (get_){
              case ROLO:
              return 0x3FFF;
              break;
              case INCLINACAO:
              return 0x3FFF;
              break;
              case GUINADA:
              return 0x3FFF;
              break;
            }
          }
        }
      }
      else{
        delayMicroseconds(100);
        if(_PC.reset_acelerometroCmd()){
          _PC.write_ace100us(0x13);
          if(_PC.reset_acelerometroDado()){
            _PC.read_bytes_acelerometro(Giro, 6);
            switch (get_){
              case ROLO:
              return GetRolo(Giro);
              break;
              case INCLINACAO:
              return GetInclinacao(Giro);
              break;
              case GUINADA:
              return GetGuinada(Giro);
              break;
            }
          }
        }
        else{
          switch (get_){
            case ROLO:
            return 0x3FFF;
            break;
            case INCLINACAO:
            return 0x3FFF;
            break;
            case GUINADA:
            return 0x3FFF;
            break;
          }
        }
      }
    break;
    case PD:
      if(_PD.reset_acelerometroCmd()){
        _PD.write_ace100us(0x13);
        if(_PD.reset_acelerometroDado()){
          _PD.read_bytes_acelerometro(Giro, 6);
          switch (get_){
            case ROLO:
            return GetRolo(Giro);
            break;
            case INCLINACAO:
            return GetInclinacao(Giro);
            break;
            case GUINADA:
            return GetGuinada(Giro);
            break;
          }
        }
        else{
          delayMicroseconds(100);
          if(_PD.reset_acelerometroCmd()){
            _PD.write_ace100us(0x13);
            if(_PD.reset_acelerometroDado()){
              _PD.read_bytes_acelerometro(Giro, 6);
              switch (get_){
                case ROLO:
                return GetRolo(Giro);
                break;
                case INCLINACAO:
                return GetInclinacao(Giro);
                break;
                case GUINADA:
                return GetGuinada(Giro);
                break;
              }
            }
          }
          else{
            switch (get_){
              case ROLO:
              return 0x3FFF;
              break;
              case INCLINACAO:
              return 0x3FFF;
              break;
              case GUINADA:
              return 0x3FFF;
              break;
            }
          }
        }
      }
      else{
        delayMicroseconds(100);
        if(_PD.reset_acelerometroCmd()){
          _PD.write_ace100us(0x13);
          if(_PD.reset_acelerometroDado()){
            _PD.read_bytes_acelerometro(Giro, 6);
            switch (get_){
              case ROLO:
              return GetRolo(Giro);
              break;
              case INCLINACAO:
              return GetInclinacao(Giro);
              break;
              case GUINADA:
              return GetGuinada(Giro);
              break;
            }
          }
        }
        else{
          switch (get_){
            case ROLO:
            return 0x3FFF;
            break;
            case INCLINACAO:
            return 0x3FFF;
            break;
            case GUINADA:
            return 0x3FFF;
            break;
          }
        }
      }
    break;
  }

}

byte CodigoVermelho = 0;

byte getSensorColor(){

  sens_cor.check_for_data();
  
  //sens_cor.listen_sensor();
  
  if (sens_cor.get_status() == DATA_MODE) {     
    if ((sens_cor.get_current_mode() != 2) && (sens_cor.get_type() == 29)) {
        int mode = 2;      
        if (mode >= 0 && mode < sens_cor.get_number_of_modes()) {
          sens_cor.set_mode(mode);
        }}

    float sample[sens_cor.sample_size()];
    sens_cor.fetch_sample(sample, 0);
    if(sens_cor.get_type() == 29){
    for (int i = 0; i < sens_cor.sample_size(); i++) {
      //Serial.println(COR[int(sample[i])]);
      //Serial.println(byte(sample[i]));
      CodigoVermelho = sample[i];
    }}
    
  }
  
  return CodigoVermelho;
}

byte lerSensor_de_Cor(byte pin, byte get_){
     static uint8_t CodigoVermelho [2] = {0x00, 0x00}; 
     static uint8_t VerdeAzul [2] = {0x00, 0x00};
     static uint8_t controle = 0;
  switch (pin) {
    case P1:
      if(_P1.reset_sensorCor()&&controle==0){_P1.write_bytes_cor100us(cmd1,2);_P1.reset_finalSensorCor();controle=1;}
          delay(64);
          if(_P1.reset_sensorCor()&&controle==1){_P1.write_bytes_cor100us(cmd2,2);_P1.reset_finalSensorCor();_P1.read_bytes_sensorCor(CodigoVermelho, 2);controle=2;}
          if(_P1.reset_sensorCor()&&controle==2){_P1.write_bytes_cor100us(cmd3,2);_P1.reset_finalSensorCor();_P1.read_bytes_sensorCor(VerdeAzul, 2);controle=0;
          }else{return 0;}

          switch (get_) {
            case LIDO:
              return CodigoVermelho[0];
            break;
            case G:
              return VerdeAzul[0];
            break;
            case B:
              return VerdeAzul[1];
            break;
            case R:
              return CodigoVermelho[1];
            break;
          }
          
    break;
    case P2:
      if(_P2.reset_sensorCor()&&controle==0){_P2.write_bytes_cor100us(cmd1,2);_P2.reset_finalSensorCor();controle=1;}
          delay(64);
          if(_P2.reset_sensorCor()&&controle==1){_P2.write_bytes_cor100us(cmd2,2);_P2.reset_finalSensorCor();_P2.read_bytes_sensorCor(CodigoVermelho, 2);controle=2;}
          if(_P2.reset_sensorCor()&&controle==2){_P2.write_bytes_cor100us(cmd3,2);_P2.reset_finalSensorCor();_P2.read_bytes_sensorCor(VerdeAzul, 2);controle=0;
          }else{return 0;}

          switch (get_) {
            case LIDO:
              return CodigoVermelho[0];
            break;
            case G:
              return VerdeAzul[0];
            break;
            case B:
              return VerdeAzul[1];
            break;
            case R:
              return CodigoVermelho[1];
            break;
          }
    break;
    case P3:
      if(_P3.reset_sensorCor()&&controle==0){_P3.write_bytes_cor100us(cmd1,2);_P3.reset_finalSensorCor();controle=1;}
          delay(64);
          if(_P3.reset_sensorCor()&&controle==1){_P3.write_bytes_cor100us(cmd2,2);_P3.reset_finalSensorCor();_P3.read_bytes_sensorCor(CodigoVermelho, 2);controle=2;}
          if(_P3.reset_sensorCor()&&controle==2){_P3.write_bytes_cor100us(cmd3,2);_P3.reset_finalSensorCor();_P3.read_bytes_sensorCor(VerdeAzul, 2);controle=0;
          }else{return 0;}

          switch (get_) {
            case LIDO:
              return CodigoVermelho[0];
            break;
            case G:
              return VerdeAzul[0];
            break;
            case B:
              return VerdeAzul[1];
            break;
            case R:
              return CodigoVermelho[1];
            break;
          }
    break;
    case P4:
      if(_P4.reset_sensorCor()&&controle==0){_P4.write_bytes_cor100us(cmd1,2);_P4.reset_finalSensorCor();controle=1;}
          delay(64);
          if(_P4.reset_sensorCor()&&controle==1){_P4.write_bytes_cor100us(cmd2,2);_P4.reset_finalSensorCor();_P4.read_bytes_sensorCor(CodigoVermelho, 2);controle=2;}
          if(_P4.reset_sensorCor()&&controle==2){_P4.write_bytes_cor100us(cmd3,2);_P4.reset_finalSensorCor();_P4.read_bytes_sensorCor(VerdeAzul, 2);controle=0;
          }else{return 0;}

          switch (get_) {
            case LIDO:
              return CodigoVermelho[0];
            break;
            case G:
              return VerdeAzul[0];
            break;
            case B:
              return VerdeAzul[1];
            break;
            case R:
              return CodigoVermelho[1];
            break;
          }
    break;

    case P5:
      if(_P5.reset_sensorCor()&&controle==0){_P5.write_bytes_cor100us(cmd1,2);_P5.reset_finalSensorCor();controle=1;}
          delay(64);
          if(_P5.reset_sensorCor()&&controle==1){_P5.write_bytes_cor100us(cmd2,2);_P5.reset_finalSensorCor();_P5.read_bytes_sensorCor(CodigoVermelho, 2);controle=2;}
          if(_P5.reset_sensorCor()&&controle==2){_P5.write_bytes_cor100us(cmd3,2);_P5.reset_finalSensorCor();_P5.read_bytes_sensorCor(VerdeAzul, 2);controle=0;
          }else{return 0;}

          switch (get_) {
            case LIDO:
              return CodigoVermelho[0];
            break;
            case G:
              return VerdeAzul[0];
            break;
            case B:
              return VerdeAzul[1];
            break;
            case R:
              return CodigoVermelho[1];
            break;
          }
    break;

    case P6:
      if(_P6.reset_sensorCor()&&controle==0){_P6.write_bytes_cor100us(cmd1,2);_P6.reset_finalSensorCor();controle=1;}
          delay(64);
          if(_P6.reset_sensorCor()&&controle==1){_P6.write_bytes_cor100us(cmd2,2);_P6.reset_finalSensorCor();_P6.read_bytes_sensorCor(CodigoVermelho, 2);controle=2;}
          if(_P6.reset_sensorCor()&&controle==2){_P6.write_bytes_cor100us(cmd3,2);_P6.reset_finalSensorCor();_P6.read_bytes_sensorCor(VerdeAzul, 2);controle=0;
          }else{return 0;}

          switch (get_) {
            case LIDO:
              return CodigoVermelho[0];
            break;
            case G:
              return VerdeAzul[0];
            break;
            case B:
              return VerdeAzul[1];
            break;
            case R:
              return CodigoVermelho[1];
            break;
          }
    break;

    case P7:
      if(_P7.reset_sensorCor()&&controle==0){_P7.write_bytes_cor100us(cmd1,2);_P7.reset_finalSensorCor();controle=1;}
          delay(64);
          if(_P7.reset_sensorCor()&&controle==1){_P7.write_bytes_cor100us(cmd2,2);_P7.reset_finalSensorCor();_P7.read_bytes_sensorCor(CodigoVermelho, 2);controle=2;}
          if(_P7.reset_sensorCor()&&controle==2){_P7.write_bytes_cor100us(cmd3,2);_P7.reset_finalSensorCor();_P7.read_bytes_sensorCor(VerdeAzul, 2);controle=0;
          }else{return 0;}

          switch (get_) {
            case LIDO:
              return CodigoVermelho[0];
            break;
            case G:
              return VerdeAzul[0];
            break;
            case B:
              return VerdeAzul[1];
            break;
            case R:
              return CodigoVermelho[1];
            break;
          }
    break;

    case P8:
      if(_P8.reset_sensorCor()&&controle==0){_P8.write_bytes_cor100us(cmd1,2);_P8.reset_finalSensorCor();controle=1;}
          delay(64);
          if(_P8.reset_sensorCor()&&controle==1){_P8.write_bytes_cor100us(cmd2,2);_P8.reset_finalSensorCor();_P8.read_bytes_sensorCor(CodigoVermelho, 2);controle=2;}
          if(_P8.reset_sensorCor()&&controle==2){_P8.write_bytes_cor100us(cmd3,2);_P8.reset_finalSensorCor();_P8.read_bytes_sensorCor(VerdeAzul, 2);controle=0;
          }else{return 0;}

          switch (get_) {
            case LIDO:
              return CodigoVermelho[0];
            break;
            case G:
              return VerdeAzul[0];
            break;
            case B:
              return VerdeAzul[1];
            break;
            case R:
              return CodigoVermelho[1];
            break;
          }
    break;

    case PA:
      if(_PA.reset_sensorCor()&&controle==0){_PA.write_bytes_cor100us(cmd1,2);_PA.reset_finalSensorCor();controle=1;}
          delay(64);
          if(_PA.reset_sensorCor()&&controle==1){_PA.write_bytes_cor100us(cmd2,2);_PA.reset_finalSensorCor();_PA.read_bytes_sensorCor(CodigoVermelho, 2);controle=2;}
          if(_PA.reset_sensorCor()&&controle==2){_PA.write_bytes_cor100us(cmd3,2);_PA.reset_finalSensorCor();_PA.read_bytes_sensorCor(VerdeAzul, 2);controle=0;
          }else{return 0;}

          switch (get_) {
            case LIDO:
              return CodigoVermelho[0];
            break;
            case G:
              return VerdeAzul[0];
            break;
            case B:
              return VerdeAzul[1];
            break;
            case R:
              return CodigoVermelho[1];
            break;
          }
    break;

    case PB:
      if(_PB.reset_sensorCor()&&controle==0){_PB.write_bytes_cor100us(cmd1,2);_PB.reset_finalSensorCor();controle=1;}
          delay(64);
          if(_PB.reset_sensorCor()&&controle==1){_PB.write_bytes_cor100us(cmd2,2);_PB.reset_finalSensorCor();_PB.read_bytes_sensorCor(CodigoVermelho, 2);controle=2;}
          if(_PB.reset_sensorCor()&&controle==2){_PB.write_bytes_cor100us(cmd3,2);_PB.reset_finalSensorCor();_PB.read_bytes_sensorCor(VerdeAzul, 2);controle=0;
          }else{return 0;}

          switch (get_) {
            case LIDO:
              return CodigoVermelho[0];
            break;
            case G:
              return VerdeAzul[0];
            break;
            case B:
              return VerdeAzul[1];
            break;
            case R:
              return CodigoVermelho[1];
            break;
          }
    break;

    case PC:
      if(_PC.reset_sensorCor()&&controle==0){_PC.write_bytes_cor100us(cmd1,2);_PC.reset_finalSensorCor();controle=1;}
          delay(64);
          if(_PC.reset_sensorCor()&&controle==1){_PC.write_bytes_cor100us(cmd2,2);_PC.reset_finalSensorCor();_PC.read_bytes_sensorCor(CodigoVermelho, 2);controle=2;}
          if(_PC.reset_sensorCor()&&controle==2){_PC.write_bytes_cor100us(cmd3,2);_PC.reset_finalSensorCor();_PC.read_bytes_sensorCor(VerdeAzul, 2);controle=0;
          }else{return 0;}

          switch (get_) {
            case LIDO:
              return CodigoVermelho[0];
            break;
            case G:
              return VerdeAzul[0];
            break;
            case B:
              return VerdeAzul[1];
            break;
            case R:
              return CodigoVermelho[1];
            break;
          }
    break;

    case PD:
      if(_PD.reset_sensorCor()&&controle==0){_PD.write_bytes_cor100us(cmd1,2);_PD.reset_finalSensorCor();controle=1;}
          delay(64);
          if(_PD.reset_sensorCor()&&controle==1){_PD.write_bytes_cor100us(cmd2,2);_PD.reset_finalSensorCor();_PD.read_bytes_sensorCor(CodigoVermelho, 2);controle=2;}
          if(_PD.reset_sensorCor()&&controle==2){_PD.write_bytes_cor100us(cmd3,2);_PD.reset_finalSensorCor();_PD.read_bytes_sensorCor(VerdeAzul, 2);controle=0;
          }else{return 0;}

          switch (get_) {
            case LIDO:
              return CodigoVermelho[0];
            break;
            case G:
              return VerdeAzul[0];
            break;
            case B:
              return VerdeAzul[1];
            break;
            case R:
              return CodigoVermelho[1];
            break;
          }
    break;
  }
}

uint8_t lerSensor_de_Distancia(byte pin_){
  static uint8_t dist = 0, cmd = 0x13;
  switch(pin_){
    case P1:
      delay(50);if(_P1.reset_ultrassom()){_P1.write_100us(cmd);dist=_P1.read_ultrassom();if(dist == NULL ){return 0;}else{return dist;}}
    break;
    case P2:
      delay(50); if(_P2.reset_ultrassom()){_P2.write_100us(cmd);dist=_P2.read_ultrassom();if(dist == NULL){return 0;}else{return dist;}} 
    break;
    case P3:
      delay(50); if(_P3.reset_ultrassom()){_P3.write_100us(cmd);dist=_P3.read_ultrassom();if(dist == NULL){return 0;}else{return dist;}} 
    break;
    case P4:
      delay(50); if(_P4.reset_ultrassom()){_P4.write_100us(cmd);dist=_P4.read_ultrassom();if(dist == NULL){return 0;}else{return dist;}} 
    break;
    case P5:
      delay(50); if(_P5.reset_ultrassom()){_P5.write_100us(cmd);dist=_P5.read_ultrassom();if(dist == NULL){return 0;}else{return dist;}} 
    break;
    case P6:
      delay(50); if(_P6.reset_ultrassom()){_P6.write_100us(cmd);dist=_P6.read_ultrassom();if(dist == NULL){return 0;}else{return dist;}} 
    break;
    case P7:
      delay(50); if(_P7.reset_ultrassom()){_P7.write_100us(cmd);dist=_P7.read_ultrassom();if(dist == NULL){return 0;}else{return dist;}} 
    break;
    case P8:
      delay(50); if(_P8.reset_ultrassom()){_P8.write_100us(cmd);dist=_P8.read_ultrassom();if(dist == NULL){return 0;}else{return dist;}} 
    break;
    case PA:
      delay(50); if(_PA.reset_ultrassom()){_PA.write_100us(cmd);dist=_PA.read_ultrassom();if(dist == NULL){return 0;}else{return dist;}} 
    break;
    case PB:
      delay(50); if(_PB.reset_ultrassom()){_PB.write_100us(cmd);dist=_PB.read_ultrassom();if(dist == NULL){return 0;}else{return dist;}} 
    break;
    case PC:
      delay(50); if(_PC.reset_ultrassom()){_PC.write_100us(cmd);dist=_PC.read_ultrassom();if(dist == NULL){return 0;}else{return dist;}} 
    break;
    case PD:
      delay(50); if(_PD.reset_ultrassom()){_PD.write_100us(cmd);dist=_PD.read_ultrassom();if(dist == NULL){return 0;}else{return dist;}} 
    break;
  }
}

uint16_t lerSensor_de_Toque(byte pin){

  switch (pin) {
    case P1:
      return analogRead(A3);
    break;
    case P2:
      return analogRead(A4);
    break;
    case P3:
      return analogRead(A5);
    break;
    case P4:
      return analogRead(A6);
    break;
    case P5:
      return analogRead(A15);
    break;
    case P6:
      return analogRead(A12);
    break;
    case P7:
      return analogRead(A13);
    break;
    case P8:
      return analogRead(A14);
    break;
    case PA:
      return analogRead(A8);
    break;
    case PB:
      return analogRead(A9);
    break;
    case PC:
      return analogRead(A10);
    break;
    case PD:
      return analogRead(A11);
    break;
  }
}



void definir_o_Led(byte pin,boolean status){
  static boolean  flagP1Branco=false,flagP1Azul=false,
                  flagP2Branco=false,flagP2Azul=false,
                  flagP3Branco=false,flagP3Azul=false,
                  flagP4Branco=false,flagP4Azul=false,
                  flagP5Branco=false,flagP5Azul=false,
                  flagP6Branco=false,flagP6Azul=false,
                  flagP7Branco=false,flagP7Azul=false,
                  flagP8Branco=false,flagP8Azul=false,
                  flagPABranco=false,flagPAAzul=false,
                  flagPBBranco=false,flagPBAzul=false,
                  flagPCBranco=false,flagPCAzul=false,
                  flagPDBranco=false,flagPDAzul=false;

  switch (pin) {
    case P1_BRANCO:
      if(!flagP1Branco){pinMode(P1_BRANCO,OUTPUT);  flagP1Branco=true;}
      digitalWrite(P1_BRANCO, status);      
    break;
    case P1_AZUL:
      if(!flagP1Azul){pinMode(P1_AZUL,OUTPUT);  flagP1Azul=true;}
      digitalWrite(P1_AZUL, status);      
    break;

    case P2_BRANCO:
      if(!flagP2Branco){pinMode(P2_BRANCO,OUTPUT);  flagP2Branco=true;}
      digitalWrite(P2_BRANCO, status);      
    break;
    case P2_AZUL:
      if(!flagP2Azul){pinMode(P2_AZUL,OUTPUT);  flagP2Azul=true;}
      digitalWrite(P2_AZUL, status);      
    break;

    case P3_BRANCO:
      if(!flagP3Branco){pinMode(P3_BRANCO,OUTPUT);  flagP3Branco=true;}
      digitalWrite(P3_BRANCO, status);      
    break;
    case P3_AZUL:
      if(!flagP3Azul){pinMode(P3_AZUL,OUTPUT);  flagP3Azul=true;}
      digitalWrite(P3_AZUL, status);      
    break;

    case P4_BRANCO:
      if(!flagP4Branco){pinMode(P4_BRANCO,OUTPUT);  flagP4Branco=true;}
      digitalWrite(P4_BRANCO, status);      
    break;
    case P4_AZUL:
      if(!flagP4Azul){pinMode(P4_AZUL,OUTPUT);  flagP4Azul=true;}
      digitalWrite(P4_AZUL, status);      
    break;

    case P5_BRANCO:
      if(!flagP5Branco){pinMode(P5_BRANCO,OUTPUT);  flagP5Branco=true;}
      digitalWrite(P5_BRANCO, status);      
    break;
    case P5_AZUL:
      if(!flagP5Azul){pinMode(P5_AZUL,OUTPUT);  flagP5Azul=true;}
      digitalWrite(P5_AZUL, status);      
    break;

    case P6_BRANCO:
      if(!flagP6Branco){pinMode(P6_BRANCO,OUTPUT);  flagP6Branco=true;}
      digitalWrite(P6_BRANCO, status);      
    break;
    case P6_AZUL:
      if(!flagP6Azul){pinMode(P6_AZUL,OUTPUT);  flagP6Azul=true;}
      digitalWrite(P6_AZUL, status);      
    break;

    case P7_BRANCO:
      if(!flagP7Branco){pinMode(P7_BRANCO,OUTPUT);  flagP7Branco=true;}
      digitalWrite(P7_BRANCO, status);      
    break;
    case P7_AZUL:
      if(!flagP7Azul){pinMode(P7_AZUL,OUTPUT);  flagP7Azul=true;}
      digitalWrite(P7_AZUL, status);      
    break;

    case P8_BRANCO:
      if(!flagP8Branco){pinMode(P8_BRANCO,OUTPUT);  flagP8Branco=true;}
      digitalWrite(P8_BRANCO, status);      
    break;
    case P8_AZUL:
      if(!flagP8Azul){pinMode(P8_AZUL,OUTPUT);  flagP8Azul=true;}
      digitalWrite(P8_AZUL, status);      
    break;

    case PA_BRANCO:
      if(!flagPABranco){pinMode(PA_BRANCO,OUTPUT);  flagPABranco=true;}
      digitalWrite(PA_BRANCO, status);      
    break;
    case PA_AZUL:
      if(!flagPAAzul){pinMode(PA_AZUL,OUTPUT);  flagPAAzul=true;}
      digitalWrite(PA_AZUL, status);      
    break;

    case PB_BRANCO:
      if(!flagPBBranco){pinMode(PB_BRANCO,OUTPUT);  flagPBBranco=true;}
      digitalWrite(PB_BRANCO, status);      
    break;
    case PB_AZUL:
      if(!flagPBAzul){pinMode(PB_AZUL,OUTPUT);  flagPBAzul=true;}
      digitalWrite(PB_AZUL, status);      
    break;

    case PC_BRANCO:
      if(!flagPCBranco){pinMode(PC_BRANCO,OUTPUT);  flagPCBranco=true;}
      digitalWrite(PC_BRANCO, status);      
    break;
    case PC_AZUL:
      if(!flagPCAzul){pinMode(PC_AZUL,OUTPUT);  flagPCAzul=true;}
      digitalWrite(PC_AZUL, status);      
    break;

    case PD_BRANCO:
      if(!flagPDBranco){pinMode(PD_BRANCO,OUTPUT);  flagPDBranco=true;}
      digitalWrite(PD_BRANCO, status);      
    break;
    case PD_AZUL:
      if(!flagPDAzul){pinMode(PD_AZUL,OUTPUT);  flagPDAzul=true;}
      digitalWrite(PD_AZUL, status);      
    break;
  }
}

boolean ler_status_do_Led(byte pin){
  switch (pin) {
    case P1_BRANCO:  return digitalRead(P1_BRANCO); break;
    case P1_AZUL:    return digitalRead(P1_AZUL);   break;

    case P2_BRANCO:  return digitalRead(P2_BRANCO); break;
    case P2_AZUL:    return digitalRead(P2_AZUL);   break;

    case P3_BRANCO:  return digitalRead(P3_BRANCO); break;
    case P3_AZUL:    return digitalRead(P3_AZUL); break;

    case P4_BRANCO:  return digitalRead(P4_BRANCO); break;
    case P4_AZUL:    return digitalRead(P4_AZUL); break;

    case P5_BRANCO:  return digitalRead(P5_BRANCO); break;
    case P5_AZUL:    return digitalRead(P5_AZUL); break;

    case P6_BRANCO:  return digitalRead(P6_BRANCO); break;
    case P6_AZUL:    return digitalRead(P6_AZUL); break;

    case P7_BRANCO:  return digitalRead(P7_BRANCO); break;
    case P7_AZUL:    return digitalRead(P7_AZUL); break;

    case P8_BRANCO:  return digitalRead(P8_BRANCO); break;
    case P8_AZUL:    return digitalRead(P8_AZUL); break;

    case PA_BRANCO:  return digitalRead(PA_BRANCO); break;
    case PA_AZUL:    return digitalRead(PA_AZUL); break;

    case PB_BRANCO:  return digitalRead(PB_BRANCO); break;
    case PB_AZUL:    return digitalRead(PB_AZUL); break;

    case PC_BRANCO:  return digitalRead(PC_BRANCO); break;
    case PC_AZUL:    return digitalRead(PC_AZUL); break;

    case PD_BRANCO:  return digitalRead(PD_BRANCO); break;
    case PD_AZUL:    return digitalRead(PD_AZUL); break;
  }
}
