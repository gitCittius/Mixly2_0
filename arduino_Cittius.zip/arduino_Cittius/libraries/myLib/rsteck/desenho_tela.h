// COMANDOS PARA DESENHO EM TELA

// tft.drawRect(X_INICIAL, Y_INICIAL,COMPRIMENTO, LARGURA, COR);              // DESENHA UM RETANGULO EM LINHA
// tft.fillRect(X_INICIAL, Y_INICIAL, COMPRIMENTO, LARGURA, COR);             // DESENHA UM RETANGULO COM PREENCHIMENTO
// tft.drawCircle(x, y, radius, color);                                       // DESENHA UM CIRCULOO EM LINHA
// tft.fillCircle(x, y, radius, color);                                       // DESENHA UM CIRCULO COM PREENCHIMENTO
// tft.drawRoundRect(X_INICIAL, Y_INICIAL, COMPRIMENTO, LARGURA, RAIO, COR);  // DESENHA UM RETANGULO EM LINHA COM CANTO RAIADO
// tft.fillRoundRect(X_INICIAL, Y_INICIAL, COMPRIMENTO, LARGURA, RAIO, COR);  // DESENHA UM RETANGULO COM PREENCHIMENTO COM CANTO RAIADO
// tft.drawLine(X_INICIAL, Y_INICIAL, X_FINAL, Y_FINAL, COR);                 // DESENHA UM RETANGULO EM LINHA
// tft.drawFastHLine(0, y, w, COR);
// tft.drawFastVLine(x, 0, h, COR);

#include <TFT_eSPI.h> // Hardware-specific library
#include <SPI.h>
#include <OneButton.h>
#include <NewTone.h>

//Display ILI9341
#define tft_cs             34
#define tft_dc             33
//#define tft_touch          43

//Declaração de Objetos
//Adafruit_ILI9341 tft = Adafruit_ILI9341(tft_cs, tft_dc);
TFT_eSPI tft = TFT_eSPI(); 

//Definição de cores ILI9341
#define  F ILI9341_BLACK       //<   0,   0,   0
#define AZUL ILI9341_BLUE         //<   0,   0, 255
#define VERMELHO ILI9341_RED      //< 255,   0,   0
#define VERDE ILI9341_GREEN       //<   0, 255,   0
#define AMARELO ILI9341_YELLOW    //< 255, 255,   0
#define BRANCO ILI9341_WHITE      //< 255, 255, 255
#define ROSA ILI9341_PINK         //< 255, 130, 198
#define COR_DE_FUNDO 0x000066
#define CINZA 0x7BEF
#define VERDE_ESCURO 0x0400 

OneButton button49(49,true);
OneButton button38(38,true);
OneButton button47(47,true);
OneButton button48(48,true);


byte menu;
byte control_motor=1;
byte control_sensor=0;
boolean menu_main;
boolean test_programa;
boolean test_motor;
boolean test_sensor;
boolean m1_test;
boolean m2_test;
boolean m3_test;
boolean m4_test;
boolean setupCittius = false;
boolean flagEncoder =false;
int velocidade;
int velocidadeM1;
int velocidadeM2;
int velocidadeM3;
int velocidadeM4;
char buff[150];
boolean flagEnableSound = true;

unsigned long previousMillis = 0;  // will store last time LED was updated
unsigned long previousMillis1 = 0;  // will store last time LED was updated
// constants won't change:
const long interval = 260;    
const long interval1 = 1500;      


const int numReadings  = 10;
int readings [numReadings];
int readIndex  = 0;
long total  = 0;

//Variables
int aisVal  = 0;

long mediaMovelUtrassonic6() { /* function smooth */
  ////Perform average on sensor readings
  long average;
  // subtract the last reading:
  total = total - readings[readIndex];
  // read the sensor:
  readings[readIndex] = getSensorUtrasson(6);
  // add value to total:
  total = total + readings[readIndex];
  // handle index
  readIndex = readIndex + 1;
  if (readIndex >= numReadings) {
    readIndex = 0;
  }
  // calculate the average:
  average = total / numReadings;

  return average;
}

//*****************************************************************************************//
//                        IMPRIME TEXTO
//*****************************************************************************************//

void printNumero(int value,byte qtd,unsigned xpos,unsigned ypos,byte font){

if(value>=0){
  if(qtd == 2){
    snprintf(buff, sizeof(buff), "  %02d", (int)value);
    tft.drawString(buff, xpos, ypos,font);    
  } else if(qtd == 3){
    snprintf(buff, sizeof(buff), "  %03d", (int)value);
    tft.drawString(buff, xpos, ypos,font);    
  }else if(qtd == 4){
    snprintf(buff, sizeof(buff), "  %04d", (int)value);
    tft.drawString(buff, xpos, ypos,font);    
  }else if(qtd == 5){
    snprintf(buff, sizeof(buff), "  %05d", (int)value);
    tft.drawString(buff, xpos, ypos,font);    
  }else if(qtd == 6){
    snprintf(buff, sizeof(buff), "  %06d", (int)value);
    tft.drawString(buff, xpos, ypos,font);    
  }  
}else{
   if(qtd == 2){
    snprintf(buff, sizeof(buff), "%03d ", (int)value);
    tft.drawString(buff, xpos, ypos,font);    
  } else if(qtd == 3){
    snprintf(buff, sizeof(buff), "%04d ", (int)value);
    tft.drawString(buff, xpos, ypos,font);    
  }else if(qtd == 4){
    snprintf(buff, sizeof(buff), "%05d ", (int)value);
    tft.drawString(buff, xpos, ypos,font);    
  }else if(qtd == 5){
    snprintf(buff, sizeof(buff), "%06d ", (int)value);
    tft.drawString(buff, xpos, ypos,font);    
  }else if(qtd == 6){
    snprintf(buff, sizeof(buff), "%07d ", (int)value);
    tft.drawString(buff, xpos, ypos,font);    
  }  
}

}

void printTexto(String text, uint16_t color, int x, int y,int textSize)
{
  tft.setCursor(x, y);
  tft.setTextColor(color);
  tft.setTextSize(textSize);
  tft.setTextWrap(true);
  tft.print(text);
}
void printTexto(int text, uint16_t color, int x, int y,int textSize)
{
  tft.setCursor(x, y);
  tft.setTextColor(color);
  tft.setTextSize(textSize);
  tft.setTextWrap(true);
  tft.print(text);
}

void attachClick47() {



  if (menu_main == true) {
    menu--;
    if(flagEnableSound){NewTone(26,659,120);}
    if (menu == 255) {
      menu = 0;
    }
   
  } else if (test_motor == true) {
    control_motor--;

    if(flagEnableSound){NewTone(26,659,120);}


    if (control_motor == 255) {  
      control_motor = 0;
    }
    
  }else if (test_sensor == true) {
    control_sensor--;
    if (control_sensor == 255) {
      control_sensor = 0;
    }
    
  } else if (m1_test == true) {
    velocidadeM1 = velocidadeM1 + 10;

    if(flagEnableSound){NewTone(26,659,120);}

    if (velocidadeM1 >= 100) {
      velocidadeM1 = 100;
    }
    tft.fillRoundRect(6, 60, 233, 39, 6, CINZA);
    tft.setTextColor(TFT_WHITE, CINZA);
    tft.drawString("A",12,69,4);
    tft.setTextColor(TFT_WHITE, CINZA);
    printNumero(velocidadeM1,3,65,69,4);
    printNumero(getCodePin(m1),6,130,69,4);
  }else if (m2_test == true) {
    velocidadeM2 = velocidadeM2 + 10;

    if(flagEnableSound){NewTone(26,659,120);}

    if (velocidadeM2 >= 100) {
      velocidadeM2 = 100;
    }
    tft.fillRoundRect(6, 110, 233, 39, 6, CINZA);
    tft.setTextColor(TFT_WHITE, CINZA);
    tft.drawString("B",12,119,4);
    tft.setTextColor(TFT_WHITE, CINZA);
    printNumero(velocidadeM2,3,65,119,4);
    printNumero(getCodePin(m2),6,130,119,4);
  }else if (m3_test == true) {
    velocidadeM3 = velocidadeM3 + 10;

    if(flagEnableSound){NewTone(26,659,120);}

    if (velocidadeM3 >= 100) {
      velocidadeM3 = 100;
    }
    tft.fillRoundRect(6, 160, 233, 39, 6, CINZA);
    tft.setTextColor(TFT_WHITE, CINZA);
    tft.drawString("C",12,169,4);
    tft.setTextColor(TFT_WHITE, CINZA);
    printNumero(velocidadeM3,3,65,169,4);
    printNumero(getCodePin(m3),6,130,169,4);
  }else if (m4_test == true) {
    velocidadeM4 = velocidadeM4 + 10;

    if(flagEnableSound){NewTone(26,659,120);}

    if (velocidadeM4 >= 100) {
      velocidadeM4 = 100;
    }
    tft.fillRoundRect(6, 210, 233, 39, 6, CINZA);
    tft.setTextColor(TFT_WHITE, CINZA);
    tft.drawString("D",12,219,4);
    tft.setTextColor(TFT_WHITE, CINZA);
    printNumero(velocidadeM4,3,65,219,4);
    printNumero(getCodePin(m4),6,130,219,4);
  }
}

void attachClick38() {

  if (menu_main == true) {
    menu++;
    if(flagEnableSound){NewTone(26,659,120);}
    if (menu >= 2) {menu = 2;}
   
  } else if (test_motor == true) {
    control_motor++;

    if(flagEnableSound){NewTone(26,659,120);}

    if (control_motor >= 4) {
      control_motor = 4;
    }
  
  }else if (test_sensor == true) {
    control_sensor++;
    
    if (control_sensor >= 4) {
      control_sensor = 4;
    }
  } else if (m1_test == true) {
    velocidadeM1 = velocidadeM1 - 10;

    if(flagEnableSound){NewTone(26,659,120);}

    if (velocidadeM1 <= (-100)) {
      velocidadeM1 = -100;

    }
      tft.fillRoundRect(6, 60, 233, 39, 6, CINZA);
      tft.setTextColor(TFT_WHITE, CINZA);
      tft.drawString("A",12,69,4);
      tft.setTextColor(TFT_WHITE, CINZA);
      printNumero(velocidadeM1,3,65,69,4);
      printNumero(getCodePin(m1),6,130,69,4);
  }else if (m2_test == true) {
    velocidadeM2 = velocidadeM2 - 10;

    if(flagEnableSound){NewTone(26,659,120);}

    if (velocidadeM2 <= (-100)) {
      velocidadeM2 = -100;

    }
      tft.fillRoundRect(6, 110, 233, 39, 6, CINZA);
      tft.setTextColor(TFT_WHITE, CINZA);
      tft.drawString("B",12,119,4);
      tft.setTextColor(TFT_WHITE, CINZA);
      printNumero(velocidadeM2,3,65,119,4);
       printNumero(getCodePin(m2),6,130,119,4);
  }else if (m3_test == true) {
    velocidadeM3 = velocidadeM3 - 10;

    if(flagEnableSound){NewTone(26,659,120);}

    if (velocidadeM3 <= (-100)) {
      velocidadeM3 = -100;

    }
      tft.fillRoundRect(6, 160, 233, 39, 6, CINZA);
      tft.setTextColor(TFT_WHITE, CINZA);
      tft.drawString("C",12,169,4);
      tft.setTextColor(TFT_WHITE, CINZA);
      printNumero(velocidadeM3,3,65,169,4);
      printNumero(getCodePin(m3),6,130,169,4);
  }else if (m4_test == true) {
    velocidadeM4 = velocidadeM4 - 10;

    if(flagEnableSound){NewTone(26,659,120);}

    if (velocidadeM4 <= (-100)) {
      velocidadeM4 = -100;

    }
      tft.fillRoundRect(6, 210, 233, 39, 6, CINZA);
      tft.setTextColor(TFT_WHITE, CINZA);
      tft.drawString("D",12,219,4);
      tft.setTextColor(TFT_WHITE, CINZA);
      printNumero(velocidadeM4,3,65,219,4);
      printNumero(getCodePin(m4),6,130,219,4);
  }
}

void attachClick48() {
  if(!test_programa){
    switch (menu) {
    case 0:
      test_programa = false;
      menu_main = true;
      test_motor = false;
      break;
    case 1:

      tft.fillRoundRect(6, 60, 233, 39, 6, COR_DE_FUNDO);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      tft.drawString("A",12,69,4);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      printNumero(velocidadeM1,3,65,69,4);
      printNumero(getCodePin(m1),6,130,69,4);

      tft.fillRoundRect(6, 110, 233, 39, 6, COR_DE_FUNDO);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      tft.drawString("B",12,119,4);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      printNumero(velocidadeM2,3,65,119,4);
      printNumero(getCodePin(m2),6,130,119,4);

      tft.fillRoundRect(6, 160, 233, 39, 6, COR_DE_FUNDO);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      tft.drawString("C",12,169,4);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      printNumero(velocidadeM3,3,65,169,4);
      printNumero(getCodePin(m3),6,130,169,4);

      tft.fillRoundRect(6, 210, 233, 39, 6, COR_DE_FUNDO);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      tft.drawString("D",12,219,4);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      printNumero(velocidadeM4,3,65,219,4);
      printNumero(getCodePin(m4),6,130,219,4);


     // m1_test = false;
     // m2_test = false;
     // m3_test = false;
     // m4_test = false;
      test_motor = true;
      break;
  }
  }
}










//*****************************************************************************************//
//                      DESENHO DO MENU INICIAL
//*****************************************************************************************//
void TELA_MENU(){

    tft.setRotation(2);
    tft.drawLine(0, 30, 240, 30, BRANCO);             // DESENHA UMA LINHA PARA O MENU
    tft.fillRect(3,6,105,21,COR_DE_FUNDO);                   // APAGA O SETOR DO DISPLAY PARA NOVA ESCRITA
    printTexto("MENU", BRANCO,8,9,2);

    tft.drawRect(196, 6, 31, 18, BRANCO);             // DESENHA A BATERIA
    tft.fillRect(227,11,3,8,BRANCO);
    printTexto("%", BRANCO,219,11,1);

    tft.fillRect(0,37,240,281,COR_DE_FUNDO);                   // APAGA O SETOR DO DISPLAY PARA NOVA ESCRITA

    tft.fillRoundRect(20, 60, 200, 40, 6, CINZA);
    tft.drawRoundRect(19, 59, 201, 41, 6, VERDE);
    tft.setTextColor(BRANCO);
    tft.drawString("PROGRAMACAO",22,68,4);

    tft.fillRoundRect(20, 110, 200, 40, 6, CINZA);
    tft.drawRoundRect(19, 109, 201, 41, 6, VERMELHO);
    tft.setTextColor(BRANCO);
    tft.drawString("MOTORES",56,118,4);

    tft.fillRoundRect(20, 160, 200, 40, 6, CINZA);
    tft.drawRoundRect(19, 159, 201, 41, 6, VERMELHO);
    tft.setTextColor(BRANCO);
    tft.drawString("SENSORES",50,168,4);

    printTexto("<-Enter", BRANCO,5,270,2); 
     printTexto("<-Voltar", BRANCO,5,300,2); 

    printTexto("Mais->", BRANCO,155,270,2); 
     printTexto("Menos->", BRANCO,155,300,2);
     /*
    tft.fillRoundRect(20, 160, 200, 40, 6, CINZA);
    tft.drawRoundRect(19, 159, 201, 41, 6, VERMELHO);
    tft.setTextColor(BRANCO);
    tft.drawString("TOQUE",64,168,4);

    tft.fillRoundRect(20, 210, 200, 40, 6, CINZA);
    tft.drawRoundRect(19, 209, 201, 41, 6, VERMELHO);
    tft.setTextColor(BRANCO);
    tft.drawString("UTRASSONICO",32,218,4);

    tft.fillRoundRect(16, 260, 208, 40, 6, CINZA);
    tft.drawRoundRect(15, 259, 209, 41, 6, VERMELHO);
    tft.setTextColor(BRANCO);
    tft.drawString("SENSOR DE COR",20,268,4);
    */
  
}


//*****************************************************************************************//
//                      DESENHO DA TELA LEITURA DE CARD
//*****************************************************************************************//
void TELA_CARD(){

    tft.setRotation(2);
    tft.fillRect(3,6,105,21,COR_DE_FUNDO);                 // APAGA O SETOR DO DISPLAY PARA NOVA ESCRITA
    printTexto("LER CARD", BRANCO,8,9,2);  
}


//*****************************************************************************************//
//                      ATUALIZA O VALOR DA BATERIA
//*****************************************************************************************//
void BAT(int a ){

    tft.fillRect(199,10,17,9,COR_DE_FUNDO);
    tft.setCursor(199, 11);
    tft.setTextColor(BRANCO);
    tft.setTextSize(1);
    tft.setTextWrap(true);
    tft.print(a);  
}

//*****************************************************************************************//
//                        FUNÇÃO PARA SEQUENCIA DO CARTÃO
//*****************************************************************************************//
void seq_cartao_tft(byte b, String a){

  tft.setCursor(9, (40+(20*b)));
  tft.setTextColor(BRANCO);  
  tft.setTextSize(2);
  tft.println(a);
}

void buttonMenu(){
  if (menu_main == true) {
   switch (menu) {
   case 0:
    tft.drawRoundRect(19, 59, 201, 41, 6, VERDE);
    tft.drawRoundRect(19, 109, 201, 41, 6, VERMELHO);
   // tft.drawRoundRect(19, 159, 201, 41, 6, VERMELHO);
   // tft.drawRoundRect(19, 159, 201, 41, 6, VERMELHO);
   // tft.drawRoundRect(19, 209, 201, 41, 6, VERMELHO);
   // tft.drawRoundRect(15, 259, 209, 41, 6, VERMELHO);

   break;
   case 1:
    tft.drawRoundRect(19, 59, 201, 41, 6, VERMELHO);
    tft.drawRoundRect(19, 109, 201, 41, 6, VERDE);
    tft.drawRoundRect(19, 159, 201, 41, 6, VERMELHO);
//tft.drawRoundRect(19, 159, 201, 41, 6, VERMELHO);
  ///  tft.drawRoundRect(19, 209, 201, 41, 6, VERMELHO);
  //  tft.drawRoundRect(15, 259, 209, 41, 6, VERMELHO);   
   break;
   case 2:
    tft.drawRoundRect(19, 59, 201, 41, 6, VERMELHO);
    tft.drawRoundRect(19, 109, 201, 41, 6, VERMELHO);
    tft.drawRoundRect(19, 159, 201, 41, 6, VERDE);
   // tft.drawRoundRect(19, 159, 201, 41, 6, VERMELHO);
   // tft.drawRoundRect(19, 209, 201, 41, 6, VERMELHO);
   // tft.drawRoundRect(15, 259, 209, 41, 6, VERMELHO);   
   break;
   case 3:
    tft.drawRoundRect(19, 59, 201, 41, 6, VERMELHO);
    tft.drawRoundRect(19, 109, 201, 41, 6, VERMELHO);
    tft.drawRoundRect(19, 159, 201, 41, 6, VERMELHO);
    tft.drawRoundRect(19, 159, 201, 41, 6, VERDE);
    tft.drawRoundRect(19, 209, 201, 41, 6, VERMELHO);
    tft.drawRoundRect(15, 259, 209, 41, 6, VERMELHO);   
   break;
   case 4:
    tft.drawRoundRect(19, 59, 201, 41, 6, VERMELHO);
    tft.drawRoundRect(19, 109, 201, 41, 6, VERMELHO);
    tft.drawRoundRect(19, 159, 201, 41, 6, VERMELHO);
    tft.drawRoundRect(19, 159, 201, 41, 6, VERMELHO);
    tft.drawRoundRect(19, 209, 201, 41, 6, VERDE);
    tft.drawRoundRect(15, 259, 209, 41, 6, VERMELHO);   
   break;
   case 5:
    tft.drawRoundRect(19, 59, 201, 41, 6, VERMELHO);
    tft.drawRoundRect(19, 109, 201, 41, 6, VERMELHO);
    tft.drawRoundRect(19, 159, 201, 41, 6, VERMELHO);
    tft.drawRoundRect(19, 159, 201, 41, 6, VERMELHO);
    tft.drawRoundRect(19, 209, 201, 41, 6, VERMELHO);
    tft.drawRoundRect(15, 259, 209, 41, 6, VERDE);   
   break;
   }
  }
}

void telaProgramao(){
  if(test_programa){
    tft.setRotation(2);
    tft.drawLine(0, 30, 240, 30, BRANCO);             // DESENHA UMA LINHA PARA O MENU
    tft.fillRect(3,6,105,21,COR_DE_FUNDO);                   // APAGA O SETOR DO DISPLAY PARA NOVA ESCRITA
    printTexto("PROGRAMA", BRANCO,8,9,2);

    tft.drawRect(196, 6, 31, 18, BRANCO);             // DESENHA A BATERIA
    tft.fillRect(227,11,3,8,BRANCO);
    printTexto("%", BRANCO,219,11,1);

    tft.fillRect(0,37,240,281,COR_DE_FUNDO);                   // APAGA O SETOR DO DISPLAY PARA NOVA ESCRITA    
    
    tft.drawLine(0, 298, 240, 298, BRANCO);
    printTexto("<- Pressione por 4s para sair", VERMELHO,5,305,1); 
  }
}

void telaMotores(){
  if(test_motor){
    tft.setRotation(2);
    tft.drawLine(0, 30, 240, 30, BRANCO);             // DESENHA UMA LINHA PARA O MENU
    tft.fillRect(3,6,105,21,COR_DE_FUNDO);                   // APAGA O SETOR DO DISPLAY PARA NOVA ESCRITA
    printTexto("MOTORES", BRANCO,8,9,2);

    tft.drawRect(196, 6, 31, 18, BRANCO);             // DESENHA A BATERIA
    tft.fillRect(227,11,3,8,BRANCO);
    printTexto("%", BRANCO,219,11,1);

    tft.fillRect(0,37,240,281,COR_DE_FUNDO);                   // APAGA O SETOR DO DISPLAY PARA NOVA ESCRITA 

               
    printTexto("PORTA", BRANCO,12,50,1);
    //tft.drawString("PORTA", 12, 20,2);
    printTexto("VELOCIDADE", BRANCO,65,50,1);
    printTexto("ENCODER", BRANCO,152,50,1);


      tft.fillRoundRect(6, 60, 233, 39, 6, COR_DE_FUNDO);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      tft.drawString("A",12,69,4);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      printNumero(velocidadeM1,3,65,69,4);
      printNumero(getCodePin(m1),6,130,69,4);

      tft.fillRoundRect(6, 110, 233, 39, 6, COR_DE_FUNDO);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      tft.drawString("B",12,119,4);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      printNumero(velocidadeM2,3,65,119,4);
      printNumero(getCodePin(m2),6,130,119,4);

      tft.fillRoundRect(6, 160, 233, 39, 6, COR_DE_FUNDO);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      tft.drawString("C",12,169,4);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      printNumero(velocidadeM3,3,65,169,4);
      printNumero(getCodePin(m3),6,130,169,4);

      tft.fillRoundRect(6, 210, 233, 39, 6, COR_DE_FUNDO);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      tft.drawString("D",12,219,4);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      printNumero(velocidadeM4,3,65,219,4);
      printNumero(getCodePin(m4),6,130,219,4);

      printTexto("<-Enter", BRANCO,5,270,2); 
      printTexto("<-Voltar", BRANCO,5,300,2); 

      printTexto("Menos->", BRANCO,155,270,2); 
      printTexto("Mais->", BRANCO,155,300,2);
   
    switch(control_motor){
      case 0:
          tft.drawRoundRect(5, 59, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 109, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 159, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 209, 235, 41, 6, VERMELHO);
      break;
      case 1:
          tft.drawRoundRect(5, 59, 235, 41, 6, VERDE);
          tft.drawRoundRect(5, 109, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 159, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 209, 235, 41, 6, VERMELHO);
      break;
      case 2:
          tft.drawRoundRect(5, 59, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 109, 235, 41, 6, VERDE);
          tft.drawRoundRect(5, 159, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 209, 235, 41, 6, VERMELHO);
      break;
      case 3:
          tft.drawRoundRect(5, 59, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 109, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 159, 235, 41, 6, VERDE);
          tft.drawRoundRect(5, 209, 235, 41, 6, VERMELHO);
      break;
      case 4:
          tft.drawRoundRect(5, 59, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 109, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 159, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 209, 235, 41, 6, VERDE);
      break;
    }
  }
}

void telaSensores(){
  Serial.println(menu);
  if(test_sensor){
    tft.setRotation(2);
    tft.drawLine(0, 30, 240, 30, BRANCO);             // DESENHA UMA LINHA PARA O MENU
    tft.fillRect(3,6,105,21,COR_DE_FUNDO);                   // APAGA O SETOR DO DISPLAY PARA NOVA ESCRITA
    printTexto("SENSORES 1", BRANCO,8,9,2);

    tft.drawRect(196, 6, 31, 18, BRANCO);             // DESENHA A BATERIA
    tft.fillRect(227,11,3,8,BRANCO);
    printTexto("%", BRANCO,219,11,1);

    tft.fillRect(0,37,240,281,COR_DE_FUNDO);                   // APAGA O SETOR DO DISPLAY PARA NOVA ESCRITA 

    tft.drawRoundRect(5, 35, 230, 86, 6, VERMELHO);
    printTexto("Sensor de Toque", BRANCO,32,40,2);          
    
    tft.drawRoundRect(5, 126, 230, 86, 6, AMARELO);
    tft.drawRoundRect(60, 149, 42, 42, 6, BRANCO);
    tft.drawRoundRect(121, 149, 42, 42, 6, BRANCO);

    printTexto("Sensor de Cor", BRANCO,36,130,2); 
    printTexto(" 5", BRANCO,67,193,2);
    printTexto(" 7", BRANCO,130,193,2);

    tft.drawRoundRect(5, 217, 230, 86, 6, VERDE_ESCURO);
    printTexto("Sensor de Distancia", BRANCO,7,220,2); 
  }
}

//*****************************************************************************************//
//            ---------- FUNÇÃO PARA FILTRO DA ENTRADA ANALÓGICA -----------
//*****************************************************************************************//
int Filtro_Analog(int porta, int amostra, int diferenca){    // GERALMENTE USA 15 PARA AMOSTRA, 8 PARA DIFERENÇA
 
    int reads = 0;
    int lastread = 0;
    int correntread = 0;
      
    for(int ii=0;ii<amostra;ii++){      
        reads+=analogRead(porta);      
    }
      
    correntread=reads/amostra;
      
    if((abs(correntread - lastread))>diferenca){      
        lastread=correntread;      
    } 
    
  return lastread;
}

boolean clearTFT = false;
void telaSemafaro(unsigned L_VERDE,unsigned L_AMARELO,unsigned L_VERMELHO){
  if(!clearTFT){
    tft.fillScreen(BRANCO);
    tft.fillRect(70,120,100,160,COR_DE_FUNDO);
    tft.fillRect(115,240,30,160,BRANCO);
    clearTFT=true;
  }
  
}
  

void attachClick49() {

  switch (menu) {
   case 0:
   

   if(!test_programa){

    if(flagEnableSound){NewTone(26,349,120);}

    tft.fillRect(0,0,240,320,COR_DE_FUNDO);                   // APAGA O SETOR DO DISPLAY PARA NOVA ESCRITA
    test_programa = true;
    menu_main = false;
    telaProgramao(); 
    C_BAT = map(Filtro_Analog(V_Bat,15,10),0,1023,0,100);
    BAT(C_BAT);    
   }
    break;
   case 1:
    if(flagEnableSound){NewTone(26,349,120);}
    tft.fillRect(0,0,240,320,COR_DE_FUNDO);
    test_motor = true;
    menu_main = false;
    telaMotores();
    C_BAT = map(Filtro_Analog(V_Bat,15,10),0,1023,0,100);
    BAT(C_BAT);
    break;
   case 2:

    test_sensor = true;
    test_motor = false;
    menu_main = false;
    test_programa = false;
    telaSensores();
    break;
   case 3:
 
    menu_main = false;
    break;
  }

  if (test_motor == true) { 
    switch (control_motor) {
     case 1:
      m1_test = true;
      m2_test = false;
      m4_test = false;
      m4_test = false;
      test_motor = false;
      tft.fillRoundRect(6, 60, 233, 39, 6, CINZA);
      tft.setTextColor(TFT_WHITE, CINZA);
      tft.drawString("A",12,69,4);
      tft.setTextColor(TFT_WHITE, CINZA);
      printNumero(velocidadeM1,3,65,69,4);
      
      break;
     case 2:

      m1_test = false;
      m2_test = true;
      m4_test = false;
      m4_test = false;
      test_motor = false;
      tft.fillRoundRect(6, 110, 233, 39, 6, CINZA);
      tft.setTextColor(TFT_WHITE, CINZA);
      tft.drawString("B",12,119,4);
      tft.setTextColor(TFT_WHITE, CINZA);
      printNumero(velocidadeM2,3,65,119,4);
      break;
     case 3:
      Serial.println("Controle M3");
      m1_test = false;
      m2_test = false;
      m3_test = true;
      m4_test = false;
      test_motor = false;
        tft.fillRoundRect(6, 160, 233, 39, 6, CINZA);
      tft.setTextColor(TFT_WHITE, CINZA);
      tft.drawString("C",12,169,4);
      tft.setTextColor(TFT_WHITE, CINZA);
      printNumero(velocidadeM3,3,65,169,4);
      break;
     case 4:
      Serial.println("Controle M4");
      m1_test = false;
      m2_test = false;
      m3_test = false;
      m4_test = true;
      test_motor = false;
      tft.fillRoundRect(6, 210, 233, 39, 6, CINZA);
      tft.setTextColor(TFT_WHITE, CINZA);
      tft.drawString("D",12,219,4);
      tft.setTextColor(TFT_WHITE, CINZA);
      printNumero(velocidadeM4,3,65,219,4);
      break;
    }

  }
}

void attachLongPressStart48() {

  if(flagEnableSound){
    NewTone(26,349,120);
    NewTone(26,589,120);
  }

    test_sensor = false;
    m1_test = false;
    m2_test = false;
    m3_test = false;
    m4_test = false;

    test_programa = false;
    test_motor = false;
    menu_main = true;
    velocidadeM1 = 0;
    velocidadeM2 = 0;
    velocidadeM3 = 0;
    velocidadeM4 = 0;
    setMotorPin(A,0);
    setMotorPin(B,0);
    setMotorPin(C,0);
    setMotorPin(D,0);
    setupCittius=false;

    TELA_MENU();
    C_BAT = map(Filtro_Analog(V_Bat,15,10),0,1023,0,100);
    BAT(C_BAT);

}
void initCittius(){
    tft.begin();              // INICIALIZA O BARRAMENTO DO DISPLAY

  tft.fillScreen(COR_DE_FUNDO);

  pinMode(2,INPUT_PULLUP);
  pinMode(3,INPUT_PULLUP);
  pinMode(18,INPUT_PULLUP);
  pinMode(19,INPUT_PULLUP);

   TELA_MENU();
   C_BAT = map(Filtro_Analog(V_Bat,15,10),0,1023,0,100);
   BAT(C_BAT);
    
  button49.attachClick(attachClick49);
  Serial.begin(9600);
  menu = 0;
  control_motor = 1;
  menu_main = true;
  test_programa = false;
  test_motor = false;
  test_sensor = false;
  m1_test = false;
  m2_test = false;
  m3_test = false;
  m4_test = false;
  velocidadeM1 = 0;
  velocidadeM2 = 0;
  velocidadeM3 = 0;
  velocidadeM4 = 0;
  button38.attachClick(attachClick38);
  button47.attachClick(attachClick47);
  button48.attachClick(attachClick48);
  button48.attachLongPressStart(attachLongPressStart48);
}



void updateCittius(){
  buttonMenu();
  unsigned long currentMillis = millis();
  unsigned long currentMillis1 = millis();
  button49.tick();
  button38.tick();
  button47.tick();
  button48.tick();

  if(test_sensor){
  

 if (currentMillis1 - previousMillis1 >= interval1){

    tft.drawRoundRect(15, 240, 100, 40, 6, BRANCO);
   
    

    tft.fillRoundRect(16, 241, 98, 38, 6, COR_DE_FUNDO);
   // printNumero(getSensorUtrasson(6),3,20,242,2);
    printTexto(" 6", BRANCO,48,282,2);
    

    tft.drawRoundRect(122, 240, 100, 40, 6, BRANCO);
    tft.fillRoundRect(123, 241, 98, 38, 6, COR_DE_FUNDO);
    //printNumero(getSensorUtrasson(8),3,112,242,2);
    printTexto(" 8", BRANCO,152,282,2);

  previousMillis1 = currentMillis1;
 }

  if (currentMillis - previousMillis >= interval) {
    // save the last time you blinked the LED
    
/*
    if(analogRead(A3)==1022){
      tft.fillRoundRect(6, 60, 40, 40, 6, VERDE_ESCURO);
      tft.setTextColor(TFT_WHITE, VERDE_ESCURO);
      printTexto("P2", BRANCO,18,105,2);
    }else{
      tft.fillRoundRect(6, 60, 40, 40, 6, VERMELHO);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      printTexto("P2", BRANCO,18,105,2);
    }
*/


    
   
    if(analogRead(A4)>=600){
      tft.fillRoundRect(61, 60, 40, 40, 6, VERDE_ESCURO);
      printTexto("1", BRANCO,71+5 ,72,2);
      tft.setTextColor(TFT_WHITE, VERDE_ESCURO);
      printTexto(" 2", BRANCO,67,105,2);
    }else{
      tft.fillRoundRect(61, 60, 40, 40, 6, VERMELHO);
      printTexto("0", BRANCO,71+5 ,72,2);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      printTexto(" 2", BRANCO,67,105,2);
    }

    if(analogRead(A5)>=600){
      tft.fillRoundRect(117+5, 60, 40, 40, 6, VERDE_ESCURO);
      printTexto("1", BRANCO,132+5 ,72,2);
      tft.setTextColor(TFT_WHITE, VERDE_ESCURO);
      printTexto(" 3", BRANCO,130,105,2);
    }else{
      tft.fillRoundRect(117+5, 60, 40, 40, 6, VERMELHO);
      printTexto("0", BRANCO,132+5,72,2);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      printTexto(" 3", BRANCO,130,105,2);
    }
  /*
    switch (getSensorColor(5))
    {
      case 1:
      tft.fillRoundRect(61, 150, 40, 40, 6, TFT_RED);

      printTexto("1", TFT_WHITE,76,162,2);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      
      break;
      case 2:
      tft.fillRoundRect(61, 150, 40, 40, 6, TFT_GREEN);
      printTexto("2", TFT_BLACK,76,162,2);
    //  tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
   //   printTexto("P5", BRANCO,128+5,152,2);
      break;
      case 3:
      tft.fillRoundRect(61, 150, 40, 40, 6, TFT_BLUE);
      printTexto("3", TFT_WHITE,76,162,2);
    //  tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
   //   printTexto("P5", BRANCO,128+5,152,2);
      break;

      case 4:
      tft.fillRoundRect(61, 150, 40, 40, 6, TFT_YELLOW);
      printTexto("4", TFT_BLACK,76,162,2);
    //  tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
   //   printTexto("P5", BRANCO,128+5,152,2);
      break;
     case 5:
      tft.fillRoundRect(61, 150, 40, 40, 6, 0xFD20);
      printTexto("5", TFT_BLACK,76,162,2);
    //  tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
   //   printTexto("P5", BRANCO,128+5,152,2);
      break;
    case 6:
      tft.fillRoundRect(61, 150, 40, 40, 6, TFT_WHITE);
      printTexto("6", TFT_BLACK,76,162,2);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);

      break;
    case 7:
      tft.fillRoundRect(61, 150, 40, 40, 6, TFT_BLACK);
      printTexto("7", TFT_WHITE,76,162,2);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);

      break;
    
    default:
     tft.drawRoundRect(60, 149, 42, 42, 6, BRANCO);
     tft.fillRoundRect(61, 150, 40, 40, 6, COR_DE_FUNDO);
      break;
    }

    switch (getSensorColor(7))
    {
      case 1:
      tft.fillRoundRect(122, 150, 40, 40, 6, TFT_RED);

      printTexto("1", TFT_WHITE,137,162,2);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
      
      break;
      case 2:
      tft.fillRoundRect(122, 150, 40, 40, 6, TFT_GREEN);
      printTexto("2", TFT_BLACK,137,162,2);
    //  tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
   //   printTexto("P5", BRANCO,128+5,152,2);
      break;
      case 3:
      tft.fillRoundRect(122, 150, 40, 40, 6, TFT_BLUE);
      printTexto("3", TFT_WHITE,137,162,2);
    //  tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
   //   printTexto("P5", BRANCO,128+5,152,2);
      break;

      case 4:
      tft.fillRoundRect(122, 150, 40, 40, 6, TFT_YELLOW);
      printTexto("4", TFT_BLACK,137,162,2);
    //  tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
   //   printTexto("P5", BRANCO,128+5,152,2);
      break;
     case 5:
      tft.fillRoundRect(122, 150, 40, 40, 6, 0xFD20);
      printTexto("5", TFT_BLACK,137,162,2);
    //  tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
   //   printTexto("P5", BRANCO,128+5,152,2);
      break;
    case 6:
      tft.fillRoundRect(122, 150, 40, 40, 6, TFT_WHITE);
      printTexto("6", TFT_BLACK,137,162,2);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);

      break;
    case 7:
      tft.fillRoundRect(122, 150, 40, 40, 6, TFT_BLACK);
      printTexto("7", TFT_WHITE,137,162,2);
      tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);

      break;
    
    default:
      tft.drawRoundRect(121, 149, 42, 42, 6, BRANCO);
      tft.fillRoundRect(122, 150, 40, 40, 6, COR_DE_FUNDO);
      break;
    }
*/

    previousMillis = currentMillis;
  }

}

  if (test_motor == true) {


    switch(control_motor){
      case 0:
          tft.drawRoundRect(5, 59, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 109, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 159, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 209, 235, 41, 6, VERMELHO);
      break;
      case 1:
          tft.drawRoundRect(5, 59, 235, 41, 6, VERDE);
          tft.drawRoundRect(5, 109, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 159, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 209, 235, 41, 6, VERMELHO);
      break;
      case 2:
          tft.drawRoundRect(5, 59, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 109, 235, 41, 6, VERDE);
          tft.drawRoundRect(5, 159, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 209, 235, 41, 6, VERMELHO);
      break;
      case 3:
          tft.drawRoundRect(5, 59, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 109, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 159, 235, 41, 6, VERDE);
          tft.drawRoundRect(5, 209, 235, 41, 6, VERMELHO);
      break;
      case 4:
          tft.drawRoundRect(5, 59, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 109, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 159, 235, 41, 6, VERMELHO);
          tft.drawRoundRect(5, 209, 235, 41, 6, VERDE);
      break;
      default:
          tft.drawRoundRect(5, 59, 235, 41, 6, AMARELO);
          tft.drawRoundRect(5, 109, 235, 41, 6, AMARELO);
          tft.drawRoundRect(5, 159, 235, 41, 6, AMARELO);
          tft.drawRoundRect(5, 209, 235, 41, 6, AMARELO);
      break;
    }

  //  tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
   // printNumero(getCodePin(m1),6,130,69,4);
   // printNumero(getCodePin(m2),6,130,119,4);
  //  printNumero(getCodePin(m3),6,130,169,4);
  //  printNumero(getCodePin(m4),6,130,219,4);

  }

  if (m1_test == true){
   setMotorPin(A,velocidadeM1);
   tft.setTextColor(TFT_WHITE, CINZA);
   printNumero(getCodePin(m1),6,130,69,4);

   tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
   printNumero(getCodePin(m2),6,130,119,4);
   printNumero(getCodePin(m3),6,130,169,4);
   printNumero(getCodePin(m4),6,130,219,4);
  }else if(m2_test == true){
   setMotorPin(B,velocidadeM2);
   tft.setTextColor(TFT_WHITE, CINZA);
   printNumero(getCodePin(m2),6,130,119,4);

   tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
   
   printNumero(getCodePin(m1),6,130,69,4);
   printNumero(getCodePin(m3),6,130,169,4);
   printNumero(getCodePin(m4),6,130,219,4);
  }  else if(m3_test == true){
   setMotorPin(C,velocidadeM3);
   tft.setTextColor(TFT_WHITE, CINZA);
   printNumero(getCodePin(m3),6,130,169,4);
   tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
   printNumero(getCodePin(m2),6,130,119,4);
   printNumero(getCodePin(m1),6,130,69,4);
   printNumero(getCodePin(m4),6,130,219,4);
  }  else if(m4_test == true){
   setMotorPin(D,velocidadeM4);
  tft.setTextColor(TFT_WHITE, CINZA);
   printNumero(getCodePin(m4),6,130,219,4);
   tft.setTextColor(TFT_WHITE, COR_DE_FUNDO);
   printNumero(getCodePin(m1),6,130,69,4);
   printNumero(getCodePin(m2),6,130,119,4);
   printNumero(getCodePin(m3),6,130,169,4);
   
  }

 

}
// ------------------------------------ FIM DA FUNÇÃO DE FILTRO--------------------------------------------
