// sensor and lcd
//OneWire ds(27);
//LiquidCrystal lcd(A5, A4, 7, 6, 5, 4);

//LiquidCrystal_I2C lcd(0x3F,16,2);

// ENTRADAS ANALÓGICAS
#define V_Bat A7

// push buttons
#define BTN1_enter digitalRead(49)
#define BTN2_voltar digitalRead(48)
#define BTN3_up digitalRead(47)
#define BTN4_dn digitalRead(38)


//const byte BTN1_enter    = 49;    // PROJETO CITTIUS
//const byte BTN2_voltar   = 48;    // PROJETO CITTIUS
//const byte BTN3_up       = 47;    // PROJETO CITTIUS
//const byte BTN4_dn       = 38;    // PROJETO CITTIUS


// FLAGS BUTTONS
boolean Flag_BTN1_enter  = 0;
boolean Flag_BTN2_voltar = 0;
boolean Flag_BTN3_up     = 0;
boolean Flag_BTN4_dn     = 0;
boolean Flag_card        = 0;
boolean Flag_play        = 0;
boolean Flag_read        = false;


const short DEBOUNCING    = 1000;     // TEMPO DE VARREDURA DA INTERRUPÇÃO EM ms.
const short T_CARD        = 500;      // TEMPO DE VARREDURA DA LEITURA DO CARTÃO
const short T_BAT         = 1000;     // TEMPO DE VARREDURA DA LEITURA DO CARTÃO


// outputs
const byte BUZ           = 26;       // PROJETO CITTIUS

// VARIÁVEIS USADAS
byte C_BAT = 0;                     // CARGA DA BATERIA
byte M_BAT = 0;                     // CONTAGEM DE 1 MIN PARA ATUALIZAÇÃO DO NÍVEL DA BATERIA
byte N_CARD = 0;                    // QUANTIDADE DE PASSAGEM DE CARTÃO
byte N_PLAY = 0;                    // CONTAGEM DA SEQUENCIA DO PLAY
unsigned long Tarefa = 0;           // RECEBE MILLIS DO CARD
unsigned long Tarefa2 = 0;          // RECEBE MILLIS DO BATERIA

String Seq_CARD [14];               // RECEBE A SEQUENCIA DOS NOMES DOS CARTOES PASSADOS -----------------------> VAI PODER RETIRAR NO FIM DA PROGRAMAÇÃO 
String Seq_PLAY [14];               // RECEBE A SEQUENCIA DAS FUNÇOES A SEREM EXECUTADAS


                                              
