#define RST_PIN         A2           // PINO SELECIONADO REFERENTE AO ARDUINO MEGA2560
#define SS_PIN          A1          // PINO SELECIONADO REFERENTE AO ARDUINO MEGA2560

MFRC522 mfrc522(SS_PIN, RST_PIN);   // CRIA INSTÂNCIA PARA O MFRC522
String rfid_card = "";               // VARIÁVEL COM O VALOR DA FUNÇÃO DO CARTÃO


//*****************************************************************************************//
//                        FUNÇÃO PARA LEITURA DE CARTÃO
//*****************************************************************************************//
void le_cartao(){
      // Chave de preparação - todas as chaves são configuradas para (FF FF FF FF FF FFh) na entrega do chip da fábrica.
  MFRC522::MIFARE_Key key;
  for (byte i = 0; i < 6; i++) key.keyByte[i] = 0xFF;

  // algumas variáveis que precisamos
  byte block;
  byte len;
  MFRC522::StatusCode status;
  //-------------------------------------------
  //   Reinicialize o loop se nenhum cartão novo estiver presente no sensor/leitor. Isso salva todo o processo quando ocioso.
  if ( ! mfrc522.PICC_IsNewCardPresent()) {
    return;
  }
  // Selecione um dos cartões
  if ( ! mfrc522.PICC_ReadCardSerial()) {
    return;
  }

  //Serial.println(F("\n**Cartão Detectado**\n"));          // UTILIZADO PARA TESTE, RETIRAR***********

  //-------------------------------------------
  //mfrc522.PICC_DumpDetailsToSerial(&(mfrc522.uid)); // despejar alguns detalhes sobre o cartão (card UID, card SAK, PICC type)
  //mfrc522.PICC_DumpToSerial(&(mfrc522.uid));      // descomente isso para ver todos os blocos em hexadecimal
  //------------------------------------------- OBTER NOME

  delay(7);     // AJUDOU A REDUZIR A REINCIDENCIA DE FALHAS EM LEITURA
  
  status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 4, &key, &(mfrc522.uid)); // LINHA 834
  if (status != MFRC522::STATUS_OK) {
    //Serial.print(F("AUTENTICAÇÃO FALHOU: "));             // UTILIZADO PARA TESTE, RETIRAR***********
    Serial.println(mfrc522.GetStatusCodeName(status));
    return;
  }

  byte buffer1[18];
  block = 4;
  len = 18;

  status = mfrc522.MIFARE_Read(block, buffer1, &len);
  if (status != MFRC522::STATUS_OK) {
    //Serial.print(F("A LEITURA FALHOU: "));
    Serial.println(mfrc522.GetStatusCodeName(status));
    //Serial.println(F("A LEITURA FALHOU, AGUARDE 3s"));          // UTILIZADO PARA TESTE, RETIRAR***********
    delay(2000);                                                // TROCAR PARA CICLOS DE VERIFICAÇÃO
    //return; 
  }

//------------------------------------------- TRATAMENTO DOS DADOS CITTIUS DO CARTÃO -------------------------------------------
  for (uint8_t i = 11; i < 16; i++) {
    //if (((buffer1[i] == 42)&&(Flag_read == 0))||(Flag_read == 0)){
        if ((buffer1[i] == 42)||(buffer1[i]>=65&&buffer1[i]<=90)||(buffer1[i]>=48&&buffer1[i]<=57))
          rfid_card = rfid_card + char(buffer1[i]);
  }

  if ((rfid_card.length() == 5)&&(rfid_card[0] == '*')&&(rfid_card[1] != '*')&&(rfid_card[2] != '*')&&(rfid_card[3] != '*')&&(rfid_card[4] == '*')){ 
    Flag_read = true;
  }
  else {
    rfid_card = "";
    Flag_read = false;
    tone(BUZ,150,1000);
    delay(1000);
  }
//------------------------------------------- FIM DO TRATAMENTO DOS DADOS CITTIUS DO CARTÃO -------------------------------------------

  mfrc522.PICC_HaltA();
  mfrc522.PCD_StopCrypto1(); 
}
//*****************************************************************************************//
