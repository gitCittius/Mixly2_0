#include "rsteck.h"
#include <music.h>
// FUNÇÕES PARA TRATAMENTO DOS SWITCH CASE


byte MT_A = 100;
byte MT_B = 100;
byte MT_C = 100;
unsigned long D_elay1 = 0;  
unsigned long D_elay2 = 0;
unsigned long D_elay3 = 0; 
unsigned long D_elay4 = 0;   
boolean FlagDelay1 = 0;
boolean FlagDelay2 = 0;   
boolean FlagDelay3 = 0;         
boolean FlagDelay4 = 0;


music Music_(26);

//*****************************************************************************************//
//                        FUNÇÃO PARA SEQUENCIA DOS CARTÕES
//*****************************************************************************************//
String Nome_card(String cartao, boolean retorno){

// RETORNO = 0 -> RETORNA O VALOR PARA VARIÁVEL Seq_PLAY
// RETORNO = 1 -> RETORNA O NOME A SER IMPRESSO NO TFT  

byte y = 0;
String z = "";

switch (cartao[1]){
  case '1':
  {
    //Serial.println(F("cartao AMARELO"));
    if (cartao[2] == 'S'){
      y = 1;
      z = "AGUARDAR 0.5s";
    }
    if ((cartao[2] == '1')&&(cartao[3] == 'S')){
      y = 2;
      z = "AGUARDAR 1s";
    }
    if (cartao[2] == '3'){
      y = 3;
      z = "AGUARDAR 3s";
    }
    if ((cartao[2] == '1')&&(cartao[3] == '0')){
      y = 4;
      z = "AGUARDAR 10s";
    }            
  }
  break;

  case '2':
  {
    //Serial.println(F("cartao AMARELO"));
    if (cartao[2] == 'L'){
      y = 5;
      z = "LOOP";
    }
    if (cartao[2] == 'S'){
      y = 6;
      z = "PARAR ROTINA";
    }        
  }
  break;  

  case '3':
  {
    //Serial.println(F("cartao VERDE"));
    if ((cartao[2] == 'A')&&(cartao[3] == 'A')){
      y = 7;
      z = "MOTOR A [-]";
    }
    if ((cartao[2] == 'B')&&(cartao[3] == 'A')){
      y = 8;
      z = "MOTOR B [-]";
    }     
    if ((cartao[2] == 'C')&&(cartao[3] == 'A')){
      y = 9;
      z = "MOTOR C [-]";
    }  
    if ((cartao[2] == 'A')&&(cartao[3] == 'H')){
      y = 10;
      z = "MOTOR A [+]";
    }
    if ((cartao[2] == 'B')&&(cartao[3] == 'H')){
      y = 11;
      z = "MOTOR B [+]";
    }     
    if ((cartao[2] == 'C')&&(cartao[3] == 'H')){
      y = 12;
      z = "MOTOR C [+]";
    }         
  }
  break; 

  case '4':
  {
    //Serial.println(F("cartao VERDE"));
    if (cartao[2] == 'A'){
      y = 13;
      z = "PARE MOTOR A";
    }
    if (cartao[2] == 'B'){
      y = 14;
      z = "PARE MOTOR B";
    }     
    if (cartao[2] == 'C'){
      y = 15;
      z = "PARE MOTOR C";
    }  
    if (cartao[2] == 'T'){
      y = 16;
      z = "PARAR MOTORES";
    }       
  }
  break;   

  case '5':
  {
    //Serial.println(F("cartao VERDE"));
    if (cartao[2] == 'F'){
      y = 17;
      z = "PARA FRENTE";
    }
    if (cartao[2] == 'D'){
      y = 18;
      z = "PARA DIREITA";
    }     
    if (cartao[2] == 'E'){
      y = 19;
      z = "PARA ESQUERDA";
    }  
    if (cartao[2] == 'T'){
      y = 20;
      z = "PARA TRAS";
    }
    if (cartao[2] == 'S'){
      y = 21;
      z = "PARAR DIRECAO";
    }            
  }
  break;  

  case '6':
  {
    //Serial.println(F("cartao VERDE"));
    if ((cartao[2] == 'V')&&(cartao[3] == 'M')){
      y = 22;
      z = "RGB D = VERMELHO";
    }
    if (cartao[2] == 'A'){
      y = 23;
      z = "RGB D = AMARELO";
    }     
    if ((cartao[2] == 'V')&&(cartao[3] == 'D')){
      y = 24;
      z = "RGB D = VERDE";
    }  
    if (cartao[2] == 'S'){
      y = 25;
      z = "RGB DESLIGADO";
    }      
  }
  break;  

  case '7':
  {
    //Serial.println(F("cartao VERDE"));
    if (cartao[3] == 'C'){
      y = 26;
      z = "TELA CERTO";
    }
    if (cartao[3] == 'E'){
      y = 27;
      z = "TELA ERRADO";
    }         
  }
  break;    

  case '8':
  {
    //Serial.println(F("cartao VERDE"));
    if (cartao[3] == 'B'){
      y = 28;
      z = "TOCAR SOM DE BUZINA";
    }
    if (cartao[3] == 'A'){
      y = 29;
      z = "ANIVERSARIO";
    }     
    if (cartao[3] == 'N'){
      y = 30;
      z = "TOCAR SOM DE NATAL";
    }  
    if (cartao[3] == 'E'){
      y = 31;
      z = "TOCAR SOM DE ESPACIAL";
    }
    if (cartao[3] == 'D'){
      y = 32;
      z = "DESLIGAR SOM";
    }            
  }
  break; 

  case '9':
  {
    //Serial.println(F("cartao VERMELHO"));
    if ((cartao[2] == '1')&&(cartao[3] == 'V')){
      y = 33;
      z = "1 OK, PULAR L";
    }
    if ((cartao[2] == '2')&&(cartao[3] == 'V')){
      y = 34;
      z = "2 OK, PULAR L";
    }     
    if ((cartao[2] == '6')&&(cartao[3] == 'V')){
      y = 35;
      z = "6 OK,PULAR L";
    }  
    if ((cartao[2] == '8')&&(cartao[3] == 'V')){
      y = 36;
      z = "8 OK,PULAR L";
    }
    if ((cartao[2] == '1')&&(cartao[3] == 'F')){
      y = 37;
      z = "1 FALSO,PULAR L";
    }
    if ((cartao[2] == '2')&&(cartao[3] == 'F')){
      y = 38;
      z = "2 FALSO,PULAR L";
    }     
    if ((cartao[2] == '6')&&(cartao[3] == 'F')){
      y = 39;
      z = "6 FALSO,PULAR L";
    }  
    if ((cartao[2] == '8')&&(cartao[3] == 'F')){
      y = 40;
      z = "8 FALSO, PULAR L";
    }  
    if ((cartao[2] == '5')&&(cartao[3] == 'V')){
      y = 43;
      z = "5 VERMELHO PULAR L";
    }  
    if ((cartao[2] == '5')&&(cartao[3] == 'F')){
      y = 44;
      z = "5 VERDE PULAR L";
    } 
    if ((cartao[2] == '5')&&(cartao[3] == 'A')){
      y = 45;
      z = "5 AZUL PULAR L";
    }                 
  }
  break;   

  case 'X':
  {
    //Serial.println(F("cartao CINZA"));
    if (cartao[2] == '1'){
      y = 41;
      z = "ESPERAR 1 OK";
    }
    if (cartao[2] == '2'){
      y = 42;
      z = "ESPERAR 2 OK";
    } 
    if ((cartao[2] == 'A')&&(cartao[3] == '1')){
      y = 46;
      z = "VELOCIDADE A 100%";
    }    
    if ((cartao[2] == 'A')&&(cartao[3] == '5')){
      y = 47;
      z = "VELOCIDADE A 50%";
    }   
    if ((cartao[2] == 'B')&&(cartao[3] == '1')){
      y = 48;
      z = "VELOCIDADE B 100%";
    }    
    if ((cartao[2] == 'B')&&(cartao[3] == '5')){
      y = 49;
      z = "VELOCIDADE B 50%";
    }
    if ((cartao[2] == 'C')&&(cartao[3] == '1')){
      y = 50;
      z = "VELOCIDADE C 100%";
    }    
    if ((cartao[2] == 'C')&&(cartao[3] == '5')){
      y = 51;
      z = "VELOCIDADE C 50%";
    }          
  }
  break; 

  case 'S':
  {
    //Serial.println(F("cartao CINZA"));
    if (cartao[2] == '1'){
      y = 52;
      z = "SENSIBILIDADE 1";
    }
    if (cartao[2] == '2'){
      y = 53;
      z = "SENSIBILIDADE 2";
    }
    if (cartao[2] == '6'){
      y = 54;
      z = "SENSIBILIDADE 6";
    }
    if (cartao[2] == '8'){
      y = 55;
      z = "SENSIBILIDADE 8";
    }    
  }
  break;              
}

// retorno = 0 -> RETORNA O VALOR PARA VARIÁVEL Seq_PLAY
// retorno = 1 -> RETORNA O NOME A SER IMPRESSO NO TFT  

if (retorno == 0)
  return String(y);
  else if (retorno == 1)
  return z;
}
//*****************************************************************************************//



//*****************************************************************************************//
//                        FUNÇÃO PARA SEQUENCIA DAS ATIVIDADES
//*****************************************************************************************//

void PLAY(String a){

int p_play = a.toInt();

 switch (p_play){
  case 1:
  if (FlagDelay1 == 0){
    FlagDelay1 = 1;
    D_elay1 = millis();
  }

  if((millis() - D_elay1) > 500){ 
    N_PLAY += 1;
    FlagDelay1 = 0;
    D_elay1 = 0;
  }
  break;
  
  case 2:
  if (FlagDelay2 == 0){
    FlagDelay2 = 1;
    D_elay2 = millis();
  }

  if((millis() - D_elay2) > 1000){ 
    N_PLAY += 1;
    FlagDelay2 = 0;
    D_elay2 = 0;
  }
  break;
  
  case 3:
  if (FlagDelay3 == 0){
    FlagDelay3 = 1;
    D_elay3 = millis();
  }

  if((millis() - D_elay3) > 3000){ 
    N_PLAY += 1;
    FlagDelay3 = 0;
    D_elay3 = 0;
  }
  break;
  
  case 4:
  if (FlagDelay4 == 0){
    FlagDelay4 = 1;
    D_elay4 = millis();
  }

  if((millis() - D_elay4) > 10000){ 
    N_PLAY += 1;
    FlagDelay4 = 0;
    D_elay4 = 0;
  }
  break;    
  
  case 5:
  N_PLAY = 0;
  break;
      
  case 6:
  Flag_play = 0;
  N_PLAY = 0;
  break;
    
  case 7:
  setMotorPin(A, (-1 * MT_A));
  N_PLAY += 1;
  break;
    
  case 8:
  setMotorPin(B, (-1 * MT_B));
  N_PLAY += 1;
  break;
    
  case 9:
  setMotorPin(C, (-1 * MT_C));
  N_PLAY += 1;
  break;
    
  case 10:
  setMotorPin(A, MT_A);
  N_PLAY += 1;
  break;
    
  case 11:
  setMotorPin(B, MT_B);
  N_PLAY += 1;
  break;
    
  case 12:
  setMotorPin(C, MT_C);
  N_PLAY += 1;
  break;
    
  case 13:
  setMotorPin(A, 0);
  N_PLAY += 1;
  break;
    
  case 14:
  setMotorPin(B, 0);
  N_PLAY += 1;
  break;
    
  case 15:
  setMotorPin(C, 0);
  N_PLAY += 1;
  break;
    
  case 16:
  setMotorPin(A, 0);
  setMotorPin(B, 0);
  setMotorPin(C, 0);
  N_PLAY += 1;
  break;
  
  case 17:
  setMotorPin(A, MT_A);
  setMotorPin(B, MT_B);  
  N_PLAY += 1;
  break;
      
  case 18:
  setMotorPin(A, MT_A);
  setMotorPin(B, 30);
  N_PLAY += 1;
  break;
    
  case 19:
  setMotorPin(A, 30);
  setMotorPin(B, MT_B);
  N_PLAY += 1;
  break;
    
  case 20:
  setMotorPin(A, -MT_A);
  setMotorPin(B, -MT_B);
  N_PLAY += 1;
  break;
    
  case 21:
  setMotorPin(A, 0);
  setMotorPin(B, 0);
  N_PLAY += 1;
  break;
    
  case 22:
  setLed(7,0xff0000 );    // ACIONA O LED VERMELHO NA SAIDA D DA CONTROLADORA
  tft.fillScreen(VERMELHO);
  N_PLAY += 1;
  break;
    
  case 23:
  tft.fillScreen(AMARELO);
  setLed(7,0xffff00 );    // ACIONA O LED VERDE NA SAIDA D DA CONTROLADORA
  N_PLAY += 1;
  break;
    
  case 24:
  tft.fillScreen(VERDE);
  setLed(7,0x00ff00 );    // ACIONA O LED VERDE NA SAIDA D DA CONTROLADORA
  N_PLAY += 1;
  break;
    
  case 25:
  tft.fillScreen(COR_DE_FUNDO);
  setLed(7,0x000000 );    // DESLIGA O LED NA SAIDA D DA CONTROLADORA
  N_PLAY += 1;
  break;
    
  case 26:
  Serial.println("caso 26");
  N_PLAY += 1;
  break;
    
  case 27:
  Serial.println("caso 27");
  N_PLAY += 1;
  break;
    
  case 28:
  Music_.beep(3015,150);
  Music_.beep(3015,150);
  N_PLAY += 1;
  break;  
      
  case 29:
  Music_.birthday();
  N_PLAY += 1;
  break;
    
  case 30:
  Music_.christmas();
  N_PLAY += 1;
  break;
    
  case 31:
  Music_.star_war_tone();
  N_PLAY += 1;
  break;
    
  case 32:
  Serial.println("caso 32");
  N_PLAY += 1;
  break;
    
  case 33:
  Serial.println("caso 33");
  N_PLAY += 1;
  break;
    
  case 34:
  Serial.println("caso 34");
  N_PLAY += 1;
  break;
    
  case 35:
  Serial.println("caso 35");
  N_PLAY += 1;
  break;
  
  case 36:
  Serial.println("caso 36");
  N_PLAY += 1;
  break;
      
  case 37:
  Serial.println("caso 37");
  N_PLAY += 1;
  break;
    
  case 38:
  Serial.println("caso 38");
  N_PLAY += 1;
  break;
    
  case 39:
  Serial.println("caso 39");
  N_PLAY += 1;
  break;
    
  case 40:
  Serial.println("caso 40");
  N_PLAY += 1;
  break;
    
  case 41:
  Serial.println("caso 41");
  N_PLAY += 1;
  break;
    
  case 42:
  Serial.println("caso 42");
  N_PLAY += 1;
  break;
    
  case 43:
  Serial.println("caso 43");
  N_PLAY += 1;
  break;
    
  case 44:
  Serial.println("caso 44");
  N_PLAY += 1;
  break;
    
  case 45:
  Serial.println("caso 45");
  N_PLAY += 1;
  break;
    
  case 46:
  MT_A = 100;
  N_PLAY += 1;
  break;
    
  case 47:
  MT_A = 30;
  N_PLAY += 1;
  break;
        
  case 48:
  MT_B = 100;  
  N_PLAY += 1;
  break;
    
  case 49:
  MT_B = 30;
  N_PLAY += 1;
  break;
    
  case 50:
  MT_C = 100;  
  N_PLAY += 1;
  break;
    
  case 51:
  MT_C = 30;
  N_PLAY += 1;
  break;
    
  case 52:
  Serial.println("caso 52");
  N_PLAY += 1;
  break;
    
  case 53:
  Serial.println("caso 53");
  N_PLAY += 1;
  break;
    
  case 54:
  Serial.println("caso 54");
  N_PLAY += 1;
  break;
    
  case 55:
  Serial.println("caso 55");
  N_PLAY += 1;
  break;
 
  default:
  Serial.println("DEFAULT");
  setMotorPin(A, 0);
  setMotorPin(B, 0);
  setMotorPin(C, 0);
  setLed(7,0x000000 );    // DESLIGA O LED NA SAIDA D DA CONTROLADORA
  Flag_play = 0;
  D_elay1 = 0;  
  D_elay2 = 0;
  D_elay3 = 0; 
  D_elay4 = 0; 
  FlagDelay1 = 0;
  FlagDelay2 = 0;   
  FlagDelay3 = 0;         
  FlagDelay4 = 0;
  Flag_play = 0;
  N_PLAY = 0;
  break;  
 }

//Serial.println("FIM DO SWITCH PLAY");
  
}


//*****************************************************************************************//
