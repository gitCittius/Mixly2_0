# AsyncDelay

A simple abstraction for implementing delays and timeouts in Arduino
sketches.

## Licence

Released under the GNU Lesser General Public License, version 2.1. See
license.txt for details.

## Examples

### AsyncDelay_example

Demonstrate the use of `start()`, `isExpired()` and `repeat()`.
