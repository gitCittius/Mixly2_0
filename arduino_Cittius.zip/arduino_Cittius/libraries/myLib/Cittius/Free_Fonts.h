#define FSBI9 &FreeSerifBoldItalic9pt7b
#define FM9 &FreeMono9pt7b
#define FSB9 &FreeSerifBold9pt7b
#define FSSB12 &FreeSansBold12pt7b
#define FF0 NULL //ff0 reserved for GLCD