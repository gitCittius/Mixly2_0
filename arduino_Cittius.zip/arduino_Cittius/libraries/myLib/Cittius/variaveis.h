#ifndef VARIABLES_H
#define VARIABLES_H

// Variaveis Globais
extern boolean flagSetupMenu = false, // Setup da Tela
        flagSetupMotor = false,    // Setup da Tela Motor
        flagSetupProgram = false,  // Setup da Tela Akuno
        flagSetupAluno = false,    // Setup da Tela Akuno
        flagSetupConfig = false,
        flagLoopAluno = false, // Setup da Tela Akuno

        flagSetupApp = false,      // Setup da Tela App Dable
        flagSetupSensores = false; // Setup da Tela Sensor

extern boolean enableM1 = false,
        enableM2 = false,
        enableM3 = false,
        serigrafia = false,
        enableConfig = false,
        enableBUZZER = true,
        myWhile2    =  false,
        enableM4 = false;

extern uint8_t selectMotor = 1, pageDosSensores = 1, minhaDistncia=255,getEV3test=255,mychanel=1,myMode=0;
extern uint8_t menu = 0; // Controle das Paginas
extern uint8_t menuConfig = 1;
extern uint8_t btnMenu = 1; // Controle das Paginas com os Botões

extern byte typeSensorButton = 1, typeSensorUtra = 1, typeSensorColor = 1;


extern int padding;

extern char *namePort[12][2] = {{"M1", "A"}, {"M2", "B"}, {"M3", "C"}, {"M4", "D"}, {"P1", "1"}, {"P2", "2"}, {"P3", "3"}, {"P4", "4"}, {"P5", "5"}, {"P6", "6"}, {"P7", "7"}, {"P8", "8"}};
extern boolean enableTemp=false;
//Bibliotecas
#include <CorUltra.h>
#include <EV3UARTSensor.h>
#include <SoftwareSerial.h>

//Definições de Objetos
EV3UARTSensor sensor5(A15,4);
EV3UARTSensor sensor6(A12,53);
EV3UARTSensor sensor7(A13,28);
EV3UARTSensor sensor8(A14,29);

EV3UARTSensor sensorA(A8,2);
EV3UARTSensor sensorB(A9,3);
EV3UARTSensor sensorC(A10,18);
EV3UARTSensor sensorD(A11,19);

//Definições
#define P1 1
#define P2 2
#define P3 3
#define P4 4
#define P5 5
#define P6 6
#define P7 7
#define P8 8
#define PA 9
#define PB 10
#define PC 11
#define PD 12

#define REFLETIVO 0
#define AMBIENTE 1
#define COR 2

#define CENTIMETROS 0
#define MILIMETROS 1
#define ESCUTA 2

//Variaveis Globais
extern unsigned long lastMessageEV3 = 0;

extern boolean flag5=false,flag6=false,flag7=false,flag8=false,
        flagA=false,flagB=false,flagC=false,flagD=false;

extern byte valueUtra;
extern bool enableMode = false;


extern byte CodigoVermelho4 = 0;
SoftwareSerial sens_cor(A15, 4); // RX, TX porta 5
SoftwareSerial sens_cor2(A12, 53); // RX, TX porta 5

CorUltra sensor5f1; //cor
CorUltra sensor6f1; //cor




#endif



