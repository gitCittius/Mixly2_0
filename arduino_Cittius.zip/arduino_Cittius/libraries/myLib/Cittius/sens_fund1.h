//#include <CorUltra.h>
//#include <SoftwareSerial.h>

////SoftwareSerial sens_cor(A15, 4); // RX, TX porta 5


///CorUltra sensor5f1; //cor

#include"variaveis.h"


byte getSensorColor(byte typeGet){
    static byte dataA = 0;
    static byte dataB = 0;
    static byte over = 0;


    static byte CodigoCor = 0;
    static boolean flag_escrita = 0;

    flag_escrita = 0;
  
    sens_cor.listen();
    delay(150);
      
      while (sens_cor.available()>15){
        while (sens_cor.available()>0){
        over = byte(sens_cor.read());
        }
      }
          if (sens_cor.overflow()) {
        Serial.println("Porta1 overflow!");
    }
    
      while ((sens_cor.available()>0)&&(sens_cor.available()==13)||(sens_cor.available()>0)&&(flag_escrita == 1)){
          flag_escrita = 1;
          dataA = byte(sens_cor.read());
          sensor5f1.Handler_SoftSerial(dataA);
    }

    flag_escrita = 0;
    
    if(typeGet==0){
      if (sensor5f1.PegarCor()!=9000){    
      CodigoCor = sensor5f1.PegarCor(); 
      }  else {
        CodigoCor = 0;
      }
      return CodigoCor;
    }//else{
  //    if (sensor5f1.PegarCinza()!=9000){    
  //    CodigoCor = sensor5f1.PegarCinza(); 
  //    }  else {
  //      CodigoCor = 0;
  //    }
  //    return CodigoCor;
  //  }

}

byte getSensorColor6(byte typeGet){
    static byte dataA = 0;
    static byte dataB = 0;
    static byte over = 0;


    static byte CodigoCor = 0;
    static boolean flag_escrita = 0;

    flag_escrita = 0;
  
    sens_cor2.listen();
    delay(10);
      
      while (sens_cor2.available()>15){
        while (sens_cor2.available()>0){
        over = byte(sens_cor2.read());
        }
      }
          if (sens_cor2.overflow()) {
        Serial.println("Porta1 overflow!");
    }
    
      while ((sens_cor2.available()>0)&&(sens_cor2.available()==13)||(sens_cor2.available()>0)&&(flag_escrita == 1)){
          flag_escrita = 1;
          dataA = byte(sens_cor2.read());
          sensor6f1.Handler_SoftSerial(dataA);
    }

    flag_escrita = 0;
    
    if(typeGet==0){
      if (sensor6f1.PegarCor()!=9000){    
      CodigoCor = sensor6f1.PegarCor(); 
      }  else {
        CodigoCor = 0;
      }
      return CodigoCor;
    }//else{
   //   if (sensor6f1.PegarCinza()!=9000){    
   //   CodigoCor = sensor6f1.PegarCinza(); 
   //   }  else {
   //     CodigoCor = 0;
   //   }
  //    return CodigoCor;
  //  }

}



