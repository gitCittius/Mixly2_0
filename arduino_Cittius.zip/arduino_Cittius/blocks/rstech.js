'use strict';

goog.provide('Blockly.Blocks.loops');

goog.require('Blockly.Blocks');


Blockly.Blocks.loops.HUE = "#FFAB19";

Blockly.Blocks.loops.HUE_CONTR = "#3ea8ff";
Blockly.Blocks.loops.HUE_CRTL = "#F5B041";
Blockly.Blocks.loops.HUE_LCD = "#91114d";

var DRAWFIll_ = [
  ["Preenchido", "fill"],
  ["Contorno", "draw"]

];

var CIRCLEOPTELECT_ = [
  [Blockly.OLED_WHOLE_CICILE, "U8G2_DRAW_ALL"],
  [Blockly.OLED_UP_R, "U8G2_DRAW_UPPER_RIGHT"],
  [Blockly.OLED_UP_L, "U8G2_DRAW_UPPER_LEFT"],
  [Blockly.OLED_LOW_R, "U8G2_DRAW_LOWER_RIGHT"],
  [Blockly.OLED_LOW_L, "U8G2_DRAW_LOWER_LEFT"]
  ];

Blockly.Blocks['Setup_Cittius'] = {
    init: function() {
     this.appendDummyInput()
     .appendField("Controladora");
     this.appendStatementInput("setup")
     .appendField("Inicializar")
     .setCheck(null);
     this.appendStatementInput("loop")
     .appendField("Sempre")
     .setCheck(null);
     this.setColour(Blockly.Blocks.loops.HUE_CONTR);
     this.setTooltip(Blockly.MIXLY_TOOLTIP_SCOOP);
   }
};

Blockly.Blocks['SCoop_sleep_ED'] = {
    init: function() {
      this.setColour(Blockly.Blocks.loops.HUE_CRTL);
      this.appendDummyInput("")
      .appendField(new Blockly.FieldImage("../../ThirdParty/arduino_Cittius/common/media/keyesAll/time01.png", 30, 30, { alt: "*", flipRtl: "FALSE" }))
      .appendField("Execute o bloco acima por");
      this.appendValueInput("sleeplength", Number)
      .setCheck(Number);
      this.appendDummyInput("")
      .appendField("s");
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setTooltip(Blockly.MIXLY_TOOLTIP_SCOOP_SLEEP);
      this.setHelpUrl("https://mixly.readthedocs.io/zh_CN/latest/arduino/03.Control.html#scoop-task");
    }
};

Blockly.Blocks.controls_for_ED = {
    init: function() {
      this.setColour(Blockly.Blocks.loops.HUE_CRTL);
      this.appendDummyInput()
      .appendField(`Repita`)
      //.appendField(new Blockly.FieldTextInput('i'), 'VAR');
     // this.appendValueInput('FROM')
      //.setCheck(Number)
      //.setAlign(Blockly.ALIGN_RIGHT)
     // .appendField(Blockly.LANG_CONTROLS_FOR_INPUT_FROM);
      this.appendValueInput('TO')
      .setCheck(Number)
      .setAlign(Blockly.ALIGN_RIGHT)
      this.appendDummyInput()
      .appendField(`vezes`);
      //.appendField(Blockly.LANG_CONTROLS_FOR_INPUT_TO);
      //this.appendValueInput('STEP')
      //.setCheck(Number)
      //.setAlign(Blockly.ALIGN_RIGHT)
     
      this.appendStatementInput('DO')
      .appendField('Faça');
      this.setPreviousStatement(true);
      this.setNextStatement(true);
      this.setInputsInline(true);
      this.setHelpUrl("https://mixly.readthedocs.io/zh_CN/latest/arduino/03.Control.html#id2");
      var thisBlock = this;
      this.setTooltip(function() {
        return Blockly.Msg.CONTROLS_FOR_TOOLTIP.replace('%1',
          thisBlock.getFieldValue('VAR'));
      });
    },
    getVars: function() {
      return [this.getFieldValue('VAR')];
    },
    renameVar: function(oldName, newName) {
      if (Blockly.Names.equals(oldName, this.getFieldValue('VAR'))) {
        this.setTitleValue(newName, 'VAR');
      }
    }
};

Blockly.Blocks['controls_if_ED'] = {
    /**
     * Block for if/elseif/else condition.
     * @this Blockly.Block
     */
     init: function() {
      //this.setHelpUrl(Blockly.Msg.CONTROLS_IF_HELPURL);
      this.setColour("#F5B041");
      this.appendValueInput('IF0')
      .setCheck([Boolean,Number])
      .appendField(Blockly.Msg.CONTROLS_IF_MSG_IF);
      this.appendStatementInput('DO0')
      .appendField(Blockly.Msg.CONTROLS_IF_MSG_THEN);
      this.setPreviousStatement(true);
      this.setNextStatement(true);
      this.setHelpUrl("https://mixly.readthedocs.io/zh_CN/latest/arduino/03.Control.html#if");
      this.setMutator(new Blockly.Mutator(['controls_if_elseif',
       'controls_if_else']));
      // Assign 'this' to a variable for use in the tooltip closure below.
      var thisBlock = this;
      this.setTooltip(function() {
        if (!thisBlock.elseifCount_ && !thisBlock.elseCount_) {
          return Blockly.Msg.CONTROLS_IF_TOOLTIP_1;
        } else if (!thisBlock.elseifCount_ && thisBlock.elseCount_) {
          return Blockly.Msg.CONTROLS_IF_TOOLTIP_2;
        } else if (thisBlock.elseifCount_ && !thisBlock.elseCount_) {
          return Blockly.Msg.CONTROLS_IF_TOOLTIP_3;
        } else if (thisBlock.elseifCount_ && thisBlock.elseCount_) {
          return Blockly.Msg.CONTROLS_IF_TOOLTIP_4;
        }
        return '';
      });
      this.elseifCount_ = 0;
      this.elseCount_ = 0;
    },
    /**
     * Create XML to represent the number of else-if and else inputs.
     * @return {Element} XML storage element.
     * @this Blockly.Block
     */
     mutationToDom: function() {
      if (!this.elseifCount_ && !this.elseCount_) {
        return null;
      }
      var container = document.createElement('mutation');
      if (this.elseifCount_) {
        container.setAttribute('elseif', this.elseifCount_);
      }
      if (this.elseCount_) {
        container.setAttribute('else', 1);
      }
      return container;
    },
    /**
     * Parse XML to restore the else-if and else inputs.
     * @param {!Element} xmlElement XML storage element.
     * @this Blockly.Block
     */
     domToMutation: function(xmlElement) {
      var containerBlock = this;
      var valueConnections = [];
      var statementConnections = [];
      var elseStatementConnection = null;
      if (this.elseCount_) {
        if(containerBlock.getInputTargetBlock('ELSE') && containerBlock.getInputTargetBlock('ELSE').previousConnection)
          elseStatementConnection = containerBlock.getInputTargetBlock('ELSE').previousConnection;
        this.removeInput('ELSE');
      }
      for (var i = this.elseifCount_; i > 0; i--) {
        if(containerBlock.getInputTargetBlock('IF' + i) && containerBlock.getInputTargetBlock('IF' + i).previousConnection)
          valueConnections[i] = (containerBlock.getInputTargetBlock('IF' + i).previousConnection);
        else
          valueConnections[i] = null;
        this.removeInput('IF' + i);
        if(containerBlock.getInputTargetBlock('DO' + i) && containerBlock.getInputTargetBlock('DO' + i).previousConnection)
          statementConnections[i] = (containerBlock.getInputTargetBlock('DO' + i).previousConnection);
        else
          statementConnections[i] = null;
        this.removeInput('DO' + i);
      }
      this.elseifCount_ = parseInt(xmlElement.getAttribute('elseif'), 10);
      this.elseCount_ = parseInt(xmlElement.getAttribute('else'), 10);
      //this.compose(containerBlock);
      for (var i = 1; i <= this.elseifCount_; i++) {
        this.appendValueInput('IF' + i)
        .setCheck([Boolean,Number])
        .appendField(Blockly.Msg.CONTROLS_IF_MSG_ELSEIF);
        this.appendStatementInput('DO' + i)
        .appendField(Blockly.Msg.CONTROLS_IF_MSG_THEN);
      }
      if (this.elseCount_) {
        this.appendStatementInput('ELSE')
        .appendField(Blockly.Msg.CONTROLS_IF_MSG_ELSE);
      }
      for(var i = valueConnections.length - 2; i > 0; i--){
        if(valueConnections[i])
          Blockly.Mutator.reconnect(valueConnections[i], this, 'IF' + i);
      }
      for(var i = statementConnections.length - 2; i > 0; i--){
        if(statementConnections[i])
          Blockly.Mutator.reconnect(statementConnections[i], this, 'DO' + i);
      }
    },
    /**
     * Populate the mutator's dialog with this block's components.
     * @param {!Blockly.Workspace} workspace Mutator's workspace.
     * @return {!Blockly.Block} Root block in mutator.
     * @this Blockly.Block
     */
     decompose: function(workspace) {
      var containerBlock = workspace.newBlock('controls_if_if');
      containerBlock.initSvg();
      var connection = containerBlock.getInput('STACK').connection;
      for (var i = 1; i <= this.elseifCount_; i++) {
        var elseifBlock = workspace.newBlock('controls_if_elseif');
        elseifBlock.initSvg();
        connection.connect(elseifBlock.previousConnection);
        connection = elseifBlock.nextConnection;
      }
      if (this.elseCount_) {
        var elseBlock = workspace.newBlock('controls_if_else');
        elseBlock.initSvg();
        connection.connect(elseBlock.previousConnection);
      }
      return containerBlock;
    },
    /**
     * Reconfigure this block based on the mutator dialog's components.
     * @param {!Blockly.Block} containerBlock Root block in mutator.
     * @this Blockly.Block
     */
     compose: function(containerBlock) {
      // Disconnect the else input blocks and remove the inputs.
      if (this.elseCount_) {
        this.removeInput('ELSE');
      }
      this.elseCount_ = 0;
      // Disconnect all the elseif input blocks and remove the inputs.
      for (var i = this.elseifCount_; i > 0; i--) {
        this.removeInput('IF' + i);
        this.removeInput('DO' + i);
      }
      this.elseifCount_ = 0;
      // Rebuild the block's optional inputs.
      var clauseBlock = containerBlock.getInputTargetBlock('STACK');
      var valueConnections = [null];
      var statementConnections = [null];
      var elseStatementConnection = null;
      while (clauseBlock) {
        switch (clauseBlock.type) {
          case 'controls_if_elseif':
          this.elseifCount_++;
          valueConnections.push(clauseBlock.valueConnection_);
          statementConnections.push(clauseBlock.statementConnection_);
          break;
          case 'controls_if_else':
          this.elseCount_++;
          elseStatementConnection = clauseBlock.statementConnection_;
          break;
          default:
          throw TypeError('Unknown block type: ' + clauseBlock.type);
        }
        clauseBlock = clauseBlock.nextConnection &&
        clauseBlock.nextConnection.targetBlock();
      }
  
      this.updateShape_();
      // Reconnect any child blocks.
      this.reconnectChildBlocks_(valueConnections, statementConnections, elseStatementConnection);
  
    },
    /**
     * Store pointers to any connected child blocks.
     * @param {!Blockly.Block} containerBlock Root block in mutator.
     * @this Blockly.Block
     */
     saveConnections: function(containerBlock) {
      var clauseBlock = containerBlock.getInputTargetBlock('STACK');
      var i = 1;
      while (clauseBlock) {
        switch (clauseBlock.type) {
          case 'controls_if_elseif':
          var inputIf = this.getInput('IF' + i);
          var inputDo = this.getInput('DO' + i);
          clauseBlock.valueConnection_ =
          inputIf && inputIf.connection.targetConnection;
          clauseBlock.statementConnection_ =
          inputDo && inputDo.connection.targetConnection;
          i++;
          break;
          case 'controls_if_else':
          var inputDo = this.getInput('ELSE');
          clauseBlock.statementConnection_ =
          inputDo && inputDo.connection.targetConnection;
          break;
          default:
          throw 'Unknown block type.';
        }
        clauseBlock = clauseBlock.nextConnection &&
        clauseBlock.nextConnection.targetBlock();
      }
    },
    /**
     * Reconstructs the block with all child blocks attached.
     */
     rebuildShape_: function() {
      var valueConnections = [null];
      var statementConnections = [null];
      var elseStatementConnection = null;
  
      if (this.getInput('ELSE')) {
        elseStatementConnection = this.getInput('ELSE').connection.targetConnection;
      }
      var i = 1;
      while (this.getInput('IF' + i)) {
        var inputIf = this.getInput('IF' + i);
        var inputDo = this.getInput('DO' + i);
        console.log(inputIf.connection.targetConnection);
        valueConnections.push(inputIf.connection.targetConnection);
        statementConnections.push(inputDo.connection.targetConnection);
        i++;
      }
      this.updateShape_();
      this.reconnectChildBlocks_(valueConnections, statementConnections,elseStatementConnection);
    },
    /**
     * Modify this block to have the correct number of inputs.
     * @this Blockly.Block
     * @private
     */
     updateShape_: function() {
      // Delete everything.
      if (this.getInput('ELSE')) {
        this.removeInput('ELSE');
      }
      var i = 1;
      while (this.getInput('IF' + i)) {
        this.removeInput('IF' + i);
        this.removeInput('DO' + i);
        i++;
      }
      // Rebuild block.
      for (var i = 1; i <= this.elseifCount_; i++) {
        this.appendValueInput('IF' + i)
        .setCheck([Number,Boolean])
        .appendField(Blockly.Msg['CONTROLS_IF_MSG_ELSEIF']);
        this.appendStatementInput('DO' + i)
        .appendField(Blockly.Msg['CONTROLS_IF_MSG_THEN']);
      }
      if (this.elseCount_) {
        this.appendStatementInput('ELSE')
        .appendField(Blockly.Msg['CONTROLS_IF_MSG_ELSE']);
      }
    },
    /**
     * Reconnects child blocks.
     * @param {!Array<?Blockly.RenderedConnection>} valueConnections List of value
     * connectsions for if input.
     * @param {!Array<?Blockly.RenderedConnection>} statementConnections List of
     * statement connections for do input.
     * @param {?Blockly.RenderedConnection} elseStatementConnection Statement
     * connection for else input.
     */
     reconnectChildBlocks_: function(valueConnections, statementConnections,
      elseStatementConnection) {
      for (var i = 1; i <= this.elseifCount_; i++) {
        Blockly.Mutator.reconnect(valueConnections[i], this, 'IF' + i);
        Blockly.Mutator.reconnect(statementConnections[i], this, 'DO' + i);
      }
      Blockly.Mutator.reconnect(elseStatementConnection, this, 'ELSE');
    }
};

Blockly.Blocks['controls_switch_case_ED'] = {
    init: function() {
      this.setColour(Blockly.Blocks.loops.HUE_CRTL);
      this.appendValueInput('IF0')
      .setCheck([Number,Boolean])
      .appendField('switch');
      this.setPreviousStatement(true);
      this.setNextStatement(true);
      this.setHelpUrl("https://mixly.readthedocs.io/zh_CN/latest/arduino/03.Control.html#switch");
      this.setMutator(new Blockly.Mutator(['controls_case',
       'controls_default']));
      this.elseifCount_ = 0;
      this.elseCount_ = 0;
    },
    /**
     * Create XML to represent the number of else-if and else inputs.
     * @return {Element} XML storage element.
     * @this Blockly.Block
     */
     mutationToDom: function() {
      if (!this.elseifCount_ && !this.elseCount_) {
        return null;
      }
      var container = document.createElement('mutation');
      if (this.elseifCount_) {
        container.setAttribute('elseif', this.elseifCount_);
      }
      if (this.elseCount_) {
        container.setAttribute('else', 1);
      }
      return container;
    },
    /**
     * Parse XML to restore the else-if and else inputs.
     * @param {!Element} xmlElement XML storage element.
     * @this Blockly.Block
     */
     domToMutation: function(xmlElement) {
      this.compose(this);
      this.elseifCount_ = parseInt(xmlElement.getAttribute('elseif'), 10);
      this.elseCount_ = parseInt(xmlElement.getAttribute('else'), 10);
      for (var i = 1; i <= this.elseifCount_; i++) {
        this.appendValueInput('IF' + i)
        .setCheck([Number,Boolean])
        .appendField('case');
        this.appendStatementInput('DO' + i)
        .appendField('');
      }
      if (this.elseCount_) {
        this.appendStatementInput('ELSE')
        .appendField('default');
      }
    },
    /**
     * Populate the mutator's dialog with this block's components.
     * @param {!Blockly.Workspace} workspace Mutator's workspace.
     * @return {!Blockly.Block} Root block in mutator.
     * @this Blockly.Block
     */
     decompose: function(workspace) {
      var containerBlock = Blockly.Block.obtain(workspace, 'controls_switch');
      containerBlock.initSvg();
      var connection = containerBlock.getInput('STACK').connection;
      for (var i = 1; i <= this.elseifCount_; i++) {
        var elseifBlock = Blockly.Block.obtain(workspace, 'controls_case');
        elseifBlock.initSvg();
        connection.connect(elseifBlock.previousConnection);
        connection = elseifBlock.nextConnection;
      }
      if (this.elseCount_) {
        var elseBlock = Blockly.Block.obtain(workspace, 'controls_default');
        elseBlock.initSvg();
        connection.connect(elseBlock.previousConnection);
      }
      return containerBlock;
    },
    /**
     * Reconfigure this block based on the mutator dialog's components.
     * @param {!Blockly.Block} containerBlock Root block in mutator.
     * @this Blockly.Block
     */
     compose: function(containerBlock) {
    //  console.log(arguments.callee.caller.name);
      // Disconnect the else input blocks and remove the inputs.
      if (this.elseCount_) {
        this.removeInput('ELSE');
      }
      this.elseCount_ = 0;
      // Disconnect all the elseif input blocks and remove the inputs.
      for (var i = this.elseifCount_; i > 0; i--) {
        this.removeInput('IF' + i);
        this.removeInput('DO' + i);
      }
      this.elseifCount_ = 0;
      // Rebuild the block's optional inputs.
      var clauseBlock = containerBlock.getInputTargetBlock('STACK');
      while (clauseBlock) {
        switch (clauseBlock.type) {
          case 'controls_case':
          this.elseifCount_++;
          var ifInput = this.appendValueInput('IF' + this.elseifCount_)
          .setCheck([Number,Boolean])
          .appendField('case');
          var doInput = this.appendStatementInput('DO' + this.elseifCount_);
          doInput.appendField('');
            // Reconnect any child blocks.
            if (clauseBlock.valueConnection_) {
              ifInput.connection.connect(clauseBlock.valueConnection_);
            }
            if (clauseBlock.statementConnection_) {
              doInput.connection.connect(clauseBlock.statementConnection_);
            }
            break;
            case 'controls_default':
            this.elseCount_++;
            var elseInput = this.appendStatementInput('ELSE');
            elseInput.appendField('default');
            // Reconnect any child blocks.
            if (clauseBlock.statementConnection_) {
              elseInput.connection.connect(clauseBlock.statementConnection_);
            }
            break;
            default:
            throw 'Unknown block type.';
          }
          clauseBlock = clauseBlock.nextConnection &&
          clauseBlock.nextConnection.targetBlock();
        }
      },
    /**
     * Store pointers to any connected child blocks.
     * @param {!Blockly.Block} containerBlock Root block in mutator.
     * @this Blockly.Block
     */
     saveConnections: function(containerBlock) {
      var clauseBlock = containerBlock.getInputTargetBlock('STACK');
      var i = 1;
      while (clauseBlock) {
        switch (clauseBlock.type) {
          case 'controls_case':
          var inputIf = this.getInput('IF' + i);
          var inputDo = this.getInput('DO' + i);
          clauseBlock.valueConnection_ =
          inputIf && inputIf.connection.targetConnection;
          clauseBlock.statementConnection_ =
          inputDo && inputDo.connection.targetConnection;
          i++;
          break;
          case 'controls_default':
          var inputDo = this.getInput('ELSE');
          clauseBlock.statementConnection_ =
          inputDo && inputDo.connection.targetConnection;
          break;
          default:
          throw 'Unknown block type.';
        }
        clauseBlock = clauseBlock.nextConnection &&
        clauseBlock.nextConnection.targetBlock();
      }
    }
};

Blockly.Blocks.espereAteQue = {
    init: function() {
      this.setColour(Blockly.Blocks.loops.HUE_CRTL);
      this.appendValueInput("STAT")
      .appendField("esperar até")
      .setCheck([Number,Boolean]);
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setInputsInline(true);
      this.setTooltip(Blockly.LANG_INOUT_DIGITAL_WRITE_TOOLTIP);
      this.setHelpUrl("https://mixly.readthedocs.io/zh_CN/latest/arduino/02.Input-Output.html#id2");
      this.wiki = {
        'zh-hans': {
          page: ['Arduino AVR', '输入输出', '数字输出']
        }
      };
    }
  };


  Blockly.Blocks.TFT_fillScreen_ED = {
    init: function () {
      this.setColour(Blockly.Blocks.loops.HUE_LCD);
      this.appendDummyInput("")
      .appendField(new Blockly.FieldImage("../../ThirdParty/arduino_Cittius/common/media/keyesAll/4r32.png", 40, 40, { alt: "*", flipRtl: "FALSE" }))
      .appendField("Cor de Fundo:");
      this.appendDummyInput("")
      .appendField("");
      this.appendValueInput("COLOR", Number)
      .setCheck(Number);
      this.setInputsInline(true);
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
    }
  };

Blockly.Blocks.tft_drawPixel_ED = {
    init: function() {
      this.setColour(Blockly.Blocks.loops.HUE_LCD);
      this.appendDummyInput("")
      .appendField(new Blockly.FieldImage("../../ThirdParty/arduino_Cittius/common/media/keyesAll/4r32.png", 40, 40, { alt: "*", flipRtl: "FALSE" }))
      .appendField("Pintar um ponto");
      this.appendValueInput("POS_X", Number)
      .appendField("X:")
      .setCheck(Number);
      this.appendValueInput("POS_Y", Number)
      .appendField("Y:")
      .setCheck(Number);
      this.appendDummyInput("")
      .appendField("Cor:");
      this.appendValueInput("COLOR", Number)
      .setCheck(Number);
      this.setInputsInline(true);
      this.setPreviousStatement(true);
      this.setNextStatement(true);
      this.setTooltip(Blockly.OLED_DRAW_PIXE_TOOLTIP);
    }
  };
  
//显示-TFT-画线
Blockly.Blocks.tft_drawLine_ED = {
  init: function() {
    this.setColour(Blockly.Blocks.loops.HUE_LCD);
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/arduino_Cittius/common/media/keyesAll/4r32.png", 40, 40, { alt: "*", flipRtl: "FALSE" }))
    .appendField("Desenhar LINHA");
    this.appendValueInput("START_X", Number)
    .appendField("X Inicial:")
    .setCheck(Number);
    this.appendValueInput("START_Y", Number)
    .appendField("Y Inicial:")
    .setCheck(Number);
    this.appendValueInput("END_X", Number)
    .appendField("X Final:")
    .setCheck(Number);
    this.appendValueInput("END_Y", Number)
    .appendField("Y Final:")
    .setCheck(Number);
    this.appendDummyInput("")
    .appendField("Cor:");
    this.appendValueInput("COLOR", Number)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip(Blockly.OLED_DRAW_LINE_TOOLTIP);
  }
};


Blockly.Blocks.tft_drawFastLine_ED = {
  init: function() {
    this.setColour(Blockly.Blocks.loops.HUE_LCD);
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/arduino_Cittius/common/media/keyesAll/4r32.png", 40, 40, { alt: "*", flipRtl: "FALSE" }))
    .appendField("Criar um LINHA");
    this.appendValueInput("START_X", Number)
    .appendField("X Inicial:")
    .setCheck(Number);
    this.appendValueInput("START_Y", Number)
    .appendField("Y Inicial")
    .setCheck(Number);
    this.appendValueInput("LENGTH", Number)
    .appendField("Largura:")
    .setCheck(Number);
    this.appendDummyInput("")
    .appendField(new Blockly.FieldDropdown(LINESELECT), "TYPE");
    this.appendDummyInput("")
    .appendField("Cor:");
    this.appendValueInput("COLOR", Number)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
  }
};

//显示-TFT-画长方形
Blockly.Blocks.tft_Rect_ED = {
  init: function() {
    this.setColour(Blockly.Blocks.loops.HUE_LCD);
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/arduino_Cittius/common/media/keyesAll/4r32.png", 40, 40, { alt: "*", flipRtl: "FALSE" }))
    .appendField("Criar Retângulo 1");
    this.appendDummyInput("")
    .appendField(new Blockly.FieldDropdown(DRAWFIll_), "TYPE");
    this.appendValueInput("D0_X", Number)
    .appendField("X:")
    .setCheck(Number);
    this.appendValueInput("D0_Y", Number)
    .appendField("Y:")
    .setCheck(Number);
    this.appendValueInput("WIDTH", Number)
    .appendField("Largura:")
    .setCheck(Number);
    this.appendValueInput("HEIGHT", Number)
    .appendField("Altura:")
    .setCheck(Number);
    this.appendDummyInput("")
    .appendField("Cor:");
    this.appendValueInput("COLOR", Number)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip("x(0~127),y(0~63)");
  }
};

//显示-TFT-画圆角矩形
Blockly.Blocks.tft_RoundRect_ED = {
  init: function() {
    this.setColour(Blockly.Blocks.loops.HUE_LCD);
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/arduino_Cittius/common/media/keyesAll/4r32.png", 40, 40, { alt: "*", flipRtl: "FALSE" }))
    .appendField("Criar Retângulo 2");
    this.appendDummyInput("")
    .appendField(new Blockly.FieldDropdown(DRAWFIll_), "TYPE");
    this.appendValueInput("D0_X", Number)
    .appendField("X:")
    .setCheck(Number);
    this.appendValueInput("D0_Y", Number)
    .appendField("Y:")
    .setCheck(Number);
    this.appendValueInput("WIDTH", Number)
    .appendField("Largura:")
    .setCheck(Number);
    this.appendValueInput("HEIGHT", Number)
    .appendField("Altura:")
    .setCheck(Number);
    this.appendValueInput("RADIUS", Number)
    .appendField("Raio:")
    .setCheck(Number);
    this.appendDummyInput("")
    .appendField("Cor:");
    this.appendValueInput("COLOR", Number)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
  }
};

//显示-TFT-画圆（空心，实心）
Blockly.Blocks.tft_Circle_ED = {
  init: function() {
    this.setColour(Blockly.Blocks.loops.HUE_LCD);
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/arduino_Cittius/common/media/keyesAll/4r32.png", 40, 40, { alt: "*", flipRtl: "FALSE" }))
    .appendField("Criar Circulo");
    this.appendDummyInput("")
    .appendField(new Blockly.FieldDropdown(DRAWFIll_), "TYPE");
    this.appendValueInput("D0_X", Number)
    .appendField("X:")
    .setCheck(Number);
    this.appendValueInput("D0_Y", Number)
    .appendField("Y:")
    .setCheck(Number);
    this.appendValueInput("RADIUS", Number)
    .appendField("Raio:")
    .setCheck(Number);
   // this.appendDummyInput("")
   // .appendField(new Blockly.FieldDropdown(CIRCLEOPTELECT_), "OPT");
    this.appendDummyInput("")
    .appendField("Cor:");
    this.appendValueInput("COLOR", Number)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip("x(0~127),y(0~63)");
  }
};

//显示-TFT-显示字符串
Blockly.Blocks.tft_print_ED = {
  init: function() {
    this.setColour(Blockly.Blocks.loops.HUE_LCD);
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/arduino_Cittius/common/media/keyesAll/4r32.png", 40, 40, { alt: "*", flipRtl: "FALSE" }))
    .appendField("Escrever Texto");
    this.appendValueInput("POS_X", Number)
    .appendField("X:")
    .setCheck(Number);
    this.appendValueInput("POS_Y", Number)
    .appendField("Y:")
    .setCheck(Number);
    this.appendDummyInput("")
    .appendField("Cor:");
    this.appendValueInput("COLOR", Number)
    .setCheck(Number);
    this.appendValueInput("TEXT", String)
    .appendField("Texto:")
    .setCheck([Number, String]);
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip(Blockly.oled_print_tooltip);
  }
};

//显示-TFT-显示字符串
Blockly.Blocks.tft_print_refresh_ED = {
  init: function() {
    this.setColour(Blockly.Blocks.loops.HUE_LCD);
    this.appendDummyInput("")
    .appendField(new Blockly.FieldImage("../../ThirdParty/arduino_Cittius/common/media/keyesAll/4r32.png", 40, 40, { alt: "*", flipRtl: "FALSE" }))
    .appendField("Escrever Texto");
    this.appendValueInput("POS_X", Number)
    .appendField("X:")
    .setCheck(Number);
    this.appendValueInput("POS_Y", Number)
    .appendField(Blockly.OLED_START_Y)
    .setCheck(Number);
    this.appendDummyInput("")
    .appendField(Blockly.Msg.HTML_COLOUR);
    this.appendValueInput("COLOR", Number)
    .setCheck(Number);
    this.appendValueInput("TEXT", String)
    .appendField(Blockly.OLED_STRING)
    .setCheck([Number, String]);
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip(Blockly.oled_print_tooltip);
  }
};