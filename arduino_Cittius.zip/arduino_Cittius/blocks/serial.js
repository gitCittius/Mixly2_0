'use strict';

goog.provide('Blockly.Blocks.serial');

goog.require('Blockly.Blocks');
Blockly.Blocks.serial.HUE = "#7ED321";
Blockly.Blocks['serial_begin'] = {
  init: function() {
    this.setColour(Blockly.Blocks.serial.HUE);
    this.appendValueInput("CONTENT", Number)
    .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
    .appendField(Blockly.MIXLY_SERIAL_BEGIN)
    .setCheck(Number);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setInputsInline(true);
    this.setTooltip(Blockly.MIXLY_TOOLTIP_SERIAL_BEGIN);
    
  }
};

Blockly.Blocks['serial_write'] = {
  init: function () {
    this.setColour(Blockly.Blocks.serial.HUE);
    this.appendValueInput("CONTENT", String)
    .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
    .appendField(Blockly.MIXLY_SERIAL_WRITE);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip(Blockly.Msg.TEXT_WRITE_TOOLTIP);
  }
};

Blockly.Blocks['serial_print'] = {
  init: function() {
   this.setColour(Blockly.Blocks.serial.HUE);
   this.appendValueInput("CONTENT", String)
   .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")

   .appendField(Blockly.MIXLY_SERIAL_PRINT);
   this.appendDummyInput()
   .appendField(new Blockly.FieldDropdown([[Blockly.MIXLY_PRINT_INLINE, "print"],[Blockly.Msg.TEXT_PRINT_Huanhang_TOOLTIP, "println"]]), "new_line");
    
   this.setPreviousStatement(true, null);
   this.setNextStatement(true, null);
   this.setTooltip(Blockly.Msg.TEXT_PRINT_TOOLTIP);
 }
};

Blockly.Blocks['serial_println'] =  {
  init: function() {
   this.setColour(Blockly.Blocks.serial.HUE);
   this.appendValueInput("CONTENT", String)
   .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
   .appendField(Blockly.MIXLY_SERIAL_PRINT)
    .appendField(new Blockly.FieldDropdown([[Blockly.Msg.TEXT_PRINT_Huanhang_TOOLTIP, "println"],[Blockly.MIXLY_PRINT_INLINE, "print"]]), "new_line");
   this.setPreviousStatement(true, null);
   this.setNextStatement(true, null);
   this.setTooltip(Blockly.Msg.TEXT_PRINT_TOOLTIP);
 }
};


Blockly.Blocks['serial_print_num'] = {
 init: function() {
  this.setColour(Blockly.Blocks.serial.HUE);
  this.appendDummyInput()
  .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
  .appendField(Blockly.MIXLY_SERIAL_PRINT)
  .appendField(new Blockly.FieldDropdown([[Blockly.MIXLY_PRINT_INLINE, "print"],[Blockly.Msg.TEXT_PRINT_Huanhang_TOOLTIP, "println"]]), "new_line")
  .appendField(Blockly.MIXLY_NUMBER);
  this.appendValueInput("CONTENT", Number)
  .appendField(new Blockly.FieldDropdown([[Blockly.Msg.MATH_HEX, "HEX"],[Blockly.Msg.MATH_BIN, "BIN"],[Blockly.Msg.MATH_OCT, "OCT"],[Blockly.Msg.MATH_DEC, "DEC"]]), "STAT")
  .setCheck(Number);
  this.setPreviousStatement(true, null);
  this.setNextStatement(true, null);
  this.setInputsInline(true);
  this.setTooltip(Blockly.Msg.TEXT_PRINT_HEX_TOOLTIP);
}
};

Blockly.Blocks['serial_print_hex']=Blockly.Blocks['serial_print_num'];

Blockly.Blocks['serial_available'] = {
  init: function() {
    this.setColour(Blockly.Blocks.serial.HUE);
    this.appendDummyInput()
    .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
    .appendField(Blockly.MIXLY_SERIAL_AVAILABLE);
    this.setOutput(true, Boolean);
    this.setTooltip(Blockly.MIXLY_TOOLTIP_BLOCKGROUP_SERIAL_AVAILABLE);
  }
};

Blockly.Blocks['serial_readstr'] = {
  init: function() {
    this.setColour(Blockly.Blocks.serial.HUE);
    this.appendDummyInput()
    .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
    .appendField(Blockly.MIXLY_SERIAL_READSTR);
    this.setOutput(true, String);
    this.setTooltip(Blockly.MIXLY_TOOLTIP_BLOCKGROUP_SERIAL_READ_STR);
  }
};

Blockly.Blocks['serial_readstr_until'] = {
  init: function() {
    this.setColour(Blockly.Blocks.serial.HUE);
    this.appendValueInput("CONTENT", Number)
    .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
    .appendField(Blockly.MIXLY_SERIAL_READSTR_UNTIL)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setOutput(true, String);
    this.setTooltip(Blockly.MIXLY_TOOLTIP_SERIAL_READSTRUNITL.replace('%1',Blockly.Arduino.valueToCode(this, 'CONTENT',Blockly.Arduino.ORDER_ATOMIC)));
  }
};

Blockly.Blocks['serial_parseInt_Float'] = {
  init: function() {
    this.setColour(Blockly.Blocks.serial.HUE);
    this.appendDummyInput()
    .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
        //.appendField(Blockly.MIXLY_SERIAL_READ)
        .appendField(new Blockly.FieldDropdown([["read", "read"],["peek", "peek"],["parseInt", "parseInt"], ["parseFloat", "parseFloat"]]), "STAT");
        this.setOutput(true, Number);
        var thisBlock = this;
        this.setTooltip(function() {
          var op = thisBlock.getFieldValue('STAT');
          var TOOLTIPS = {
            'parseInt': Blockly.MIXLY_TOOLTIP_BLOCKGROUP_SERIAL_READ_INT,
            'parseFloat': Blockly.MIXLY_TOOLTIP_BLOCKGROUP_SERIAL_READ_FLOAT
          };
          return TOOLTIPS[op];
        });
      }
    };

    Blockly.Blocks['serial_flush'] = {
      init: function() {
       this.setColour(Blockly.Blocks.serial.HUE);
       this.appendDummyInput()
       .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
       .appendField(Blockly.MIXLY_SERIAL_FLUSH);
       this.setPreviousStatement(true, null);
       this.setNextStatement(true, null);
       this.setTooltip(Blockly.MIXLY_TOOLTIP_SERIAL_FLUSH);
     }
   };
   Blockly.Blocks['serial_softserial'] = {
    init: function() {
      this.setColour(Blockly.Blocks.serial.HUE);
      this.appendDummyInput("")
      .appendField(Blockly.MIXLY_SETUP)
      .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select");
      this.appendValueInput("RX", Number)
      .setCheck(Number)
      .appendField("RX#")
      .setAlign(Blockly.ALIGN_RIGHT);
      this.appendValueInput("TX", Number)
      .appendField("TX#")
      .setCheck(Number)
      .setAlign(Blockly.ALIGN_RIGHT);
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setInputsInline(true);
      this.setTooltip(Blockly.MIXLY_TOOLTIP_SOFTSERIAL.replace('%1',Blockly.Arduino.valueToCode(this, 'RX',Blockly.Arduino.ORDER_ATOMIC))
        .replace('%2',Blockly.Arduino.valueToCode(this, 'TX',Blockly.Arduino.ORDER_ATOMIC)));
    }
  };

  Blockly.Blocks['serial_event'] = {
    init: function () {
      this.setColour(Blockly.Blocks.serial.HUE);
      this.appendDummyInput()
      .appendField(new Blockly.FieldDropdown(profile.default.serial_select), "serial_select")
      .appendField(Blockly.MIXLY_SERIAL_EVENT);
      this.appendStatementInput('DO')
      .appendField(Blockly.MIXLY_DO);
      this.setPreviousStatement(true);
      this.setNextStatement(true);
      this.setTooltip(Blockly.MIXLY_TOOLTIP_SERIALEVENT);
    }
  };