'use strict';

goog.provide('Blockly.Python.hardware');

goog.require('Blockly.Python');

Blockly.Python.hardware_arduino_start=function(){
  Blockly.Python.definitions_['import_s4alib'] = 'import s4alib';
  var v = Blockly.Python.valueToCode(this, 'SUB', Blockly.Python.ORDER_ATOMIC);
  // var code= v + '.start()\n';  
  var code = v + ' = s4alib.s4a_start("'+JSFuncs.getCom()+'")\n'; 
  return code;
};

Blockly.Python.inout_highlow = function () {
    // Boolean values HIGH and LOW.
    var code = (this.getFieldValue('BOOL') == 'HIGH') ? '1' : '0';
    return [code, Blockly.Python.ORDER_ATOMIC];
};

Blockly.Python.hardware_arduino_digital_write = function () {
    Blockly.Python.definitions_['import_s4alib'] = 'import s4alib';
    var v = Blockly.Python.valueToCode(this, 'SUB', Blockly.Python.ORDER_ATOMIC);
    var dropdown_pin = Blockly.Python.valueToCode(this, 'PIN', Blockly.Python.ORDER_ATOMIC);
    var dropdown_stat = Blockly.Python.valueToCode(this, 'STAT', Blockly.Python.ORDER_ATOMIC);
    var code = "";
    code += ''+v+'.digital_write('+dropdown_pin+','+ dropdown_stat +')\n'
    return code;
};

Blockly.Python.hardware_arduino_digital_read = function () {
    Blockly.Python.definitions_['import_s4alib'] = 'import s4alib';
    var v = Blockly.Python.valueToCode(this, 'SUB', Blockly.Python.ORDER_ATOMIC);
    var dropdown_pin = Blockly.Python.valueToCode(this, 'PIN', Blockly.Python.ORDER_ATOMIC);
    var code = "";
    code =''+v+'.digital_read('+dropdown_pin+')';
    return [code, Blockly.Python.ORDER_ATOMIC];
};

Blockly.Python.hardware_arduino_analog_read = function () {
    Blockly.Python.definitions_['import_s4alib'] = 'import s4alib';
    var v = Blockly.Python.valueToCode(this, 'SUB', Blockly.Python.ORDER_ATOMIC);
    var dropdown_pin = Blockly.Python.valueToCode(this, 'PIN', Blockly.Python.ORDER_ATOMIC);
    var code = "";
    code =''+v+'.analog_read('+dropdown_pin+')';
    return [code, Blockly.Python.ORDER_ATOMIC];
};

Blockly.Python.hardware_arduino_analog_write = function () {
    Blockly.Python.definitions_['import_s4alib'] = 'import s4alib';
    var v = Blockly.Python.valueToCode(this, 'SUB', Blockly.Python.ORDER_ATOMIC);
    var dropdown_pin = Blockly.Python.valueToCode(this, 'PIN', Blockly.Python.ORDER_ATOMIC);
    var value_num = Blockly.Python.valueToCode(this, 'NUM', Blockly.Python.ORDER_ATOMIC);
    var code = "";
    code += ''+v+'.analog_write('+dropdown_pin+','+ value_num +')\n'
    return code;
};

/*
Blockly.Python.StartRobot_ = function () {
    Blockly.Python.definitions_['import_s4alib'] = 'import serial.tools.list_ports';

    var code = "def list_serial_ports(x):\n"+
    "    ports = list(serial.tools.list_ports.comports())\n"+
    "    for port in ports:\n"+
    "        try:\n"+
    "            if(x==0):\n"+
    "              return(port.device)\n"+
    "            elif(x==1):\n"+
    "                return(port.vid)\n"+
    "            elif(x==2):\n"+
    "                return(port.manufacturer)\n"+
    "            elif(x==3):\n"+
    "                return(port.pid)\n"+
    "            elif(x==4):\n"+
    "                return(port.serial_number)\n"+
    "            elif(x==5):\n"+
    "                return(port.location)\n"+
    "            elif(x==6):\n"+
    "                return(port.product)\n"+
    "            elif(x==7):\n"+
    "                return(port.interface)\n"+
    "            elif(x==8):\n"+
    "                return(port.description)\n"+

    "        except AttributeError:\n"+
    '            print("Intalar a versão 3.4 do pySerial")\n'+
    '            sys.exit(0)\n\n'+
    'print("------- DADOS DA PORTA SERIAL --------")\n'+
    'print("Fabricante: " +list_serial_ports(2))\n'+
    'print("Conectada na porta: " + list_serial_ports(0))\n'+
    'print("USB Vendor ID: " + str(list_serial_ports(1)))\n'+
    'print("USB product ID: " + str(list_serial_ports(3)))\n'+
    'print("USB serial number: " + str(list_serial_ports(4)))\n'+
    'print("USB device location: " + str(list_serial_ports(5)))\n'+
    'print("USB product: " + str(list_serial_ports(6)))\n'+
    'print("Interface specific description: " + str(list_serial_ports(7)))\n'+
    'print("description: " + str(list_serial_ports(8)))\n'+
    'print("------- FIM DOS DADOS DA PORTA SERIAL --------")\n\n\n';
    return code;
};
*/

Blockly.Python.StartRobot_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";


    
    return "ser.write(b'\\x01')\n";
};

Blockly.Python.EndRobot_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";


    
    return "ser.write(b'\\xFE')\n";
};

Blockly.Python.MoveForward_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";
    return "ser.write(b'\\x02')\n";
};

Blockly.Python.MoveRight_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";
    return "ser.write(b'\\x04')\n";
};

Blockly.Python.MoveLeft_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";
    return "ser.write(b'\\x05')\n";
};

Blockly.Python.Move180_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";
    return "ser.write(b'\\x06')\n";
};


Blockly.Python.MoveBack_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";
    return "ser.write(b'\\x03')\n";
};

Blockly.Python.Timer1s_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";
    return "ser.write(b'\\x0B')\n";
};

Blockly.Python.Timer3s_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";
    return "ser.write(b'\\x0C')\n";
};

Blockly.Python.Timer5s_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";
    return "ser.write(b'\\x0D')\n";
};

   
Blockly.Python.Mult2x_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";
    return "ser.write(b'\\x07')\n";
};

Blockly.Python.Mult3x_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";

    return "ser.write(b'\\x08')\n";
};
Blockly.Python.Mult4x_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";

    return "ser.write(b'\\x09')\n";
};
Blockly.Python.Mult5x_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";

    return "ser.write(b'\\x0A')\n";
};
/*
    <block type="Som1_"></block> 
    <block type="Som2_"></block>
    <block type="Som3_"></block>
    <block type="Som4_"></block>
    <block type="Som5_"></block>
    <block type="Som6_"></block>
*/
Blockly.Python.Som1_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";

    return "ser.write(b'\\x0E')\n";
};

Blockly.Python.Som2_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";

    return "ser.write(b'\\x0F')\n";
};

Blockly.Python.Som3_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";

    return "ser.write(b'\\x10')\n";
};

Blockly.Python.Som4_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";

    return "ser.write(b'\\x11')\n";
};

Blockly.Python.Som5_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";

    return "ser.write(b'\\x12')\n";
};

Blockly.Python.Som6_ = function () {
    Blockly.Python.definitions_['import_serial'] = "import serial.tools.list_ports\n"+
    "import time\n\n"+
    "ports = list(serial.tools.list_ports.comports())\n"+
    "for p in ports:\n"+
    "   if 'Arduino Leonardo' in p.description:\n"+
    "     port = p.device\n"+
    "     break\n\n"+
    "ser = serial.Serial(port, 115200)\n\n";

    return "ser.write(b'\\x13')\n";
};

