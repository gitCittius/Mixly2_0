'use strict';

goog.provide('Blockly.Arduino.procedures');

goog.require('Blockly.Arduino');
