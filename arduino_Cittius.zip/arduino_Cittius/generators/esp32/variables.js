'use strict';

goog.provide('Blockly.Arduino.variables');

goog.require('Blockly.Arduino');
