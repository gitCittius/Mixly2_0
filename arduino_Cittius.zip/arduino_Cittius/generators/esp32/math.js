'use strict';

goog.provide('Blockly.Arduino.math');

goog.require('Blockly.Arduino');
