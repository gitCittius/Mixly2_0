'use strict';

goog.provide('Blockly.Arduino.factory');
goog.require('Blockly.Arduino');
