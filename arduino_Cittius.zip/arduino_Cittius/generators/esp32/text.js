'use strict';

goog.provide('Blockly.Arduino.texts');

goog.require('Blockly.Arduino');

