

//----------FUNÇÃO PARA GRAVAR VALORES DE 32BITS NA EEPROM------------------
void EEPROMWritelong(int address, long value)
      {
      //Decomposition from a long to 4 bytes by using bitshift.
      //One = Most significant -> Four = Least significant byte
      byte four = (value & 0xFF);
      byte three = ((value >> 8) & 0xFF);
      //byte two = ((value >> 16) & 0xFF);
      //byte one = ((value >> 24) & 0xFF);

      //Write the 4 bytes into the eeprom memory.
      EEPROM.write(address, four);
      EEPROM.write(address + 1, three);
      //EEPROM.write(address + 2, two);
      //EEPROM.write(address + 3, one);
      }

//This function will return a 4 byte (32bit) long from the eeprom
//at the specified address to address + 3.
long EEPROMReadlong(long address)
      {
      //Read the 4 bytes from the eeprom memory.
      long four = EEPROM.read(address);
      long three = EEPROM.read(address + 1);
      //long two = EEPROM.read(address + 2);
      //long one = EEPROM.read(address + 3);

      //Return the recomposed long by using bitshift.
      //return ((four << 0) & 0xFF) + ((three << 8) & 0xFFFF) + ((two << 16) & 0xFFFFFF) + ((one << 24) & 0xFFFFFFFF);
      return ((four << 0) & 0xFF) + ((three << 8) & 0xFFFF);  
      }
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
void grava_progx(byte pos, String val){     //SERVE PARA GRAVAR UMA SEQUENCIA DE ATIVIDADE NA MEMORIA

  int g_pro = val.toInt();
  if (EEPROM.read(pos) != g_pro) EEPROM.write(pos, g_pro);
  
}
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
byte le_progx(byte pos){     //SERVE PARA LER UMA SEQUENCIA DE ATIVIDADE NA MEMORIA

  byte l_pro = EEPROM.read(pos);

  return l_pro;
}
//----------------------------------------------------------------------------
