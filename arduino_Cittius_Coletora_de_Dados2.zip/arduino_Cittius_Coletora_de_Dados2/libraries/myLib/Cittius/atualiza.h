//------------------------------------------------------

//------------------------------------------------------
void menu2_atual(byte A){
  switch(A){

    case 1:         //MEDIDOR DE TENSÃO
            TENSAO = voltimeter(66);

    break;    

    case 2:         //SENSOR DE CORRENTE
            CORRENTE = corrente(67);
            
    break;

    case 3:         //SENSOR DE TEMPERATURA A PROVA D'ÁGUA
            inicia_temp();
            TEMPERATURA = temp();

    break;

    case 4:         //SENSOR DE PH
            PH = medir_ph(68);

    break;

    case 5:         //SENSOR DE HUMIDADE DO SOLO
            SOLO = hum_solo(69);

    break;    

    case 6:         //SENSOR DE ULTRASSOM
          //  ULTRA = ultra();

    break;

    case 7:         //SENSOR DE FORÇA
           // FORCA = forca(69);
              FORCA = analogRead(A15);
    break;

    case 8:         //SENSOR DE PRESSÃO DIFERENCIAL
            if ((millis() - atual_pf) >= 2000){
              PRES_DIF = P_dif();
              atual_pf = millis();
            }
    break;    

    case 9:        //SENSOR DE EFEITO HALL
            HALL = s_hall(68);

    break;

    case 10:        //SENSOR DE TEMPERATURA E UMIDADE DO AR
            if ((millis() - atual_dht) >= 2000){
              DHTT = dht_temp();
              DHTH = dht_hum();
              atual_dht = millis();
            }
    break; 

    case 11:        //SENSOR DE BATIMENTOS CARDIACOS 
            //BPM = batimentos(67);   //USAR I3 67

    break;       

    case 12:        //SENSOR DE SOM
            SEN_SOM = decib(67);   //USAR I3 67

    break;    

    case 13:        //BUSSOLA
    /*
          if ((millis() - atual_busso) >= 2000){
            if(Flag_bussola == 0) {
              inicia_bussola();
              le_bussola();
            }
              else le_bussola();
            atual_busso = millis();
          }
*/
    break;     
               
  }
}
//------------------------------------------------------

//------------------------------------------------------
void play_atual(String AA){

int A = AA.toInt();
  
  switch(A){

    case 1:         //MEDIDOR DE TENSÃO
            //TENSAO = voltimeter(66);

    break;    

    case 15:         //SENSOR DE CORRENTE
            CORRENTE = corrente(67);
            
    break;

    case 14:         //SENSOR DE TEMPERATURA A PROVA D'ÁGUA
            inicia_temp();
            TEMPERATURA = temp();

    break;

    case 23:         //SENSOR DE PH
            PH = medir_ph(68);

    break;

    case 18:         //SENSOR DE HUMIDADE DO SOLO
            SOLO = hum_solo(69);

    break;    

    case 22:         //SENSOR DE ULTRASSOM
           // ULTRA = ultra();

    break;

    case 21:         //SENSOR DE FORÇA
            FORCA = forca(69);

    break;

    case 17:         //SENSOR DE PRESSÃO DIFERENCIAL
            if ((millis() - atual_pf) >= 2000){
              PRES_DIF = P_dif();
              atual_pf = millis();
            }
    break;    

    case 19:        //SENSOR DE EFEITO HALL
            HALL = s_hall(68);

    break;

    case 13:        //SENSOR DE TEMPERATURA E UMIDADE DO AR
            if ((millis() - atual_dht) >= 2000){
              DHTT = dht_temp();
              DHTH = dht_hum();
              atual_dht = millis();
            }
    break; 

    case 16:        //SENSOR DE BATIMENTOS CARDIACOS 
            BPM2 = "90";

    break;       

    case 20:        //SENSOR DE SOM
            SEN_SOM = decib(67);   //USAR I3 67

    break;    

    case 12:        //BUSSOLA
            BUSSOLA_ang = "20.00";
    break;     
               
  }
}
//------------------------------------------------------


//------------------------------------------------------
void var_out(byte A, boolean B){

  A = A * B;
  
  switch(A){
    case 0:
            //Serial.println("nao envia");
            break;

    case 1:         //MEDIDOR DE TENSÃO
        if(flagSetupDC==false){ pinMode(A12, INPUT_PULLUP); flagSetupDC=true;}
        if(analogRead(A12)>=1000){
             dataString = dataString + (String(0) + ",");
        }else{
            dataString = dataString + (String(analogRead(A12)) + ",");
        }
        break;   
            //dataString = dataString + (String(1) + ","); break;  

    case 2:         //SENSOR DE CORRENTE
        if(analogRead(A14)>=1020){
                dataString = dataString + (String(0) + ",");
        }else{
                dataString = dataString + (String(CORRENTE) + ",");
        }
             break;
            //dataString = dataString + (String(17.00) + ","); break; 

    case 3:         //SENSOR DE TEMPERATURA A PROVA D'ÁGUA
            dataString = dataString + (String(TEMPERATURA) + ","); break;
            //dataString = dataString + (String(-127.00) + ","); break; 

    case 4:         //SENSOR DE PH
            dataString = dataString + (String(PH) + ","); break;
            //dataString = dataString + (String(4) + ","); break; 

    case 5:         //SENSOR DE HUMIDADE DO SOLO
            dataString = dataString + (String(SOLO) + ","); break;   
            //dataString = dataString + (String(5) + ","); break;  

    case 6:         //SENSOR DE ULTRASSOM
            dataString = dataString + (String(ULTRA) + ","); break; 
            //dataString = dataString + (String(6) + ","); break; 

    case 7:         //SENSOR DE FORÇA
            dataString = dataString + (String(FORCA) + ","); break;
            //dataString = dataString + (String(7) + ","); break; 

    case 8:         //SENSOR DE PRESSÃO DIFERENCIAL
            dataString = dataString + (String(PRES_DIF) + ","); break;
            //dataString = dataString + (String(8) + ","); break;    

    case 9:        //SENSOR DE EFEITO HALL
            dataString = dataString + (String(HALL) + ","); break;
            //dataString = dataString + (String(9) + ","); break; 

    case 10:        //SENSOR DE TEMPERATURA E UMIDADE DO AR
            dataString = dataString + (String(DHTT) + "," + String(DHTH) + ","); break; 
            //dataString = dataString + (String(101) + "," + String(102) + ","); break;

    case 11:        //SENSOR DE BATIMENTOS CARDIACOS 
            //dataString = dataString + (String(BPM) + ","); break;      
            //dataString = dataString + (String(11) + ","); break; 

    case 12:        //SENSOR DE SOM
            dataString = dataString + (String(SEN_SOM) + ","); break;
            //dataString = dataString + (String(12) + ","); break;    

    case 13:        //BUSSOLA
          dataString = dataString + ("BUSSOLA,"); break;   
          //dataString = dataString + (String(13) + ","); break; 
               
  }
}
//------------------------------------------------------
