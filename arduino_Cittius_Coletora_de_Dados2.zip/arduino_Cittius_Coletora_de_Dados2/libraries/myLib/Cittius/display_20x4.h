#include <LiquidCrystal_I2C.h>
//String  Vsoft       = "V2.3"; //VERSÃO DA PROGRAMAÇÃO

#define linha 4
#define colunas 20

byte lcdAddress = 0x3F;        // Variavel que recebe o endereço I2C do chip de expansão de IO, os endereços possíveis são 0x27 ou 0x3F
LiquidCrystal_I2C *lcd = NULL; // Não sei o que significa, mas cria um objeto "Livre" para o display. É bem interessante e deve ser estudado para Sensores do médio em robotica




//------------------------------------------------------
void inicializar(){
  
    lcd->setCursor(7,0);
    lcd->print(F("CITTIUS"));

    lcd->setCursor(2,1);
    lcd->print(F("COLETOR DE DADOS"));  

    //lcd->setCursor(5,3);
    //lcd->print(F("(GENERICO)"));       
}
//------------------------------------------------------


//------------------------------------------------------
void versao(boolean a, byte b){

  if(a == 0){
    lcd->setCursor(0,0);
    lcd->print(Vsoft);
    lcd->setCursor(0,2);
    lcd->print(materia_X [b]); 
  }
  else if(a == 1){
    lcd->setCursor(0,2);
    lcd->print(materia_X [b]);    
  }
}
//------------------------------------------------------

//------------------------------------------------------
void tela_zerar_eeprom(int a, boolean b){

  if(b == 0){
    lcd->setCursor(0,0);
    lcd->print(F("   INICIAR EEPROM   "));

    delay(1500);
    
    lcd->setCursor(0,1);
    lcd->print(F("TAMANHO =           "));
    lcd->setCursor(10,1);
    lcd->print(a);
    lcd->setCursor(0,2);
    lcd->print(F("POSICAO =           "));    
    }

  if(b == 1){
    lcd->setCursor(0,2);
    lcd->print(F("AJUSTE OK           "));
    delay(1500);  
    lcd->setCursor(0,3);
    lcd->print(F("APERTE ENTER        "));          
  }

    
}
//------------------------------------------------------


//------------------------------------------------------
void menu3(byte nnn, boolean mmm){        // MENU 2 OU SETUP DE DADOS

  switch (nnn){
    case 1:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Tensao DC         I4");
        lcd->setCursor(0,2);
        lcd->print("Enviar ?            "); 
        if (mmm == 0) {
          lcd->setCursor(0,3);
          lcd->print("NAO"); 
        }
        else {
          lcd->setCursor(0,3);
          lcd->print("SIM"); 
        }
        Flag_menu3ok = 1;
      }
    }
    break;

    case 2:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Corrente AC       I3"); 
        lcd->setCursor(0,2);
        lcd->print("Enviar ?            "); 
        if (mmm == 0) {
          lcd->setCursor(0,3);
          lcd->print("NAO"); 
        }
        else {
          lcd->setCursor(0,3);
          lcd->print("SIM"); 
        }        
        Flag_menu3ok = 1;
      }                    
    }
    break;  

    case 3:{ 
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Temperatura       M1");
        lcd->setCursor(0,2);
        lcd->print("Enviar ?            "); 
        if (mmm == 0) {
          lcd->setCursor(0,3);
          lcd->print("NAO"); 
        }
        else {
          lcd->setCursor(0,3);
          lcd->print("SIM"); 
        }        
        Flag_menu3ok = 1;
      }                      
    }
    break;

    case 4:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Medidor PH        I2");
        lcd->setCursor(0,2);
        lcd->print("Enviar ?            "); 
        if (mmm == 0) {
          lcd->setCursor(0,3);
          lcd->print("NAO"); 
        }
        else {
          lcd->setCursor(0,3);
          lcd->print("SIM"); 
        }        
        Flag_menu3ok = 1;
      }                      
    }
    break;  

    case 5:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Umidade Solo      I1");
        lcd->setCursor(0,2);
        lcd->print("Enviar ?            "); 
        if (mmm == 0) {
          lcd->setCursor(0,3);
          lcd->print("NAO"); 
        }
        else {
          lcd->setCursor(0,3);
          lcd->print("SIM"); 
        }        
        Flag_menu3ok = 1;
      }                    
    }
    break;

    case 6:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Ultrassom         M4");
        lcd->setCursor(0,2);
        lcd->print("Enviar ?            "); 
        if (mmm == 0) {
          lcd->setCursor(0,3);
          lcd->print("NAO"); 
        }
        else {
          lcd->setCursor(0,3);
          lcd->print("SIM"); 
        }        
        Flag_menu3ok = 1;
      }                     
    }
    break;  

    case 7:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Forca             I1");
        lcd->setCursor(0,2);
        lcd->print("Enviar ?            "); 
        if (mmm == 0) {
          lcd->setCursor(0,3);
          lcd->print("NAO"); 
        }
        else {
          lcd->setCursor(0,3);
          lcd->print("SIM"); 
        }        
        Flag_menu3ok = 1;
      }                    
    }
    break; 

    case 8:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Pressao Dif.      M3");
        lcd->setCursor(0,2);
        lcd->print("Enviar ?            "); 
        if (mmm == 0) {
          lcd->setCursor(0,3);
          lcd->print("NAO"); 
        }
        else {
          lcd->setCursor(0,3);
          lcd->print("SIM"); 
        }        
        Flag_menu3ok = 1;
      }                     
    }
    break;

    case 9:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Sensor Hall       I2");
        lcd->setCursor(0,2);
        lcd->print("Enviar ?            "); 
        if (mmm == 0) {
          lcd->setCursor(0,3);
          lcd->print("NAO"); 
        }
        else {
          lcd->setCursor(0,3);
          lcd->print("SIM"); 
        }        
        Flag_menu3ok = 1;
      }                    
    }
    break;  

    case 10:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Sens. Umidade     I2");
        lcd->setCursor(0,2);
        lcd->print("Enviar ?            "); 
        if (mmm == 0) {
          lcd->setCursor(0,3);
          lcd->print("NAO"); 
        }
        else {
          lcd->setCursor(0,3);
          lcd->print("SIM"); 
        }        
        Flag_menu3ok = 1;
      }                    
    }
    break;   

    case 11:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Batim. Cardiacos  I3");
        lcd->setCursor(0,2);
        lcd->print("Enviar ?            "); 
        if (mmm == 0) {
          lcd->setCursor(0,3);
          lcd->print("NAO"); 
        }
        else {
          lcd->setCursor(0,3);
          lcd->print("SIM"); 
        }        
        Flag_menu3ok = 1;
      }                    
    }
    break;     

    case 12:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Sensor De Som     I3");
        lcd->setCursor(0,2);
        lcd->print("Enviar ?            "); 
        if (mmm == 0) {
          lcd->setCursor(0,3);
          lcd->print("NAO"); 
        }
        else {
          lcd->setCursor(0,3);
          lcd->print("SIM"); 
        }        
        Flag_menu3ok = 1;
      }                    
    }
    break;  

    case 13:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Bussola           I4");
        lcd->setCursor(0,2);
        lcd->print("Enviar ?            "); 
        if (mmm == 0) {
          lcd->setCursor(0,3);
          lcd->print("NAO"); 
        }
        else {
          lcd->setCursor(0,3);
          lcd->print("SIM"); 
        }        
        Flag_menu3ok = 1;
      }                    
    }
    break;                   

}}
//------------------------------------------------------

//------------------------------------------------------
void menu2(byte nn){        // MENU 1 OU LER SENSORES

  switch (nn){
    case 1:{
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(6,0);
        lcd->print("I1-Forca");

        lcd->setCursor(4,3);
        lcd->print("Excel -> CH1");
        pinMode(A15,INPUT_PULLUP);
        Flag_menu2ok = 1;
      }
      else{
        float calculo3;
        calculo3 = map(analogRead(A15),222,1023,0,50) / 9.81;

        if(calculo3 >= 5.00){
          lcd->setCursor(7,1);
          lcd->print("ERRO    ");
        }else{
          lcd->setCursor(7,1);
          sprintf(strNumero,"%02d.%02dkg",(int)calculo3,(int)(calculo3 * 100) % 100);
          lcd->print(strNumero);
        }

      }                     
    }
    break;

    case 2:{
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA

        lcd->setCursor(3,0);
        lcd->print("I2-Corrente AC");

        lcd->setCursor(4,3);
        lcd->print("Excel -> CH2");

        Flag_menu2ok = 1;
      }
      else{
        if(analogRead(A14)>=1022){
          lcd->setCursor(7,1);
          lcd->print(" ERRO        ");
        }else{
          lcd->setCursor(7,1);
          lcd->print(CORRENTE + "A   ");
        }
        }                   
    }
    break;  

    case 3:{ 
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA

        lcd->setCursor(0,0);
        lcd->print("I3-Temp Prova d'Agua");

        lcd->setCursor(4,3);
        lcd->print("Excel -> CH3");

        Flag_menu2ok = 1;
      }
      else{
        if(TEMPERATURA.toFloat()==-127.00){
          lcd->setCursor(7,1);
          lcd->print(" ERRO        ");
        }else{
          lcd->setCursor(7,1);
          lcd->print(TEMPERATURA + (char)223 + "C   "); 
        }
        }                   
    }
    break;

    case 4:{
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Medidor PH        I2");
        lcd->setCursor(0,2);
        lcd->print("Val:                ");
        Flag_menu2ok = 1;
      }
      else{
          lcd->setCursor(5,2);
          lcd->print(PH + "   ");    
      }                      
    }
    break;  

    case 5:{
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Umidade Solo      I1");
        lcd->setCursor(0,2);
        lcd->print("Val:                "); 
        Flag_menu2ok = 1;
      }
      else{
          lcd->setCursor(5,2);
          lcd->print(SOLO + "%   ");    
      }                     
    }
    break;

    case 6:/* {
     if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("    I4-Distancia   ");
        Flag_menu2ok = 1;
      }
      else{
          if(float(ultra()) <= 3){
            lcd->setCursor(6,1);
            lcd->print("ERRO    ");
          }else{
            lcd->setCursor(6,1);
            lcd->print(ULTRA + "cm   ");
          }
      }                      
    }*/
    break;  

  

    case 8:{
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Pressao Dif.      M3");
        lcd->setCursor(0,2);
        lcd->print("Val:                ");
        Flag_menu2ok = 1;
      }
      else{
          lcd->setCursor(5,2);
          lcd->print(PRES_DIF + "m   ");    
      }                      
    }
    break;

    case 9:{
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Sensor Hall       I2");
        lcd->setCursor(0,2);
        lcd->print("Val:                "); 
        Flag_menu2ok = 1;
      }
      else{
          lcd->setCursor(5,2);
          lcd->print(HALL + "      ");    
      }                     
    }
    break;     

    case 10:{
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("I2 -S.Temp & Umidade");
        
        Flag_menu2ok = 1;
      }
      else{
          lcd->setCursor(7,1);
          lcd->print(DHTT + (char)223 + "C   ");
          lcd->setCursor(7,2);
          lcd->print(DHTH + "%   ");    
      }                     
    }
    break;   


// RETIRAR -----------------------------------------------------------------------|
//                                                                                |
    case 11:{
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Batim. Cardiacos  I3");
        lcd->setCursor(0,2);
        lcd->print("Val:                ");        
        Flag_menu2ok = 1;
      }
      else{
          lcd->setCursor(5,2);
          //lcd->print(BPM + "BPM   ");   
      }                     
    }
    break;  
//                                                                                |     
// RETIRAR -----------------------------------------------------------------------|   

    case 12:{
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Sensor De Som     I3");
        lcd->setCursor(0,2);
        lcd->print("Val:                ");        
        Flag_menu2ok = 1;
      }
      else{
          lcd->setCursor(5,2);
          lcd->print(SEN_SOM + "db    ");   
      }                     
    }
    break;  

    case 13:{
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Bussola           I4");
        //lcd->setCursor(0,2);
        //lcd->print("Val:                ");        
        Flag_menu2ok = 1;
      }
//      else{
//          lcd->setCursor(5,2);
//          lcd->print(SEN_SOM + "db    ");   
//      }                     
    }
    break;                  

}}
//------------------------------------------------------

//------------------------------------------------------
void menu(byte n){

  switch (n){
    case 1:{
          lcd->setCursor(0,3);
          lcd->write(2);      
          lcd->setCursor(1,0);
          lcd->print(F(">1)LER SENSORES    "));
          lcd->setCursor(1,1);
          lcd->print(F(" 2)SENSOR ESPECIAL ")); 
          lcd->setCursor(1,2);
          lcd->print(F(" 3)SETUP DOS DADOS "));
          lcd->setCursor(1,3);
          lcd->print(F(" 4)ENVIAR DADOS    "));                 
    }
    break;

    case 2:{
          lcd->setCursor(0,3);
          lcd->write(2);      
          lcd->setCursor(1,0);
          lcd->print(F(" 1)LER SENSORES    "));
          lcd->setCursor(1,1);
          lcd->print(F(">2)SENSOR ESPECIAL ")); 
          lcd->setCursor(1,2);
          lcd->print(F(" 3)SETUP DOS DADOS "));
          lcd->setCursor(1,3);
          lcd->print(F(" 4)ENVIAR DADOS    "));                           
    }
    break;    

    case 3:{
          lcd->setCursor(0,3);
          lcd->write(2);      
          lcd->setCursor(1,0);
          lcd->print(F(" 1)LER SENSORES    "));
          lcd->setCursor(1,1);
          lcd->print(F(" 2)SENSOR ESPECIAL ")); 
          lcd->setCursor(1,2);
          lcd->print(F(">3)SETUP DOS DADOS "));
          lcd->setCursor(1,3);
          lcd->print(F(" 4)ENVIAR DADOS    "));                     
    }
    break;  

    case 4:{
          lcd->setCursor(0,3);
          lcd->write(2);
          lcd->setCursor(0,0);
          lcd->print(" ");      
          lcd->setCursor(1,0);
          lcd->print(F(" 1)LER SENSORES    "));
          lcd->setCursor(1,1);
          lcd->print(F(" 2)SENSOR ESPECIAL ")); 
          lcd->setCursor(1,2);
          lcd->print(F(" 3)SETUP DOS DADOS "));
          lcd->setCursor(1,3);
          lcd->print(F(">4)ENVIAR DADOS    "));                     
    }
    break;    

    case 5:{
          lcd->setCursor(0,0);
          lcd->write(1);
          lcd->setCursor(0,3);
          lcd->print(" ");
          lcd->setCursor(1,0);
          lcd->print(F(">5)PROGRAM CARTAS  "));
          lcd->setCursor(1,1);
          lcd->print(F(" 6)CONFIG SENSOR   "));
          lcd->setCursor(1,2);
          lcd->print(F(" 7)PROGRAM MIXLY   "));
          lcd->setCursor(1,3);
          lcd->print(F(" 8)                "));                     
    }
    break;   

    case 6:{
          lcd->setCursor(1,0);
          lcd->print(F(" 5)PROGRAM CARTAS  "));
          lcd->setCursor(1,1);
          lcd->print(F(">6)CONFIG SENSOR   "));
          lcd->setCursor(1,2);
          lcd->print(F(" 7)PROGRAM MIXLY   "));
          lcd->setCursor(1,3);
          lcd->print(F(" 8)                ")); ;                     
    }
    break;     

    case 7:{
          lcd->setCursor(1,0);
          lcd->print(F(" 5)PROGRAM CARTAS  "));
          lcd->setCursor(1,1);
          lcd->print(F(" 6)CONFIG SENSOR   ")); 
          lcd->setCursor(1,2);
          lcd->print(F(">7)PROGRAM MIXLY   "));
          lcd->setCursor(1,3);
          lcd->print(F(" 8)                "));                     
    }
    break; 

    case 8:{
          lcd->setCursor(1,0);
          lcd->print(F(" 5)PROGRAM CARTAS  "));
          lcd->setCursor(1,1);
          lcd->print(F(" 6)CONFIG SENSOR   ")); 
          lcd->setCursor(1,2);
          lcd->print(F(" 7)PROGRAM MIXLY   "));
          lcd->setCursor(1,3);
          lcd->print(F(">8)                "));                     
    }
    break;      
  }  
  
}
//------------------------------------------------------

//------------------------------------------------------
void menu4(byte n4){

  switch (n4){
    case 1:{
          lcd->setCursor(1,0);
          lcd->print(F(">1)BATIMENTOS CARDI"));
          lcd->setCursor(1,1);
          lcd->print(F(" 2)BUSSOLA         ")); 
          lcd->setCursor(1,2);
          lcd->print(F(" 3)RPM             "));
          lcd->setCursor(1,3);
          lcd->print(F(" 4)                "));                 
    }
    break;

    case 2:{
          lcd->setCursor(1,0);
          lcd->print(F(" 1)BATIMENTOS CARDI"));
          lcd->setCursor(1,1);
          lcd->print(F(">2)BUSSOLA         ")); 
          lcd->setCursor(1,2);
          lcd->print(F(" 3)RPM             "));
          lcd->setCursor(1,3);
          lcd->print(F(" 4)                "));                           
    }
    break;    

    case 3:{

          lcd->setCursor(1,0);
          lcd->print(F(" 1)BATIMENTOS CARDI"));
          lcd->setCursor(1,1);
          lcd->print(F(" 2)BUSSOLA         ")); 
          lcd->setCursor(1,2);
          lcd->print(F(">3)RPM             "));
          lcd->setCursor(1,3);
          lcd->print(F(" 4)                "));                     
    }
    break;
  }}
//------------------------------------------------------

//------------------------------------------------------
void menu5(byte n5){

  switch (n5){
    case 1:{
          lcd->setCursor(1,0);
          lcd->print(F(">1)CALIBRAR PH     "));
          lcd->setCursor(1,1);
          lcd->print(F(" 2)SENSOR CORRENTE ")); 
          lcd->setCursor(1,2);
          lcd->print(F(" 3)CALIBRAR BUSSOLA"));
          lcd->setCursor(1,3);
          lcd->print(F(" 4)SENSOR DE SOM   "));                 
    }
    break;

    case 2:{
          lcd->setCursor(1,0);
          lcd->print(F(" 1)CALIBRAR PH     "));
          lcd->setCursor(1,1);
          lcd->print(F(">2)SENSOR CORRENTE ")); 
          lcd->setCursor(1,2);
          lcd->print(F(" 3)CALIBRAR BUSSOLA"));
          lcd->setCursor(1,3);
          lcd->print(F(" 4)SENSOR DE SOM   "));                           
    }
    break;    

    case 3:{
          lcd->setCursor(1,0);
          lcd->print(F(" 1)CALIBRAR PH     "));
          lcd->setCursor(1,1);
          lcd->print(F(" 2)SENSOR CORRENTE ")); 
          lcd->setCursor(1,2);
          lcd->print(F(">3)CALIBRAR BUSSOLA"));
          lcd->setCursor(1,3);
          lcd->print(F(" 4)SENSOR DE SOM   "));                     
    }
    break;

    case 4:{
          lcd->setCursor(1,0);
          lcd->print(F(" 1)CALIBRAR PH     "));
          lcd->setCursor(1,1);
          lcd->print(F(" 2)SENSOR CORRENTE ")); 
          lcd->setCursor(1,2);
          lcd->print(F(" 3)CALIBRAR BUSSOLA"));
          lcd->setCursor(1,3);
          lcd->print(F(">4)SENSOR DE SOM   "));                     
    }
    break;    
  }}
//------------------------------------------------------  

//------------------------------------------------------
void escreve_cards(){
  
        Seq_PLAY [N_CARD] = Nome_card(rfid_card,0);                 // GERA A SEQUENCIA DE ATIVIDADE BASEADO NO NOME DO CARTAO
        Seq_CARD [N_CARD] = rfid_card;                              // VETOR QUE RECEBE O NOME DA SEQUENCIA DOS CARTOES PASSADOS -----------------------> VAI PODER RETIRAR NO FIM DA PROGRAMAÇÃO 
        
        //Serial.print("codigo DO CARTÃO : ");
        //Serial.println(rfid_card);

        //Serial.print("NOME DO PLAY : ");
        //Serial.println(Nome_card(rfid_card,0));
        
        N_CARD += 1;

        Serial.print("n card = ");
        Serial.println(N_CARD);
        
        if ((tamanho_total + tamanho) < 19){
          lcd->setCursor(1 + tamanho_total,1);
          if ((Flag_print_ref  == 1)&&(N_CARD == 3)) lcd->print(convert_val);
              else lcd->print(Nome_card(rfid_card,1));
          tamanho_total = tamanho_total + tamanho;
        }        
        else if ((tamanho_total2 + tamanho) < 19){
          lcd->setCursor(0,1);
          lcd->print(F(" "));
          lcd->setCursor(0,2);
          lcd->print(F(":")); 
          lcd->setCursor(1 + tamanho_total2,2);
          if (Flag_print_ref  == 1) lcd->print(convert_val);
              else lcd->print(Nome_card(rfid_card,1));
          tamanho_total2 = tamanho_total2 + tamanho;
        }        
        else if ((tamanho_total3 + tamanho) < 19){
          lcd->setCursor(0,2);
          lcd->print(F(" "));
          lcd->setCursor(0,3);
          lcd->print(F(":")); 
          lcd->setCursor(1 + tamanho_total3,3);
          if (Flag_print_ref  == 1) lcd->print(convert_val);
              else lcd->print(Nome_card(rfid_card,1));
          tamanho_total3 = tamanho_total3 + tamanho;
        }              
        
        lcd->setCursor(17,0);  
        lcd->print(N_CARD);
}
//------------------------------------------------------

//------------------------------------------------------
void calibracao_PH(byte pos1, byte ok){

  if(flag == 0){
    lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
    lcd->setCursor(0,0);
    lcd->print(F("Calibrar PH         "));
    flag = 1;
  }else{
    PH = medir_ph(68);
    lcd->setCursor(13,0);
    lcd->print(String(PH) + "  ");    
  }
  
  switch (pos1){
    case 1:{
      if(ok == 0){
          lcd->setCursor(0,1);
          lcd->print(F(">1 Colocar PH 4")); 
          lcd->setCursor(0,2);
          lcd->print(F(" 2 Colocar PH 7"));
          lcd->setCursor(0,3);
          lcd->print(F(" 3 Colocar PH 10"));     
      }
      else{
          lcd->setCursor(18,1);
          lcd->print(F("OK"));                     
      }
    }
    break;

    case 2:{
      if(ok == 0){      
          lcd->setCursor(0,1);
          lcd->print(F(" 1 Colocar PH 4")); 
          lcd->setCursor(0,2);
          lcd->print(F(">2 Colocar PH 7"));
          lcd->setCursor(0,3);
          lcd->print(F(" 3 Colocar PH 10"));  
      }
      else{
          lcd->setCursor(18,2);
          lcd->print(F("OK"));                     
      }                                  
    }
    break;    

    case 3:{
      if(ok == 0){      
          lcd->setCursor(0,1);
          lcd->print(F(" 1 Colocar PH 4")); 
          lcd->setCursor(0,2);
          lcd->print(F(" 2 Colocar PH 7"));
          lcd->setCursor(0,3);
          lcd->print(F(">3 Colocar PH 10")); 
      }
      else{
          lcd->setCursor(18,3);
          lcd->print(F("OK"));                     
      }                               
    }
    break;

    case 4:
    break;

    default:
           flag = 0;
    break;
  
}}
//------------------------------------------------------

//*****************************************************************************************//
//                        FUNÇÃO PARA SEQUENCIA DAS ATIVIDADES
//*****************************************************************************************//

void PLAY(String a){

int p_play = a.toInt();

 //Serial.print(F("P_PLAY = "));
 //Serial.println(p_play);

 switch (p_play){
  case 1:
  Serial.println("caso 1");   // ON
  if(flag_comparacao == 1) flag_on_off = 1;
    else flag_on_off = 2;
  N_PLAY += 1;
  break;
  
  case 2:
  Serial.println("caso 2");   // OFF
  if(flag_comparacao == 1) flag_on_off = 3;
    else flag_on_off = 4;  
  N_PLAY += 1;
  break;
  
  case 3:
  Serial.println("caso 3");
  N_PLAY += 1;
  break;
  
  case 4:
  Serial.println("caso 4");
  if (FlagDelay1 == 0){
    FlagDelay1 = 1;
    D_elay1 = millis();
  }

  if((millis() - D_elay1) > 1000){ 
    N_PLAY += 1;
    FlagDelay1 = 0;
    D_elay1 = 0;
  }
  break;    
  
  case 5:  
  Serial.println("caso 5");
  if (FlagDelay2 == 0){
    FlagDelay2 = 1;
    D_elay2 = millis();
  }

  if((millis() - D_elay2) > 3000){ 
    N_PLAY += 1;
    FlagDelay2 = 0;
    D_elay2 = 0;
  }
  break;
      
  case 6:   
  Serial.println("caso 6");
  if (FlagDelay3 == 0){
    FlagDelay3 = 1;
    D_elay3 = millis();
  }

  if((millis() - D_elay3) > 5000){ 
    N_PLAY += 1;
    FlagDelay3 = 0;
    D_elay3 = 0;
  }
  break;
    
  case 7:
  Serial.print("caso 7 = ");
  Serial.println(flag_on_off);
  switch(flag_on_off){
    case 1:
          tone(BUZ,1000,50);
          delay(50);
    break;

    case 2:
    break;

    case 3:
    break;

    case 4:
          tone(BUZ,1000,50);
          delay(50);    
    break;
  }

  N_PLAY += 1;
  break;
    
  case 8:
  Serial.println("caso 8");
  switch(flag_on_off){
    case 1:
          digitalWrite(A6, 1);  // aciona o LED com o valor 
    break;

    case 2:
          digitalWrite(A6, 0);  // aciona o LED com o valor     
    break;

    case 3:
          digitalWrite(A6, 0);  // aciona o LED com o valor     
    break;

    case 4:
          digitalWrite(A6, 1);  // aciona o LED com o valor   
    break;
  }
  
  N_PLAY += 1;
  break;
    
  case 9:
  Serial.println("caso 9");
  lcd->setCursor(10,2);
  lcd->print(">");  
  if(val_sensor_play > val_ref_sensor){
    flag_comparacao = 1;
    //N_PLAY += 1;
  }
    else flag_comparacao = 0;  
    
  N_PLAY += 1;     
  break;
    
  case 10:
  Serial.println("caso 10");
  lcd->setCursor(10,2);
  lcd->print("<");  
  if(val_sensor_play < val_ref_sensor){
    flag_comparacao = 1;
    //N_PLAY += 1;
  }
    else flag_comparacao = 0; 
    
  N_PLAY += 1;    
  break;
    
  case 11:
  Serial.println("caso 11");
  lcd->setCursor(10,2);
  lcd->print("=");  
  if(val_sensor_play = val_ref_sensor){
    flag_comparacao = 1;
    //N_PLAY += 1;
  }
    else flag_comparacao = 0;
    
  N_PLAY += 1;     
  break;
    
  case 12:    // --------------------------------------------- BUSSOLA
  Serial.println("caso 12");
  
  lcd->setCursor(0,1);
  lcd->print("Bussola           I4");  
  val_sensor_play = BUSSOLA_ang.toFloat();     // aqui chama a leitura do sensor

  lcd->setCursor(0,2);
  lcd->print(val_sensor_play); 

  lcd->setCursor(12,2);
  lcd->print(val_ref_sensor);  
  
  N_PLAY += 1;
  break;
    
  case 13:    // --------------------------------------------- TEMPERATURA E UMIDDADE
  Serial.println("caso 13");
  
  lcd->setCursor(0,1);
  lcd->print("Sens. Umidade     I2");  
  val_sensor_play = DHTH.toFloat();     // aqui chama a leitura do sensor

  lcd->setCursor(0,2);
  lcd->print(val_sensor_play); 

  lcd->setCursor(12,2);
  lcd->print(val_ref_sensor);  
   
  N_PLAY += 1;
  break;
    
  case 14:    // --------------------------------------------- TEMPERATURA
  Serial.println("caso 14");
  
  lcd->setCursor(0,1);
  lcd->print("Temperatura       M1");  
  val_sensor_play = TEMPERATURA.toFloat();     // aqui chama a leitura do sensor

  lcd->setCursor(0,2);
  lcd->print(val_sensor_play); 

  lcd->setCursor(12,2);
  lcd->print(val_ref_sensor);  
     
  N_PLAY += 1;
  break;
    
  case 15:    // --------------------------------------------- CORRENTE AC
  Serial.println("caso 15");
  
  lcd->setCursor(0,1);
  lcd->print("Corrente AC       I3");  
  val_sensor_play = CORRENTE.toFloat();     // aqui chama a leitura do sensor

  lcd->setCursor(0,2);
  if(analogRead(A14)>=1020){
    lcd->print("ERRO   ");
  }else{
    lcd->print(val_sensor_play);
    lcd->setCursor(12,2);
    lcd->print(val_ref_sensor);
  }

 

  
       
  N_PLAY += 1;
  break;
    
  case 16:    // --------------------------------------------- BATIMENTOS CARDIACOS
  Serial.println("caso 16");
  
  lcd->setCursor(0,1);
  lcd->print("Batim. Cardiacos  I3");  
  val_sensor_play = BPM2.toFloat();     // aqui chama a leitura do sensor

  lcd->setCursor(0,2);
  lcd->print(val_sensor_play); 

  lcd->setCursor(12,2);
  lcd->print(val_ref_sensor);  
         
  N_PLAY += 1;
  break;
  
  case 17:    // --------------------------------------------- PRESSAO DIFERENCIAL
  Serial.println("caso 17");
  
  lcd->setCursor(0,1);
  lcd->print("Pressao Dif.      M3");  
  val_sensor_play = PRES_DIF.toFloat();     // aqui chama a leitura do sensor

  lcd->setCursor(0,2);
  lcd->print(val_sensor_play); 

  lcd->setCursor(12,2);
  lcd->print(val_ref_sensor);  
           
  N_PLAY += 1;
  break;
      
  case 18:    // --------------------------------------------- UMIDADE DO SOLO
  Serial.println("caso 18"); 
  
  lcd->setCursor(0,1);
  lcd->print("Umidade Solo      I1");  
  val_sensor_play = SOLO.toFloat();     // aqui chama a leitura do sensor

  lcd->setCursor(0,2);
  lcd->print(val_sensor_play); 

  lcd->setCursor(12,2);
  lcd->print(val_ref_sensor);  
             
  N_PLAY += 1;
  break;
    
  case 19:    // --------------------------------------------- SENSOR HALL
  Serial.println("caso 19"); 
      
  lcd->setCursor(0,1);
  lcd->print("Sensor Hall       I2");  
  val_sensor_play = HALL.toFloat();     // aqui chama a leitura do sensor

  lcd->setCursor(0,2);
  lcd->print(val_sensor_play); 

  lcd->setCursor(12,2);
  lcd->print(val_ref_sensor);  
      
  N_PLAY += 1;
  break;
    
  case 20:    // --------------------------------------------- SENSOR DE SOM
  Serial.println("caso 20");
      
  lcd->setCursor(0,1);
  lcd->print("Sensor De Som     I3");  
  val_sensor_play = SEN_SOM.toFloat();     // aqui chama a leitura do sensor

  lcd->setCursor(0,2);
  lcd->print(val_sensor_play); 

  lcd->setCursor(12,2);
  lcd->print(val_ref_sensor);  
        
  N_PLAY += 1;
  break;
    
  case 21:    // --------------------------------------------- SENSOR DE FORÇA
  Serial.println("caso 21");  
      
  lcd->setCursor(0,1);
  lcd->print("Forca             I1");  
  val_sensor_play = FORCA.toFloat();     // aqui chama a leitura do sensor

  lcd->setCursor(0,2);
  lcd->print(val_sensor_play); 

  lcd->setCursor(12,2);
  lcd->print(val_ref_sensor);  
          
  N_PLAY += 1;
  break;
    
  case 22:    // --------------------------------------------- SENSOR DISTANCIA
  Serial.println("caso 22"); 
      
  lcd->setCursor(0,1);
  lcd->print("Ultrassom         I4");  
  val_sensor_play = ULTRA.toFloat();     // aqui chama a leitura do sensor

  lcd->setCursor(0,2);
  lcd->print(val_sensor_play); 

  lcd->setCursor(12,2);
  lcd->print(val_ref_sensor);  
            
  N_PLAY += 1;
  break;
    
  case 23:    // --------------------------------------------- SENSOR PH
  Serial.println("caso 23"); 
      
  lcd->setCursor(0,1);
  lcd->print("Medidor PH        I2");  
  val_sensor_play = PH.toFloat();     // aqui chama a leitura do sensor

  lcd->setCursor(0,2);
  lcd->print(val_sensor_play); 

  lcd->setCursor(12,2);
  lcd->print(val_ref_sensor);  
              
  N_PLAY += 1;
  break;
    
  case 24:
  Serial.println("caso 24"); 
  N_PLAY += 1;
  break;
    
  case 25:
  Serial.println("caso 25"); 
  N_PLAY += 1;
  break;
    
  case 26:
  Serial.println("caso 26");
  N_PLAY += 1;
  break;
    
  case 27:
  Serial.println("caso 27");
  N_PLAY += 1;
  break;

  case 0:
  Serial.println("loop");
  N_PLAY = 0;
  break;  
 
  default:
  Serial.println("DEFAULT");
  //if (N_TELA != 4) CHAMA_TELA(2);
  Flag_play = 0;
  D_elay1 = 0;  
  D_elay2 = 0;
  D_elay3 = 0; 
  D_elay4 = 0; 
  FlagDelay1 = 0;
  FlagDelay2 = 0;   
  FlagDelay3 = 0;         
  FlagDelay4 = 0;
  Flag_play = 0;
  N_PLAY = 0;
  break;  
 }

//Serial.println("FIM DO SWITCH PLAY");
  
}
