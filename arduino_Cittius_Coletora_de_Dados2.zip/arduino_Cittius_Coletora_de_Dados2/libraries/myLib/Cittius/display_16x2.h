

//----------------------------------
byte m = 0;


//------------------------------------------------------
void inicializar(){
  
    lcd->setCursor(4,0);
    lcd->print(F("CITTIUS"));

    lcd->setCursor(0,1);
    lcd->print(F("COLETOR DE DADOS"));    
}
//------------------------------------------------------


//------------------------------------------------------
void versao(boolean a, byte b){
  
    lcd->setCursor(6,0);
    lcd->print(Vsoft);
}
//------------------------------------------------------

//------------------------------------------------------
void menu3(byte nnn){        // MENU 2 OU LER SENSORES

  switch (nnn){
    case 1:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Tensao DC     I4");
        Flag_menu3ok = 1;
      }
    }
    break;

    case 2:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Corrente AC   I3"); 
        Flag_menu3ok = 1;
      }                    
    }
    break;  

    case 3:{ 
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Temperatura   M1");
        Flag_menu3ok = 1;
      }                      
    }
    break;

    case 4:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Medidor PH    I2");
        Flag_menu3ok = 1;
      }                      
    }
    break;  

    case 5:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Umi. Solo     I1");
        Flag_menu3ok = 1;
      }                    
    }
    break;

    case 6:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Ultrassom     M4");
        Flag_menu3ok = 1;
      }                     
    }
    break;  

    case 7:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Forca         I1");
        Flag_menu3ok = 1;
      }                    
    }
    break;

    case 8:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Bussola       M2");
        Flag_menu3ok = 1;  
      }                    
    }
    break;  

    case 9:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Pres. Dif.    M3");
        Flag_menu3ok = 1;
      }                     
    }
    break;

    case 10:{
      if(Flag_menu3ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Hall          I2");
        Flag_menu3ok = 1;
      }                    
    }
    break;             

}}
//------------------------------------------------------

//------------------------------------------------------
void menu2(byte nn){        // MENU 2 OU LER SENSORES

  switch (nn){
    case 1:{
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Tensao DC     I4");
        lcd->setCursor(0,1);
        lcd->print("Val=            ");
        Flag_menu2ok = 1;
      }
      else{
          lcd->setCursor(5,1);
          lcd->print(TENSAO + "V   ");    
      }
    }
    break;

    case 2:{
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Corrente AC   I3"); 
        lcd->setCursor(0,1);
        lcd->print("Val=            ");
        Flag_menu2ok = 1;
      }
      else{
          lcd->setCursor(5,1);
          lcd->print(CORRENTE + "A   ");    
      }                     
    }
    break;  

    case 3:{ 
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Temperatura   M1");
        lcd->setCursor(0,1);
        lcd->print("Val=            ");
        //lcd->setCursor(12,1);
        //lcd->write(223);   //Simbolo grau
        Flag_menu2ok = 1;
      }
      else{
          lcd->setCursor(5,1);
          lcd->print(TEMPERATURA + (char)223 + "C   ");    
      }                      
    }
    break;

    case 4:{
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Medidor PH    I2");
        lcd->setCursor(0,1);
        lcd->print("Val=            ");
        Flag_menu2ok = 1;
      }
      else{
          lcd->setCursor(5,1);
          lcd->print(PH + "   ");    
      }                      
    }
    break;  

    case 5:{
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Umi. Solo     I1");
        lcd->setCursor(0,1);
        lcd->print("Val=            "); 
        Flag_menu2ok = 1;
      }
      else{
          lcd->setCursor(5,1);
          lcd->print(SOLO + "%   ");    
      }                     
    }
    break;

    case 6:{
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Ultrassom     M4");
        lcd->setCursor(0,1);
        lcd->print("Val=            ");
        Flag_menu2ok = 1;
      }
      else{
          lcd->setCursor(5,1);
          lcd->print(ULTRA + "cm   ");    
      }                      
    }
    break;  

    case 7:{
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Forca         I1");
        lcd->setCursor(0,1);
        lcd->print("Val=            "); 
        Flag_menu2ok = 1;
      }
      else{
          lcd->setCursor(5,1);
          lcd->print(FORCA + "kg   ");    
      }                     
    }
    break;

    case 8:{
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Bussola       M2");
        lcd->setCursor(0,1);
        lcd->print("Val=            ");
        Flag_menu2ok = 1;  
      }
      else{
          lcd->setCursor(5,1);
          lcd->print("----");    
      }                    
    }
    break;  

    case 9:{
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Pres. Dif.    M3");
        lcd->setCursor(0,1);
        lcd->print("Val=            ");
        Flag_menu2ok = 1;
      }
      else{
          lcd->setCursor(5,1);
          lcd->print("----");    
      }                      
    }
    break;

    case 10:{
      if(Flag_menu2ok == 0){
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Hall          I2");
        lcd->setCursor(0,1);
        lcd->print("Val=            "); 
        Flag_menu2ok = 1;
      }
      else{
          lcd->setCursor(5,1);
          lcd->print(HALL + "adc   ");    
      }                     
    }
    break;             

}}
//------------------------------------------------------


//------------------------------------------------------
void menu(byte n){        // MENU 1 OU PRINCIPAL

  switch (n){
    case 1:{
          m = 1;
          lcd->setCursor(1,0);
          lcd->print(F(">1)LER SENSORES"));
          lcd->setCursor(1,1);
          lcd->print(F(" 2)SETUP DADOS ")); 
    }
    break;

    case 2:{
        if(m == 1){
          m = 2;
          lcd->setCursor(1,0);
          lcd->print(F(" 1)LER SENSORES"));
          lcd->setCursor(1,1);
          lcd->print(F(">2)SETUP DADOS ")); 
        }else if(m == 3){
                m = 2;
                lcd->setCursor(1,0);
                lcd->print(F(">2)SETUP DADOS "));
                lcd->setCursor(1,1);
                lcd->print(F(" 3)ENVIAR DADOS")); 
              }         
    }
    break;    

    case 3:{
        if(m == 2){
          m = 3;
          lcd->setCursor(1,0);
          lcd->print(F(" 2)SETUP DADOS "));
          lcd->setCursor(1,1);
          lcd->print(F(">3)ENVIAR DADOS")); 
        }else if(m == 4){
                m = 3;
                lcd->setCursor(1,0);
                lcd->print(F(">3)ENVIAR DADOS"));
                lcd->setCursor(1,1);
                lcd->print(F(" 4)------------")); 
              }          
    }
    break;    

    case 4:{
          m = 4;
          lcd->setCursor(1,0);
          lcd->print(F(" 3)ENVIAR DADOS"));
          lcd->setCursor(1,1);
          lcd->print(F(">4)------------")); 
    }
    break;     
  }  
  
}
//------------------------------------------------------
