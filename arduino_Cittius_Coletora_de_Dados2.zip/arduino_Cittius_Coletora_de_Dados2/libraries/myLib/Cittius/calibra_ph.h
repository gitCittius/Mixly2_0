
float func_A = 0.000;
float func_B = 0.000;
int Flag_calPH = 0;
int ADC_PH = 0;


//------------------------------------------------------------------------------------
void covert_adcph(){

//grafico entre ph 4 e ph 7
func_B = ( (4.0000*float(adc_4710[1])) - (7.0000*float(adc_4710[0])) ) / (float(adc_4710[1]) - float(adc_4710[0]))      ;
func_A = (4.0000 - func_B) / float(adc_4710[1]);

//Serial.println(func_A);
//Serial.println(func_A,5);
//Serial.println("Grafico de PH 4 até PH 7");
//Serial.println("PH = " + String(func_A) + " * X + " + String(func_B));

graf4_7 [0] = func_A;   //graf4_7 [2] = {A; B};
graf4_7 [1] = func_B;   //graf4_7 [2] = {A; B};

//grafico entre ph 7 e ph 10
func_B = ( (7.0000*float(adc_4710[2])) - (10.0000*float(adc_4710[1])) ) / (float(adc_4710[2]) - float(adc_4710[1]))      ;
func_A = (7.0000 - func_B) / float(adc_4710[2]);

//Serial.println(func_A);
//Serial.println("Grafico de PH 4 até PH 7");
//Serial.println("PH = " + String(func_A) + " * X + " + String(func_B));

graf7_10 [0] = func_A;  //graf7_10 [2] = {A; B};
graf7_10 [1] = func_B;  //graf7_10 [2] = {A; B};
  
}
//------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------
void cal_PH(){

  Flag_calPH = 1;
  boolean adc_grav = 0;
  PH_padrao = 0;

  while(Flag_calPH != 4){
//  while(true){    

    ADC_PH = Filtro_Analog(68,20,10);
    
    if(flag_pos == 0){
//        calibracao_PH(Flag_calPH, 0);
        flag_pos = 1;
    }
//    else calibracao_PH(4, 0);
    
    if ((Button_enter == 0)&&(Flag_Button_enter == 0)){
        Flag_Button_enter = 1;

        if((Flag_calPH == 1)&&(ADC_PH > 600)&&(ADC_PH < 690)) adc_grav = 1;
        if((Flag_calPH == 2)&&(ADC_PH > 500)&&(ADC_PH < 590)) adc_grav = 1;
        if((Flag_calPH == 3)&&(ADC_PH > 400)&&(ADC_PH < 490)) adc_grav = 1;

        if(adc_grav == 1){
//            calibracao_PH(Flag_calPH, 1);
            flag_pos = 0;
            adc_4710 [Flag_calPH -1] = ADC_PH;
            Serial.println("adc_4710 = {" + String(adc_4710[0]) + " , " + String(adc_4710[1]) + " , " + String(adc_4710[2]) + " }");
            Flag_calPH += 1;
            adc_grav = 0;
            tone(BUZ,1000,50);
            delay(50);
        }
        else{
            tone(BUZ,800,1000);
            delay(1000);
        }
      }

      //if (Flag_calPH == 4) break;
  }

//GRAVA VALORES NA EEPROM
EEPROMWritelong(1,adc_4710[0]);
EEPROMWritelong(3,adc_4710[1]);
EEPROMWritelong(5,adc_4710[2]);

//Serial.println(EEPROMReadlong(1));
//Serial.println(EEPROMReadlong(3));
//Serial.println(EEPROMReadlong(5));

covert_adcph();

delay(1000);

flag = 0;
tela = 7;
menu_5 = 1;
lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
Flag_menu5ok = 0;
menu5(menu_5);

}
//------------------------------------------------------------------------------------
