

unsigned long D_elay1 = 0;  
unsigned long D_elay2 = 0;
unsigned long D_elay3 = 0; 
unsigned long D_elay4 = 0;   
boolean FlagDelay1 = 0;
boolean FlagDelay2 = 0;   
boolean FlagDelay3 = 0;         
boolean FlagDelay4 = 0;

//*****************************************************************************************//
//                        FUNÇÃO PARA SEQUENCIA DOS CARTÕES
//*****************************************************************************************//

String Nome_card(String cartao, boolean retorno){

// RETORNO = 0 -> RETORNA O VALOR PARA VARIÁVEL Seq_PLAY
// RETORNO = 1 -> RETORNA O NOME A SER IMPRESSO NO TFT  

byte y = 0;
String z = "";

//Serial.print("nome cartão = ");
//Serial.println(cartao);

switch (cartao[1]){
  case '1':
  {
    if (cartao[3] == 'N'){
      y = 1;
      Flag_edit_card = 1;
      z = "ON";
      pos_card = 4;
    }
    if (cartao[3] == 'F'){
      y = 2;
      Flag_edit_card = 1;
      z = "OFF";
      pos_card = 4;
    }                            
  }
  break;

  case '2':
  {
    if (cartao[3] == 'G'){
      y = 3;
      Flag_edit_card = 1;
      z = "Esp";
      pos_card = 6;
    }
    if (cartao[3] == '1'){
      y = 4;
      Flag_edit_card = 1;
      z = "1s";
      pos_card = 7;
    }
    if (cartao[3] == '3'){
      y = 5;
      Flag_edit_card = 1;
      z = "3s";
      pos_card = 7;
    }
    if (cartao[3] == '5'){
      y = 6;
      Flag_edit_card = 1;
      z = "5s";
      pos_card = 7;
    }                                   
  }
  break; 

  case '3':
  {
    if (cartao[3] == 'Z'){
      y = 7;
      Flag_edit_card = 1;
      z = "BUZ";
      pos_card = 5;
    }
    if (cartao[3] == 'D'){
      y = 8;
      Flag_edit_card = 1;
      z = "LED";
      pos_card = 5;
    }                                   
  }
  break;  

  case '4':
  {
    if (cartao[3] == 'A'){
      y = 9;
      Flag_edit_card = 0;
      z = " > ";
      pos_card = 2;
    }
    if (cartao[3] == 'E'){
      y = 10;
      Flag_edit_card = 0;
      z = " < ";
      pos_card = 2;
    }     
    if (cartao[3] == 'G'){
      y = 11;
      Flag_edit_card = 0;
      z = " = ";
      pos_card = 2;
    }         
  }
  break;   

  case '5':
  {
    if ((cartao[2] == 'B')&&(cartao[3] == 'U')){
      y = 12;
      Flag_edit_card = 0;
      z = "BUSS";
      pos_card = 1;
      val_ref_sensor = 180;
      val_ref_senmax = 359;
      val_ref_senmin = 0.0;
    }
    if ((cartao[2] == 'T')&&(cartao[3] == 'H')){
      y = 13;
      Flag_edit_card = 0;
      z = "T/U";
      pos_card = 1;
      val_ref_sensor = 50;
      val_ref_senmax = 100;
      val_ref_senmin = 0.0;      
    }     
    if ((cartao[2] == 'T')&&(cartao[3] == 'M')){
      y = 14;
      Flag_edit_card = 0;
      z = "TEM";
      pos_card = 1;
      val_ref_sensor = 20;
      val_ref_senmax = 100;
      val_ref_senmin = 0.0;      
    }  
    if ((cartao[2] == 'C')&&(cartao[3] == 'E')){
      y = 15;
      Flag_edit_card = 0;
      z = "AAC";
      pos_card = 1;
      val_ref_sensor = 6;
      val_ref_senmax = 15;
      val_ref_senmin = 0.0;      
    }
    if ((cartao[2] == 'F')&&(cartao[3] == 'C')){
      y = 16;
      Flag_edit_card = 0;
      z = "BPM";
      pos_card = 1;
      val_ref_sensor = 0;
      val_ref_senmax = 0;
      val_ref_senmin = 0.0;      
    }  
    if ((cartao[2] == 'P')&&(cartao[3] == 'D')){
      y = 17;
      Flag_edit_card = 0;
      z = "PDif";
      pos_card = 1;
      val_ref_sensor = 50;
      val_ref_senmax = 359;
      val_ref_senmin = 0.0;      
    }
    if ((cartao[2] == 'U')&&(cartao[3] == 'S')){
      y = 18;
      Flag_edit_card = 0;
      z = "Solo";
      pos_card = 1;
      val_ref_sensor = 50;
      val_ref_senmax = 100;
      val_ref_senmin = 0.0;      
    }     
    if ((cartao[2] == 'E')&&(cartao[3] == 'H')){
      y = 19;
      Flag_edit_card = 0;
      z = "Hall";
      pos_card = 1;
      //val_ref_sensor ---------------------------------------------> tem de fazer
    }  
    if ((cartao[2] == 'D')&&(cartao[3] == 'S')){
      y = 20;
      Flag_edit_card = 0;
      z = "Som";
      pos_card = 1;
      val_ref_sensor = 70;
      val_ref_senmax = 150;
      val_ref_senmin = 0.0;      
    }
    if ((cartao[2] == 'S')&&(cartao[3] == 'F')){
      y = 21;
      Flag_edit_card = 0;
      z = "Kg";
      pos_card = 1;
      val_ref_sensor = 2.2;
      val_ref_senmax = 5;
      val_ref_senmin = 0.0;      
    }
    if ((cartao[2] == 'S')&&(cartao[3] == 'U')){
      y = 22;
      Flag_edit_card = 0;
      z = "Dist.";
      pos_card = 1;
      val_ref_sensor = 10;
      val_ref_senmax = 50;
      val_ref_senmin = 0.0;      
    }
    if ((cartao[2] == 'P')&&(cartao[3] == 'H')){
      y = 23;
      Flag_edit_card = 0;
      z = "PH";
      pos_card = 1;
      val_ref_sensor = 8;
      val_ref_senmax = 13;
      val_ref_senmin = 0.0;      
    }    
  }
  break;  

  case '6':
  {
    if (cartao[3] == '1'){
      y = 24;
      Flag_edit_card = 0;
      z = "PROGRAMAVEL 1";
    }
    if (cartao[3] == '2'){
      y = 25;
      Flag_edit_card = 0;
      z = "PROGRAMAVEL 2";
    }     
    if (cartao[3] == '3'){
      y = 26;
      Flag_edit_card = 0;
      z = "PROGRAMAVEL 3";
    }  
    if (cartao[3] == '4'){
      y = 27;
      Flag_edit_card = 0;
      z = "PROGRAMAVEL 4";
    }      
  }
  break;    
               
}

//Serial.print("y = ");
//Serial.println(y);
// retorno = 0 -> RETORNA O VALOR PARA VARIÁVEL Seq_PLAY
// retorno = 1 -> RETORNA O NOME A SER IMPRESSO NO TFT  

if (retorno == 0)
  return String(y);
  else if (retorno == 1)
  return z;
}

//*****************************************************************************************//


//*****************************************************************************************//
//                        FUNÇÃO PARA SEQUENCIA DAS ATIVIDADES
//*****************************************************************************************//
/*
void PLAY(String a){

int p_play = a.toInt();

 //Serial.print(F("P_PLAY = "));
 //Serial.println(p_play);

 switch (p_play){
  case 1:
  Serial.println("caso 1");   // ON
  if(flag_comparacao == 1) flag_on_off = 1;
    else flag_on_off = 2;
  N_PLAY += 1;
  break;
  
  case 2:
  Serial.println("caso 2");   // OFF
  if(flag_comparacao == 1) flag_on_off = 3;
    else flag_on_off = 4;  
  N_PLAY += 1;
  break;
  
  case 3:
  Serial.println("caso 3");
  N_PLAY += 1;
  break;
  
  case 4:
  Serial.println("caso 4");
  if (FlagDelay1 == 0){
    FlagDelay1 = 1;
    D_elay1 = millis();
  }

  if((millis() - D_elay1) > 1000){ 
    N_PLAY += 1;
    FlagDelay1 = 0;
    D_elay1 = 0;
  }
  break;    
  
  case 5:  
  Serial.println("caso 5");
  if (FlagDelay2 == 0){
    FlagDelay2 = 1;
    D_elay2 = millis();
  }

  if((millis() - D_elay2) > 3000){ 
    N_PLAY += 1;
    FlagDelay2 = 0;
    D_elay2 = 0;
  }
  break;
      
  case 6:   
  Serial.println("caso 6");
  if (FlagDelay3 == 0){
    FlagDelay3 = 1;
    D_elay3 = millis();
  }

  if((millis() - D_elay3) > 5000){ 
    N_PLAY += 1;
    FlagDelay3 = 0;
    D_elay3 = 0;
  }
  break;
    
  case 7:
  Serial.println("caso 7");
  switch(flag_on_off){
    case 1:
          tone(BUZ,1000,50);
          delay(50);
    break;

    case 2:
    break;

    case 3:
    break;

    case 4:
          tone(BUZ,1000,50);
          delay(50);    
    break;
  }

  N_PLAY += 1;
  break;
    
  case 8:
  Serial.println("caso 8");
  switch(flag_on_off){
    case 1:
          digitalWrite(A6, 1);  // aciona o LED com o valor 
    break;

    case 2:
          digitalWrite(A6, 0);  // aciona o LED com o valor     
    break;

    case 3:
          digitalWrite(A6, 0);  // aciona o LED com o valor     
    break;

    case 4:
          digitalWrite(A6, 1);  // aciona o LED com o valor   
    break;
  }
  
  N_PLAY += 1;
  break;
    
  case 9:
  Serial.println("caso 9");
  lcd->setCursor(10,2);
  lcd->print(">");  
  if(val_sensor_play > val_ref_sensor){
    flag_comparacao = 1;
    //N_PLAY += 1;
  }
    else flag_comparacao = 0;  
    
  N_PLAY += 1;     
  break;
    
  case 10:
  Serial.println("caso 10");
  lcd->setCursor(10,2);
  lcd->print("<");  
  if(val_sensor_play > val_ref_sensor){
    flag_comparacao = 1;
    //N_PLAY += 1;
  }
    else flag_comparacao = 0; 
    
  N_PLAY += 1;    
  break;
    
  case 11:
  Serial.println("caso 11");
  lcd->setCursor(10,2);
  lcd->print("=");  
  if(val_sensor_play > val_ref_sensor){
    flag_comparacao = 1;
    //N_PLAY += 1;
  }
    else flag_comparacao = 0;
    
  N_PLAY += 1;     
  break;
    
  case 12:
  Serial.println("caso 12");
  
  lcd->setCursor(0,1);
  lcd->print("BUSSOLA             ");  
  val_sensor_play = 20;

  lcd->setCursor(0,2);
  lcd->print(val_sensor_play); 
  
  N_PLAY += 1;
  break;
    
  case 13:
  Serial.println("caso 13");
  N_PLAY += 1;
  break;
    
  case 14:
  Serial.println("caso 14");
  N_PLAY += 1;
  break;
    
  case 15:
  Serial.println("caso 15");
  N_PLAY += 1;
  break;
    
  case 16:
  Serial.println("caso 16");
  N_PLAY += 1;
  break;
  
  case 17:
  Serial.println("caso 17");
  N_PLAY += 1;
  break;
      
  case 18:
  Serial.println("caso 18"); 
  N_PLAY += 1;
  break;
    
  case 19:
  Serial.println("caso 19");   
  N_PLAY += 1;
  break;
    
  case 20:
  Serial.println("caso 20");
  N_PLAY += 1;
  break;
    
  case 21:
  Serial.println("caso 21");  
  N_PLAY += 1;
  break;
    
  case 22:
  Serial.println("caso 22"); 
  N_PLAY += 1;
  break;
    
  case 23:
  Serial.println("caso 23"); 
  N_PLAY += 1;
  break;
    
  case 24:
  Serial.println("caso 24"); 
  N_PLAY += 1;
  break;
    
  case 25:
  Serial.println("caso 25"); 
  N_PLAY += 1;
  break;
    
  case 26:
  Serial.println("caso 26");
  N_PLAY += 1;
  break;
    
  case 27:
  Serial.println("caso 27");
  N_PLAY += 1;
  break;

  case 0:
  Serial.println("loop");
  N_PLAY = 0;
  break;  
 
  default:
  Serial.println("DEFAULT");
  //if (N_TELA != 4) CHAMA_TELA(2);
  Flag_play = 0;
  D_elay1 = 0;  
  D_elay2 = 0;
  D_elay3 = 0; 
  D_elay4 = 0; 
  FlagDelay1 = 0;
  FlagDelay2 = 0;   
  FlagDelay3 = 0;         
  FlagDelay4 = 0;
  Flag_play = 0;
  N_PLAY = 0;
  break;  
 }

//Serial.println("FIM DO SWITCH PLAY");
  
}

*/
