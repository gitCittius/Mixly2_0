#include <OneButton.h>

unsigned long btn_timer = 0;
unsigned long btn_timer_old = 0;
unsigned int pulse_repeat = 0;
boolean Flag_pulse = 0;
boolean f_btnUp,f_btnDn;
byte step_size;
float step_size_f;

byte Botao = 0;
boolean Flag_Botao_5 = 0;
boolean Flag_Botao_6 = 0;

OneButton btnEnter(49,true);
OneButton btnVoltar(48,true);
OneButton btnCima(47,true);
OneButton btnBaixo(38,true);


void eventEnter() {
  if(tela==1 && menu_1==7){
    lcd->clear();
    tela=20;
    flagSetupAluno=false;
    flagSetupProgram=true;
  }
}

void eventVoltar() {
    lcd->clear();
    menu(7);
    tela=1;
    flagSetupAluno=false;
    flagSetupProgram=false;
}

void eventCima() {
}

void eventBaixo() {
}


void le_botao(){
    //*****************************************************************************************//
  if ((Button_enter == 0)&&(Flag_Button_enter == 0)){
    Flag_Button_enter = 1;
    tone(BUZ,1000,50);
    delay(50);
 


  if(((N_CARD == 7)||(N_CARD == 5))&&(Flag_play == 0)){
    Flag_play = 1;  // FAZ O PLAY DA SEQUENCIA
    tela = 20;
    lcd->clear();
    lcd->setCursor(0,0);
    lcd->print("PLAY                ");    
  }



    if((tela == 7)&&(menu_5 == 1)){
       //Timer3.stop();
          //Serial.println("chama a calibração do ph");
          cal_PH();
       //Timer3.start();
    }


    if(tela == 10){
      EEPROM.write(7, sensorAC);
      tela = 7;
      menu_5 = 1;
      lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
      Flag_menu5ok = 0;
      menu5(menu_5);      
      

    }



    if((tela == 7)&&(menu_5 == 2)){
      tela = 10;
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print(" Selecione o sensor ");
        if(sensorAC == 0){
          lcd->setCursor(0,2);
          lcd->print("Sensor 30A/1V       ");
          }    
          else if(sensorAC == 1){
            lcd->setCursor(0,2);
            lcd->print("Sensor 100A/50mA  v1");
            } 
            else if(sensorAC == 2){
              lcd->setCursor(0,2);
              lcd->print("Sensor 100A/50mA  v2");
              }      

    }    

  #if LCDType == 16 
 
  #elif LCDType == 20
    if((tela == 7)&&(menu_5 == 3)){
       //Timer3.stop();
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Bussola           I4");
        inicia_bussola();
       //Timer3.start();
    } 
  #endif

   

    if((tela == 6)&&(menu_4 == 3)){
      #if LCDType == 16 
        
      #elif LCDType == 20
        tela = 11;
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("TACOMETRO         I2");
      #endif

    } 

    if((tela == 6)&&(menu_4 == 2)){
      #if LCDType == 16 
        tela = 11;
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("TACOMETRO     I2");       
      #elif LCDType == 20
        tela = 8;
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Bussola           I4");
      #endif       
    }    

    if((tela == 6)&&(menu_4 == 1)){
      #if LCDType == 16 
        tela = 8;
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Bussola       I4");        
      #elif LCDType == 20
        tela = 9;
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        lcd->setCursor(0,0);
        lcd->print("Batim. Cardiacos  I3");
      #endif      

    } 

      if (tela == 5 && N_CARD == 0 && flag_apaga == 0){
        lcd->setCursor(6,0);
        lcd->print(F("APAGAR"));
        flag_apaga = 1;
      }else if (flag_apaga == 1){
              lcd->setCursor(6,0);
              lcd->print(F("      "));
              flag_apaga = 0;
            }

    if (tela == 3){
      //Serial.print ("Salvar posição = ");
      //Serial.println(seq_uso[menu_3]);
      dados_out[menu_3] = !dados_out[menu_3];
 

#if LCDType == 16 
        if (dados_out[menu_3] == 0) {
          lcd->setCursor(13,1);
          lcd->print("NAO"); 
        }
        else {
          lcd->setCursor(13,1);
          lcd->print("SIM"); 
        } 
#elif LCDType == 20
        if (dados_out[menu_3] == 1) { //RAFAEL
          lcd->setCursor(0,3);
          lcd->print("SIM"); 
        }
        else {
          lcd->setCursor(0,3);
          lcd->print("NAO"); 
        } 
#endif
    }

    if (tela == 1){
      switch (menu_1){
        case 1:{
          tela = 2;
            menu_2 = 1;
            lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
            Flag_menu2ok = 0;
            menu2(menu_2);
        }
        break;

        case 2:{
          tela = 6;
            menu_4 = 1;
            lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
            Flag_menu4ok = 0;
            menu4(menu_4);
        }
        break;        

        case 3:{
          tela = 3;
            menu_3 = 1;
            lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
            Flag_menu3ok = 0;
            menu3(menu_3,dados_out[menu_3]);
        }
        break; 

        case 4:{
          tela = 4;
            lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
            lcd->setCursor(0,0);
            
            #if LCDType == 16 
              lcd->print(F(" ENVIANDO DADOS "));
            #elif LCDType == 20
              lcd->print(F("   ENVIANDO DADOS   "));
            #endif            
        }
        break;

        case 5:{

            #if LCDType == 16 
                //Timer3.stop();
                lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
                lcd->setCursor(0,0);
                lcd->print("Bussola       I4");
                inicia_bussola();
                //Timer3.start();
              
            #elif LCDType == 20
                tela = 5;
                //mfrc522.PCD_DumpVersionToSerial();
                byte v = mfrc522.PCD_ReadRegister(0x37 << 1);   // determina se a placa rfid esta funcionando
                if( (v == 0x88) || (v == 0x90) || (v == 0x91) || (v == 0x92) || (v == 0x12) ){
                  //Serial.println(v);
                  lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
                  lcd->setCursor(0,1);
                  lcd->print(F(":                   "));
                  lcd->setCursor(0,3);
                  lcd->print(F("  ESCOLHA O SENSOR  "));                  
                  lcd->setCursor(0,0);
                  lcd->print(F("STOP           N=   "));
                  lcd->setCursor(17,0);
                  lcd->print(N_CARD);
                }
                else {
                  lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
                  lcd->setCursor(0,1);
                  lcd->print(F("FALHA NO LEITOR RFID"));
                  lcd->setCursor(0,2);
                  lcd->print(F("VERIFIQUE A CONEXAO "));                  
                }
            #endif
          

        }
        break;

        case 6:{
          tela = 7;
            menu_5 = 1;
            lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
            Flag_menu5ok = 0;
            menu5(menu_5);
        }
        break;  
                               
      }}

      //if (tela == 0) break;



/*
                  for (int i = 10; i <= 23; i++){
                  Serial.print(i);
                  Serial.print(" - ");
                  Serial.println(EEPROM.read(i)); 
                  }      
                  for (int i = 30; i <= 43; i++){
                  Serial.print(i);
                  Serial.print(" - ");
                  Serial.println(EEPROM.read(i)); 
                  } 
                  for (int i = 50; i <= 63; i++){
                  Serial.print(i);
                  Serial.print(" - ");
                  Serial.println(EEPROM.read(i)); 
                  }
                  for (int i = 70; i <= 83; i++){
                  Serial.print(i);
                  Serial.print(" - ");
                  Serial.println(EEPROM.read(i)); 
                  }      */                                                  

                  
  }
  //*****************************************************************************************//

  //*****************************************************************************************//
  if ((Button_voltar == 0)&&(Flag_Button_voltar == 0)){
    Flag_Button_voltar = 1;
    tone(BUZ,1500,50);
    delay(50);



  if(((N_CARD == 7)||(N_CARD == 5))&&(Flag_play == 1)&&(tela == 20)) Flag_play = 0;  // FAZ O STOP DA SEQUENCIA PLAY
    

    if((tela > 1)&&(tela < 8)){
        N_CARD = 0;
        flag_val_ref  = 0;
        for (int i = 0; i <= 13; i++) {
          Seq_CARD [i] = " ";
             }
        for (int i = 0; i <= 13; i++) {
          Seq_PLAY [i] = " ";
             }      

      if(tela == 3){  //GRAVA VALORES DA SEQUENCIA QUE SERÃO ENVIADOS PELA SERIAL 

        for (int i = 0; i <= 11; i++) {
      
          if(EEPROM.read(100 + i) != dados_out[i]){
               EEPROM.write(100 + i, dados_out[i]);                              
              }
          }
        }
                  
        tamanho_total = 0;
        tamanho_total2 = 0;
        tamanho_total3 = 0;
        tela = 1;
        menu_1 = 1;
        contagem = 0;
        lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
        menu(menu_1);
    }

    if(tela == 10){
      tela = 7;
      menu_5 = 1;
      lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
      Flag_menu5ok = 0;
      menu5(menu_5);
    }
    
  }
  //*****************************************************************************************//  

  //*****************************************************************************************//
  if ((Button_up == 0)&&(Flag_Button_up == 0)&&(tela != 5)){
    Flag_Button_up = 1;
    tone(BUZ,2000,50);
    delay(50);


    if((tela == 0)&&(materia > 1)&&(materia <= 4)){
      materia -= 1;
      versao(0,materia);
    }

    if((tela == 1)&&(menu_1 > menu_1min)&&(menu_1 <= menu_1max)){
      menu_1 -= 1;
      menu(menu_1);
    }

    if((tela == 2)&&(menu_2 >= menu_2min)&&(menu_2 <= menu_2max)){
      menu_2 -= 1;
      if(menu_2 == 0) menu_2 = menu_2max;
      Flag_menu2ok = 0;
#if LCDType == 16 
  menu2(menu_2);
#elif LCDType == 20
  menu2(seq_uso [menu_2]);
#endif 
    }  

    if((tela == 3)&&(menu_3 >= menu_3min)&&(menu_3 <= menu_3max)){
      menu_3 -= 1;
      if(menu_3 == 0) menu_3 = menu_3max;
      Flag_menu3ok = 0;
#if LCDType == 16 
  menu3(menu_3,dados_out[menu_3]);
#elif LCDType == 20
  menu3(seq_uso [menu_3],dados_out[menu_3]);
#endif      
      
    }     

    if((tela == 6)&&(menu_4 > menu_4min)&&(menu_4 <= menu_4max)){
      menu_4 -= 1;
      menu4(menu_4);
    }

    if((tela == 7)&&(menu_5 > menu_5min)&&(menu_5 <= menu_5max)){
      menu_5 -= 1;
      menu5(menu_5);
    } 

    if(tela == 10){
      if (sensorAC < 2) sensorAC = sensorAC + 1;
        if(sensorAC == 0){
          lcd->setCursor(0,2);
          lcd->print("Sensor 30A/1V       ");
          }    
          else if(sensorAC == 1){
            lcd->setCursor(0,2);
            lcd->print("Sensor 100A/50mA  v1");
            }     
            else if(sensorAC == 2){
              lcd->setCursor(0,2);
              lcd->print("Sensor 100A/50mA  v2");
              }               
    }
            
     
  }
  //*****************************************************************************************// 

  //*****************************************************************************************//
  if ((Button_dn == 0)&&(Flag_Button_dn == 0)&&(tela != 5)){
    Flag_Button_dn = 1;
    tone(BUZ,2000,50);
    delay(50);


    if((tela == 0)&&(materia >= 1)&&(materia < 4)){
      materia += 1;     
      versao(0,materia);
    }

    if((tela == 1)&&(menu_1 >= menu_1min)&&(menu_1 < menu_1max)){
      menu_1 += 1;     
      menu(menu_1);
    }

    if((tela == 2)&&(menu_2 >= menu_2min)&&(menu_2 <= menu_2max)){
      menu_2 += 1;
      if(menu_2 > menu_2max) menu_2 = menu_2min; 
      Flag_menu2ok = 0;     
#if LCDType == 16 
  menu2(menu_2);
#elif LCDType == 20
  menu2(seq_uso [menu_2]);
#endif       
    } 

    if((tela == 3)&&(menu_3 >= menu_3min)&&(menu_3 <= menu_3max)){
      menu_3 += 1;
      if(menu_3 > menu_3max) menu_3 = menu_3min; 
      Flag_menu3ok = 0;     
#if LCDType == 16 
  menu3(menu_3,dados_out[menu_3]);
#elif LCDType == 20
  menu3(seq_uso [menu_3],dados_out[menu_3]);
#endif       
    } 

    if((tela == 6)&&(menu_4 >= menu_4min)&&(menu_4 < menu_4max)){
      menu_4 += 1;
      menu4(menu_4);
    }

    if((tela == 7)&&(menu_5 >= menu_5min)&&(menu_5 < menu_5max)){   //SELECIONA OS ITENS DO SETUP DO SENSOR
      menu_5 += 1;
      menu5(menu_5);
    }

    if(tela == 10){
      if (sensorAC > 0) sensorAC = sensorAC - 1;
        if(sensorAC == 0){
          lcd->setCursor(0,2);
          lcd->print("Sensor 30A/1V       ");
          }    
          else if(sensorAC == 1){
            lcd->setCursor(0,2);
            lcd->print("Sensor 100A/50mA  v1");
            } 
            else if(sensorAC == 2){
              lcd->setCursor(0,2);
              lcd->print("Sensor 100A/50mA  v2");
              }                   
    }
              
        
  }
  //*****************************************************************************************// 

}   



//  ----------------------------- FUNÇÃO PARA SETAR VALOR DO TIPO FLOAT  -------------------------------------
float Set(float& Set, float Up, float Low, float Step){

  if(Set>Up)Set = Up;
  if(Set<Low)Set = Low;


//    ***** INICIO TRATAMENTO DO BOTÃO UP *****
  if ( (Button_up == 0) && (Button_dn == 1) && (Flag_Button_up == 0) ){
    if (Button_up == 0) Flag_Button_up = 1;
    
    f_btnUp = true;
    step_size_f = Step;
    btn_timer_old = millis();
  }
  else if ( (Button_up == 1) && (Button_dn == 1) && (Flag_Button_up == 0) ){
      pulse_repeat = 0;
      f_btnUp = false;
      } 
  if (f_btnUp == true) btn_timer = millis();
//    ***** FIM DO TRATAMENTO DO BOTÃO UP *****


//    ***** INICIO TRATAMENTO DO BOTÃO DOWN *****
  if ( (Button_dn == 0) && (Button_up == 1) && (Flag_Button_dn == 0) ){     
    if (Button_dn == 0) Flag_Button_dn = 1;
    
    f_btnDn = true;
    step_size_f = Step;
    btn_timer_old = millis();
  }
  else if ( (Button_dn == 1) && (Button_up == 1) && (Flag_Button_dn == 0)  ){
      pulse_repeat = 0;
      f_btnDn = false;
      }
  if (f_btnDn == true) btn_timer = millis();
//    ***** FIM DO TRATAMENTO DO BOTÃO DOWN *****


  if((f_btnDn == true) || (f_btnUp == true)){
      if(((btn_timer-btn_timer_old)/1000)>=5){
        if(((btn_timer-(btn_timer_old+pulse_repeat))/1000)>=2){
          step_size_f = (Step*10);
          pulse_repeat = pulse_repeat + 300;
          }
      }
      else if(((btn_timer-btn_timer_old)/1000)>=2){
          if(((btn_timer-(btn_timer_old+pulse_repeat))/1000)>=2){
            step_size_f = Step;
            pulse_repeat = pulse_repeat + 300;
            }
          }
     }
        
    if(f_btnUp == true){    
      if (Set + step_size_f > Up) Set=Up;
        else {
      Set+=step_size_f;
      step_size_f = 0;
      }
    }
  else if(f_btnDn == true){
          if (Set - step_size_f < Low) Set=Low;
          else {
        Set-=step_size_f;
        step_size_f = 0;
        }
        }
}
//  ---------------------------------------------------------------------------------------------------------
