#include <QMC5883LCompassDuMod.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <Ultrasonic.h>
#include <DHT.h>
#include <HX711.h>                    // Biblioteca HX711
#include <Adafruit_BMP280.h>



#define DOUT  18                      // HX711 DATA OUT = ENTRADA M3
#define CLK  A10                       // HX711 SCK IN = ENTRADA M3

#define ONE_WIRE_BUS 62   // Porta do pino de sinal do DS18B20 (AD08) NA ENTRADA M1
#define DHTPIN  A14        
#define DHTTYPE DHT11

int PinTrigger = 19; // Pino usado para disparar os pulsos do sensor
int PinEcho = A11; // pino usado para ler a saida do sensor
float TempoEcho = 0;
const float VelocidadeSom_mpors = 340; // em metros por segundo
const float VelocidadeSom_mporus = 0.000340; // em metros por microsegundo
float distance;

OneWire oneWire(ONE_WIRE_BUS);        // Define uma instancia do oneWire para comunicacao com o sensor
DallasTemperature sensors(&oneWire);  // ENTRADA M1
DeviceAddress DS;
//Ultrasonic ultrasonic(19, A11);       //Inicializa o sensor nos pinos definidos acima  // ENTRADA M4


DHT dht(DHTPIN, DHTTYPE);             // ENTRADA I2
HX711 balanca;                        // define instancia balança HX711 // ENTRADA I4

Adafruit_BMP280 bmp(64,18);           //Inicializa o sensor nos pinos definidos acima  // ENTRADA M3
QMC5883LCompassDuMod compass(66, 22);

char tela1[50];
int calibrationData[3][2];
bool changed = false;
bool done = false;
int t = 0;
int c = 0;





byte saida_Mx [9] = {2, 62, 3, 63, 18, 64, 19, 65};   // SELECIONA QUAL PORTA SERÁ UTILIZADA PARA SAÍDA


//----------------- SAÍDA A RELE -----------------------
void out_x(byte A, boolean B){
  //A - seleciona qual saida será aciona (vai de 0 a 7)
  //B - seleciona qual será o estado da saída
  
  byte Mx = 0;

  Mx = saida_Mx [A];
  digitalWrite(Mx,B);
}
//------------------------------------------------------


//------------- SENSOR DE TEMPERATURA ------------------
//************************************************************************//  // USAR PORTA A12 (PINO 67)/ ENTRADA I3
//------------------------------------------------------
float inicia_temp(){
  sensors.getDeviceCount();
  sensors.getAddress(DS, 0); 
}
//------------------------------------------------------
//------------------------------------------------------
String temp(){
  sensors.requestTemperatures();
  String tempC = String (sensors.getTempC(DS));

  return tempC;
}
//------------------------------------------------------
//************************************************************************//


//-------------------- SENSOR ULTRASSON ----------------------------------    // ENTRADA I1
String ultra(){

  String cmMsec;
  digitalWrite(PinTrigger, HIGH);
  delayMicroseconds(10);
  digitalWrite(PinTrigger, LOW);

  TempoEcho = pulseIn(PinEcho, HIGH);
  
  //long microsec = ultrasonic.timing();
  //cmMsec = ultrasonic.convert(microsec, Ultrasonic::CM);
  distance = (((TempoEcho*VelocidadeSom_mporus)/2)*100);
  cmMsec = String(distance);

  return cmMsec;
}
//------------------------------------------------------

/*
//-------------------- SENSOR PRESSÃO DIFERENCIAL ----------------------------------    // ENTRADA I2
String buss(){

 String ang;


    ang = 

  return ang;
}
//------------------------------------------------------
*/

//-------------------- SENSOR PRESSÃO DIFERENCIAL ----------------------------------    // ENTRADA I2
String P_dif(){

 String p_dif_out;

  bmp.begin(0x76);

  /* Default settings from datasheet. */
  bmp.setSampling(Adafruit_BMP280::MODE_FORCED,     /* Operating Mode. */
                  Adafruit_BMP280::SAMPLING_X2,     /* Temp. oversampling */
                  Adafruit_BMP280::SAMPLING_X16,    /* Pressure oversampling */
                  Adafruit_BMP280::FILTER_X16,      /* Filtering. */
                  Adafruit_BMP280::STANDBY_MS_500); /* Standby time. */

  if (bmp.takeForcedMeasurement()) {

    p_dif_out = String(bmp.readAltitude(1013.25));

  return p_dif_out;
}}
//------------------------------------------------------


//-------------------- SENSOR DHT11 --------------------    // ENTRADA I2
//************************************************************************//      LER A CADA 2 SEGUNDOS NO MINIMO
String dht_temp(){

  dht.begin();

  String dht_t = String(dht.readTemperature());

  return dht_t;
}


String dht_hum(){

  //dht.begin();

  String dht_h = String(dht.readHumidity());

  return dht_h;
}
//------------------------------------------------------
//************************************************************************//


//-------------------- BALANÇA --------------------    // ENTRADA I4
//************************************************************************//      LER A CADA 2 SEGUNDOS NO MINIMO
String hx7_(){

  float kg;
  String kg2;

  if(Flag_balanca == 0){
    float calibration_factor = 42130;
    balanca.begin(DOUT, CLK);                          // inicializa a balança
    Serial.println("Balança com HX711 - celula de carga 50 Kg");            
    balanca.set_scale(calibration_factor);             // ajusta fator de calibração
    balanca.tare();                                    // zera a Balança
    Flag_balanca = 1;
  }

  kg = balanca.get_units();              // imprime peso na balança
  kg = kg*1.00;
  kg2 = String(kg); 

  return kg2;
}
//------------------------------------------------------
//************************************************************************//



//------------- SENSOR BUSSOLA ------------------
//************************************************************************//  // USAR PORTA A12 (PINO 67)/ ENTRADA I3
//------------------------------------------------------
void inicia_bussola(){
  compass.init();
  delay(50);

  #if LCDType == 16 
    lcd->setCursor(0,1);
    lcd->print("CALIBRANDO      ");
  #elif LCDType == 20
    lcd->setCursor(0,3);
    lcd->print("CALIBRANDO          ");
  #endif

 
  
    while(1) {
      
  int x, y, z;
  
  // Read compass values
  compass.read();

  // Return XYZ readings
  x = compass.getX();
  y = compass.getY();
  z = compass.getZ();

  changed = false;

  if(x < calibrationData[0][0]) {
    calibrationData[0][0] = x;
    changed = true;
  }
  if(x > calibrationData[0][1]) {
    calibrationData[0][1] = x;
    changed = true;
  }

  if(y < calibrationData[1][0]) {
    calibrationData[1][0] = y;
    changed = true;
  }
  if(y > calibrationData[1][1]) {
    calibrationData[1][1] = y;
    changed = true;
  }

  if(z < calibrationData[2][0]) {
    calibrationData[2][0] = z;
    changed = true;
  }
  if(z > calibrationData[2][1]) {
    calibrationData[2][1] = z;
    changed = true;
  }


  if (changed && !done) c = millis();
    t = millis();
  
  
  if ( (t - c > 5000) && !done) {
    done = true;
    delay(100);
    break;
    }
  }

  EEPROMWritelong(86,calibrationData[0][0]);
  EEPROMWritelong(88,calibrationData[0][1]);
  EEPROMWritelong(90,calibrationData[1][0]);
  EEPROMWritelong(92,calibrationData[1][1]);
  EEPROMWritelong(94,calibrationData[2][0]);
  EEPROMWritelong(96,calibrationData[2][1]);

  compass.setCalibration(calibrationData[0][0], calibrationData[0][1], calibrationData[1][0],calibrationData[1][1], calibrationData[2][0], calibrationData[2][1]);

  Flag_bussola = 1;


    #if LCDType == 16 
      lcd->setCursor(0,1);
      lcd->print("FINALIZADO      ");
  
      delay(2000);
  
      flag = 0;
      tela = 1;
      menu_1 = 5;
      lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
      //Flag_menu5ok = 0;
      menu(menu_1);
      
    #elif LCDType == 20
      lcd->setCursor(0,3);
      lcd->print("FINALIZADO          ");
  
      delay(2000);
  
      flag = 0;
      tela = 7;
      menu_5 = 1;
      lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
      Flag_menu5ok = 0;
      menu5(menu_5);
    #endif



  
}
//------------------------------------------------------
//------------------------------------------------------
String le_bussola(){
  compass.read();
  
  int a = compass.getAzimuth();


  sprintf(tela1, "%03d", (int)a);

  #if LCDType == 16 
    lcd->setCursor(9,1);
    lcd->print(tela1);

  
    char myArray[3];
    compass.getDirection(myArray, a);
    lcd->setCursor(13,1);
    lcd->print(myArray[0]);
    lcd->setCursor(14,1);
    lcd->print(myArray[1]);
    lcd->setCursor(15,1);
    lcd->print(myArray[2]);
  #elif LCDType == 20
    lcd->setCursor(10,2);
    lcd->print(tela1);

  
    char myArray[3];
    compass.getDirection(myArray, a);
    lcd->setCursor(0,2);
    lcd->print(myArray[0]);
    lcd->setCursor(2,2);
    lcd->print(myArray[1]);
    lcd->setCursor(4,2);
    lcd->print(myArray[2]);
  #endif
  

  
  //Serial.println();
  
  delay(250);
}
//------------------------------------------------------
//************************************************************************//
