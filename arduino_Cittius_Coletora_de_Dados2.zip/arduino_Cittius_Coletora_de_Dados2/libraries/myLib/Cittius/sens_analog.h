//-----------------------------------------------------
#include <EmonLib.h>
//#define USE_ARDUINO_INTERRUPTS true    // Set-up low-level interrupts for most acurate BPM math.
//#include <PulseSensorPlayground.h>     // Includes the PulseSensorPlayground Library. 

//int Threshold = 550;           // Determine which Signal to "count as a beat" and which to ignore.

EnergyMonitor emon1;
//PulseSensorPlayground pulseSensor;  // Creates an instance of the PulseSensorPlayground object called "pulseSensor"

    float force;

//----------EQUAÇÃO LINEAR DE ANALÓGICA PARA PONTO FLUTUANTE------------------

float MAP_F(float x, float in_min, float in_max, float out_min, float out_max){
  
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min; 
  
}
//----------------------------------------------------------------------------


//            ---------- FUNÇÃO PARA FILTRO DA ENTRADA ANALÓGICA -----------
int Filtro_Analog(int porta, int amostra, int diferenca){    // GERALMENTE USA 15 PARA AMOSTRA, 8 PARA DIFERENÇA
 
    long reads = 0;
    long lastread = 0;
    long correntread = 0;
      
    for(int ii=0;ii<amostra;ii++){      
        reads+=analogRead(porta);      
    }
      
    correntread=reads/amostra;
      
    if((abs(correntread - lastread))>diferenca){      
        lastread=correntread;      
    } 
    
  return lastread;
}
// ------------------------------------ FIM DA FUNÇÃO DE FILTRO--------------------------------------------



//-------------- VOLTIMETRO ---------------------------
float voltimeter(byte A){   // A - ENTRE COM O PINO FISICO DA ENTRADA ANALÓICA

    float corr_12 = 1.17;
    float volts = 0;
    volts = (Filtro_Analog(A,15,10)*0.0959)+0.4768;
    //volts = Filtro_Analog(A,15,10);
    //volts = volts * corr_12;

    return volts;
}
//------------------------------------------------------



//---------------------- REED SWITCH -------------------

long reed(byte B){   // B - ENTRE COM O PINO FISICO DA ENTRADA ANALÓICA

    long out = 0;
    out = Filtro_Analog(B,15,10);
  
  return out;
}
//------------------------------------------------------


//---------------- HUMIDADE DO SOLO --------------------

long hum_solo(byte C){   // C - ENTRE COM O PINO FISICO DA ENTRADA ANALÓICA

    long out = 0;
    out = map(Filtro_Analog(C,15,10),0,1023,100,0);
  
  return out;
}
//------------------------------------------------------


//------------------ SENSOR DE SOM ---------------------

String decib(byte D){   // D - ENTRE COM O PINO FISICO DA ENTRADA ANALÓICA

uint16_t ValorSensor = 0;
uint16_t sample1[10];
float media = 0;
float Vrms1 = 0;
uint8_t i = 0;

  for(i=0; i<10; i++){
    ValorSensor = analogRead(D);
    
    if( ValorSensor > 427){
      sample1[i] = ValorSensor - 427;
      //i++;
        //if(i == 10){
          //i=0;
          //}
      }else{
        sample1[i] = 427 - ValorSensor;
       // i++;
         // if(i == 10){
         //  i=0;
         // }
        }
  }
  
    for(int j=0; j<10; j++){
      media += sample1[j];
      }
      
    media = media/10;
    Vrms1 = sqrt(media);
    media = 0;






  
/*
  int ValorSensor = 0;
  int valorMaior = 0;
  float tensao = 0;
  int dB = 0;
  int cont = 0;

    while(cont < 1200)
      {
        ValorSensor = analogRead(D);
        if(ValorSensor > valorMaior)
          {
            valorMaior = ValorSensor;
          }
            cont++;
        }
        
    cont = 0;
    tensao = valorMaior/1023.0*4.53;
    //dB = 103.1*tensao - 115,4;
    dB = 87.1*tensao - 75,4;
    
    //dB = (83.2073+analogRead(D))/11.003;
    if(dB < 0)
      {
      dB = 0;
    }
  */
  
  return String(Vrms1);
}
//------------------------------------------------------


//------------------SENSOR DE FORÇA --------------------
float forca(byte E){   // E - ENTRE COM O PINO FISICO DA ENTRADA ANALÓICA

float kg = 0;
/*
    const float VCC = 4.98; // Measured voltage of Ardunio 5V line
    const float R_DIV = 9910.0; // Measured resistance of 3.3k resistor
    
    int fsrADC = Filtro_Analog(E,15,10);

      if (fsrADC != 0) // If the analog reading is non-zero
  {
    float fsrV = fsrADC * VCC / 1023.0;
    float fsrR = R_DIV * (VCC / fsrV - 1.0);
    //float force;
    float fsrG = 1.0 / fsrR; // Calculate conductance

    if (fsrR <= 600) 
      force = (fsrG - 0.00075) / 0.00000032639;
    else
      force =  fsrG / 0.000000642857;            
  }*/
    kg = map(Filtro_Analog(E,15,10),0,1023,0,5000);
    kg = kg/1000.00;
    
    return kg;
    //return force;
}
//------------------------------------------------------


//------------------SENSOR DE CORRENTE -----------------
double corrente(byte F){   // F - ENTRE COM O PINO FISICO DA ENTRADA ANALÓICA

    float zerar;
    //Pino, calibracao - Cur Const= Ratio/BurdenR. 2000/33 = 60
    if(sensorAC == 0){
      emon1.current(F, cal_30A); 
      zerar = 0.30;
    }
      else if(sensorAC == 1){
        emon1.current(F, cal_100A_v1);
        zerar = 0.20;
      }
      else if(sensorAC == 2){
        emon1.current(F, cal_100A_v2);
        zerar = 0.20;
      }
      
    //Calcula a corrente
    double Irms = emon1.calcIrms(1480); 
           Irms = Irms - zerar;

           if(Irms < 0) Irms = 0;

    return Irms;
}
//------------------------------------------------------


//------------------  SENSOR DE PH  --------------------
float medir_ph(byte G){   // G - ENTRE COM O PINO FISICO DA ENTRADA ANALÓICA

    float tensao;               // Variável para conversão em tensão
    float V_pH;

  if(PH_padrao == 0){
    float valor_calibracao = 21.7;   // Fator de calibração

    tensao = (Filtro_Analog(G,20,10) * 5.0) / 1024.0;
    V_pH = -5.7 * tensao + valor_calibracao;    // Calcula valor de pH
  }
    else if(PH_padrao == 0){

          tensao = Filtro_Analog(G,20,10);
          if(tensao >= adc_4710[1]) V_pH = (graf4_7 [0] * tensao) + graf4_7 [1];
            else if(tensao <= adc_4710[1]) V_pH = (graf7_10 [0] * tensao) + graf7_10 [1];

    }
    return V_pH;
}
//------------------------------------------------------


//------------------- SENSOR HALL ----------------------
long s_hall(byte H){   // H - ENTRE COM O PINO FISICO DA ENTRADA ANALÓICA

    long hl = 0;
    hl = Filtro_Analog(H,15,10);
    if (hl >= 600) return 0;
    else return 1;

    return hl;
}
//------------------------------------------------------

/*
//------------------- SENSOR HALL ----------------------
String batimentos(byte I){   // H - ENTRE COM O PINO FISICO DA ENTRADA ANALÓICA

  pulseSensor.analogInput(I);   
  pulseSensor.setThreshold(Threshold); 

  pulseSensor.begin();

  String bpm_out;

   int myBPM = pulseSensor.getBeatsPerMinute();  // Calls function on our pulseSensor object that returns BPM as an "int".
                                               // "myBPM" hold this BPM value now. 

    if (pulseSensor.sawStartOfBeat()) {            // Constantly test to see if "a beat happened". 
      Serial.println("♥  A HeartBeat Happened ! "); // If test is "true", print a message "a heartbeat happened".
      Serial.print("BPM: ");                        // Print phrase "BPM: " 
      Serial.println(myBPM);                        // Print the value inside of myBPM. 
      }

    bpm_out = String(myBPM);

    return bpm_out;
}*/
//------------------------------------------------------
