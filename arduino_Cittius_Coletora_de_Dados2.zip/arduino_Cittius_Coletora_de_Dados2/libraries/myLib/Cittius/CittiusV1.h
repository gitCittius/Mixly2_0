
//  faixa de 290adc placa vermelha
//  faixa de 400sdc placa azul




// SETA O TIPO DE LCD
// LCD 16 OU 20
#define LCDType 20


//libraries

#include "OneButton.h"         //Biblioteca para eventos para botões
#include <Wire.h>              //Biblioteca nativa da IDE

#include "variaveis.h"
#include <EEPROM.h>
#include <SPI.h>
#include <MFRC522.h>
#include <LiquidCrystal_I2C.h>
//#include <OneWire.h>            // VERSÃO 2.3.7
//#include <TimerOne.h>
#include <TimerThree.h>

#include "grava_val.h"
#include "nomecard.h"
#include "rfid_read.h"
#include "sens_analog.h"
//#include "sens_digital.h"

#if LCDType == 16 
  #include "display_16x2.h"
#elif LCDType == 20
  #include "display_20x4.h"
#endif

#include "calibra_ph.h"
//#include "sens_analog.h"
#include "sens_digital.h"
#include "botoes.h"
#include "atualiza.h"
#include "batimentos.h"
#include "tacho.h"
//#include "calibra_ph.h"
//#include "nomecard.h"


void inicializacaoAluno()
{
  flagSetupAluno = true;
  flagLoopAluno = true;
}

void getAddressDisplay()
{
  int nDevices = 0;
  static byte address = 1;
#ifdef DEBUG
  Serial.println("Produrando...");
#endif
  for (address = 1; address < 127; ++address)
  {

    Wire.beginTransmission(address);
    byte error = Wire.endTransmission();

    if (error == 0)
    {
#ifdef DEBUG
      Serial.print("I2C device found at address 0x");
#endif
      if (address < 16)
      {
#ifdef DEBUG
        Serial.print("0");
#endif
      }

#ifdef DEBUG
      Serial.print(address, HEX);
      Serial.println("  !");
#endif

      if (address == 0x27)
      {
#ifdef DEBUG
        Serial.println("");
        Serial.println("Endereço selecionado foi 0x27");
#endif
        lcdAddress = 0x27;
      }
      else if (address == 0x3F)
      {
#ifdef DEBUG
        Serial.println("");
        Serial.println("Endereço selecionado foi 0x3F");
#endif
        lcdAddress = 0x3F;
      }

      ++nDevices;
    }
    else if (error == 4)
    {
#ifdef DEBUG
      Serial.print("Unknown error at address 0x");
#endif
      if (address < 16)
      {
#ifdef DEBUG
        Serial.print("0");
#endif
      }
#ifdef DEBUG
      Serial.println(address, HEX);
#endif
    }
  }

  if (nDevices == 0)
  {
#ifdef DEBUG
    Serial.println("No I2C devices found\n");
#endif
  }
  else
  {
#ifdef DEBUG
    Serial.println("done\n");
#endif
  }
}


void _loop(){

}

void _delay(float seconds)
{                                           // Valores em Segundos
  long endTime = millis() + seconds * 1000; // Converter valores Segundos em millis
  while (millis() < endTime)
    _loop(); // Chamar funções dos eventos a todos momento.
}


void atualizarDisplay(const char *valor, int _linha_, int _coluna_)
{
  char str[21]; // cria uma nova matriz para armazenar a string modificada
  int len = strlen(valor);

  if (len > 20)
  { // se a string de entrada for maior do que 20 caracteres, trunque-a para 20
    len = 20;
  }

  strncpy(str, valor, len); // copie os primeiros len caracteres da string de entrada para a nova matriz
  str[len] = '\0';          // adicione o caractere nulo de terminação no final da nova matriz

  // preencha o restante da nova matriz com espaços em branco
  for (int i = len; i < 20; i++)
  {
    str[i] = ' ';
  }
  str[20] = '\0'; // adicione o caractere nulo de terminação no final da nova matriz

  // adiciona um espaço em branco extra no final da string, se ela tiver menos de 11 caracteres
  if (len < 9)
  {
    str[len] = ' ';
    str[len + 1] = '\0';
  }

  // Verifique se a string de entrada contém o caractere de graus
  char *pos = strchr(str, 176);
  if (pos != NULL)
  {
    // Se o caractere de graus for encontrado, substitua-o por "°C"
    *pos = ' ';
    *(pos + 1) = ' ';
    lcd->setCursor(_coluna_, _linha_);
    lcd->print(str);
    lcd->setCursor(_coluna_ + (pos - (str + 1)), _linha_);
    lcd->write(B11011111);
    lcd->print("C");
  }
  else
  {

    // Se o caractere de graus não for encontrado, imprima a nova matriz inteira
    lcd->setCursor(_coluna_, _linha_);
    lcd->print(str);
  }
}

//--------------------------- INTERRUPÇÃO PARA DEBOUNCING DE BOTÃO ----------------------------
void INTERRUPCAO(){

  if((Button_dn != 0) && (Flag_Button_dn == 1))
      Flag_Button_dn = 0;

  if((Button_up != 0) && (Flag_Button_up == 1))
      Flag_Button_up = 0;

  if((Button_enter != 0) && (Flag_Button_enter == 1))
      Flag_Button_enter = 0;

  if((Button_voltar != 0) && (Flag_Button_voltar == 1))
      Flag_Button_voltar = 0;

}
//---------------------------------------------------------------------------------------------


void initSetup() {

  Wire.begin();

  //Serial.begin(115200);     // UTILIZADO PARA TESTE RETIRAR
  Serial.begin(9600);     // UTILIZADO PARA TESTE RETIRAR
  sensors.begin();
  
  pinMode (38, INPUT_PULLUP);
  pinMode (47, INPUT_PULLUP);
  pinMode (48, INPUT_PULLUP);
  pinMode (49, INPUT_PULLUP);
  pinMode (BUZ, OUTPUT);

  getAddressDisplay();




  
//---------------------- UTILIZADO PARA CONFIGURAR AS SAÍDAS DE M1 A M4 ---------------------
  pinMode (2, OUTPUT);
  pinMode (62, OUTPUT);
  pinMode (3, OUTPUT);
  pinMode (63, OUTPUT);
  pinMode (18, OUTPUT);
  pinMode (64, OUTPUT);
  pinMode (19, OUTPUT);
  pinMode (65, OUTPUT);  
  // DETERMINA QUE A SAÍDA FIQUE EM NÍVEL BAIXO  
  digitalWrite(2,LOW);
  digitalWrite(62,LOW);
  digitalWrite(3,LOW);
  digitalWrite(63,LOW);  
  digitalWrite(18,LOW);
  digitalWrite(64,LOW);
  digitalWrite(19,LOW);
  digitalWrite(65,LOW);       

  pinMode(PinTrigger, OUTPUT);
  digitalWrite(PinTrigger, LOW);
  pinMode(PinEcho, INPUT); // configura pino ECHO como entrada


 btnEnter.attachClick(eventEnter);
 btnVoltar.attachLongPressStart(eventVoltar);
 btnCima.attachClick(eventCima);
 btnBaixo.attachClick(eventBaixo);
//------------------------------------------------------------------------------------------      

//------------------------------------------------------------------------------------------  
  lcd = new LiquidCrystal_I2C(lcdAddress, colunas, linha);

  lcd->init();
  lcd->backlight();
  lcd->clear();


  lcd->createChar(1, SIMB1);
  lcd->createChar(2, SIMB2);
//------------------------------------------------------------------------------------------ 

//------------------------------ AJUSTA MEMÓRIA EEPROM ------------------------------------------------------------ 
if(LCDType == 20){
  if(EEPROM.read(0) > 4) {  // SERÁ INICIADO UM AJUSTE DE VALORES EM TODAS AS POSIÇOES DA MEMÓRIA EEPROM, DEIXANDO EM 0 AO INVÉS DE 255
    tela_zerar_eeprom(EEPROM.length(),0);
    for (int i = 1 ; i < EEPROM.length() ; i++) {
      EEPROM.write(i, 0);
      
      lcd->setCursor(10,2);
      lcd->print(i);   
         
      //Serial.print("POSIÇÃO ( ");
      //Serial.print(i);
      //Serial.print(" ) = ");
      //Serial.println(EEPROM.read(i));
    }
    tela_zerar_eeprom(0,1);

    while(true){
      if (Button_enter == 0) break;
    }
      EEPROM.write(0, 0);
      Serial.print("POSIÇÃO ( ");
      Serial.print(0);
      Serial.print(" ) = ");
      Serial.println(EEPROM.read(0));  
      lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA  
  }
}
//------------------------------------------------------------------------------------------ 

//------------------------------------------------------------------------------------------ 
  for (int i = 0; i <= 11; i++) {
    dados_out[i] = EEPROM.read(100 + i);
    }
//------------------------------------------------------------------------------------------ 

//-------------------------------- INICIA A INTERRUPÇÃO ----------------------------------------------------------  
  Timer3.initialize(DEBOUNCING);                                // DETERMINA O TEMPO DE INTERRUPÇÃO
  Timer3.attachInterrupt(INTERRUPCAO);                          // CHAMA A FUNÇÃO A CADA ESTOURO DE TEMPO DA INTERRUPÇÃO
//------------------------------------------------------------------------------------------  

//------------------------------------------------------------------------------------------ 
  Timer3.stop();
  lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA  
  inicializar();
  
  delay(1500);
  lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
  Timer3.start();
//------------------------------------------------------------------------------------------  

//------------------------------------ RESET MATÉRIA ------------------------------------------------------
#if LCDType == 20 

  if ((Button_enter == 0) && (Button_dn == 0)){
    lcd->setCursor(0,0);
    lcd->print(F("        RESET       "));
    EEPROM.write(0, 0);
    while((Button_enter == 0) || (Button_dn == 0)){
      
    }
  } 

#endif
  
  lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA 
//------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------  
if(LCDType == 20){
  if(EEPROM.read(0) == 0) {
    materia = 1;
    versao(0,materia);
     
      while(true){
        le_botao();
        if(Flag_Button_enter == 1) break;
        }
      EEPROM.write(0, materia);
  }
  else {
        materia = EEPROM.read(0);
        versao(0,materia);
      }
    
}else if(LCDType == 16){
    versao(0,0);
}

    delay(2000);
//------------------------------------------------------------------------------------------ 

//----------------------------------- DETERMINA OS SENSORES QUE SERÃO LIDOS ------------------------------------------------------- 
  materia = EEPROM.read(0);

#if LCDType == 16 
  materia = 5;
#elif LCDType == 20
  materia = EEPROM.read(0);
#endif

  int i = 0;

  switch(materia){
    case 1:{    // MATEMATICA
      menu_2max = seq_mat [0];    // A POSIÇÃO 0 DETERMINA A QUANTIDADE DE SENSORES QUE SERÃO LIDOS
      menu_3max = seq_mat [0];  
      
      for(i = 0; i < (sizeof(seq_mat) - 1); i++) {
        seq_uso[i] = seq_mat[i];
      }   
    }
    break;

    case 2:{    // FISICA
      menu_2max = seq_fis [0];    // A POSIÇÃO 0 DETERMINA A QUANTIDADE DE SENSORES QUE SERÃO LIDOS
      menu_3max = seq_fis [0]; 
       
      for(i = 0; i < (sizeof(seq_fis) - 1); i++) {
        seq_uso[i] = seq_fis[i];
      }           
    }
    break;
    
    case 3:{    // QUIMICA
      menu_2max = seq_qui [0];    // A POSIÇÃO 0 DETERMINA A QUANTIDADE DE SENSORES QUE SERÃO LIDOS
      menu_3max = seq_qui [0];
       
      for(i = 0; i < (sizeof(seq_qui) - 1); i++) {
        seq_uso[i] = seq_qui[i]; 
      }          
    }
    break;

    case 4:{    // BIOLOGIA
      menu_2max = seq_bio [0];    // A POSIÇÃO 0 DETERMINA A QUANTIDADE DE SENSORES QUE SERÃO LIDOS
      menu_3max = seq_bio [0];
      
      for(i = 0; i < (sizeof(seq_bio) - 1); i++) {
        seq_uso[i] = seq_bio[i];
      }      
    }
    break;

    case 5:{    // 16x2
      menu_2max = 9;    // A POSIÇÃO 0 DETERMINA A QUANTIDADE DE SENSORES QUE SERÃO LIDOS
      menu_3max = 9;
      
      //for(i = 0; i < (sizeof(seq_bio) - 1); i++) {
      //  seq_uso[i] = seq_bio[i];
      //}      
    }
    break;    
 }
//------------------------------------------------------------------------------------------ 

      sensorAC = EEPROM.read(7);

if((EEPROMReadlong(1) != 0)&&(EEPROMReadlong(1) > 600)&&(EEPROMReadlong(1) < 690)) PH_padrao = 1;
  else PH_padrao = 0;
if((EEPROMReadlong(3) != 0)&&(EEPROMReadlong(3) > 500)&&(EEPROMReadlong(3) < 590)) PH_padrao = 1;
  else PH_padrao = 0;
if((EEPROMReadlong(5) != 0)&&(EEPROMReadlong(5) > 400)&&(EEPROMReadlong(5) < 490)) PH_padrao = 1;
  else PH_padrao = 0;

if(PH_padrao == 1){

adc_4710[0] = EEPROMReadlong(1);
adc_4710[1] = EEPROMReadlong(3);
adc_4710[2] = EEPROMReadlong(5);
covert_adcph();
}

    for (int i = 86; i <= 96 ; i += 2) {
        xy = (0.5*i) - 43;
        xy_load = EEPROMReadlong(i);
        if (xy_load > 60000) calibrationData[ EPM_X [xy] ][  EPM_Y [xy] ] = 65536 - xy_load;
          else calibrationData[ EPM_X [xy] ][  EPM_Y [xy] ] = xy_load;
        //Serial.println(EEPROMReadlong(i));
        //Serial.println("i = " + String(i));
        //Serial.println("xy = " + String(xy));
    }
    //Serial.println(calibrationData[0][0]);
    //Serial.println(calibrationData[0][1]);
    //Serial.println(calibrationData[1][0]);
    //Serial.println(calibrationData[1][1]);
    //Serial.println(calibrationData[2][0]);
    //Serial.println(calibrationData[2][1]);




//------------------------------------------------------------------------------------------ 
  SPI.begin();               // INICIALIZA O BARRAMENTO SPI

  mfrc522.PCD_Init();                                           // INICIA O LEITOR DE CARTÃO MFRC522
  mfrc522.PCD_SetAntennaGain(mfrc522.RxGain_43dB);              // AUMENTA O GANHO DE ANTENA DO MRFC522 PARA O MÁXIMO
  //mfrc522.PCD_SetAntennaGain(mfrc522.RxGain_48dB);            // AUMENTA O GANHO DE ANTENA DO MRFC522 PARA O MÁXIMO  

  //mfrc522.PCD_DumpVersionToSerial(); 
  
  //Timer3.initialize(DEBOUNCING);                                // DETERMINA O TEMPO DE INTERRUPÇÃO
  //Timer3.attachInterrupt(INTERRUPCAO);                          // CHAMA A FUNÇÃO A CADA ESTOURO DE TEMPO DA INTERRUPÇÃO

  lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA
  tela = 1;
  menu(menu_1);

 /*         for (int i = 1; i <= 23; i++){
              Serial.print("vetor card = "); 
              Serial.print(vetor_card [i]);
              Serial.print(" - ");
              Serial.print(Nome_card(vetor_card [i],0));
              Serial.print(" - ");
              Serial.println(Nome_card(vetor_card [i],1));
              } */

        lcd->setCursor(0,3);
        lcd->write(2);

}

void updateLoop() {

_loop();
  btnEnter.tick();
  btnVoltar.tick();
  btnCima.tick();
  btnBaixo.tick();

/*
unsigned long kk;
if((millis() - kk) >= 700){
  Serial.print("db = ");
  Serial.println (analogRead(67));
  kk = millis();
}
*/

  le_botao();

//Serial.print("n card = ");
//Serial.println(N_CARD);
//Serial.print("val_ref_sensor = ");
//Serial.println(val_ref_sensor);

  if((tela == 5)&&(flag_val_ref  == 1)&&(N_CARD == 3)){

    val_ref_old = val_ref_sensor;
    Set(val_ref_sensor, val_ref_senmax, val_ref_senmin, 1);

    if(val_ref_old != val_ref_sensor){

          Serial.print("val_ref_sensor = ");
          Serial.println(val_ref_sensor);

          convert_val = String(val_ref_sensor,1);

          lcd->setCursor(8,1);
          lcd->print(convert_val);
          
          
          //tamanho = convert_val.length();
          //escreve_cards();
          
          //Serial.print("tamanho = ");
          //Serial.println(tamanho);
          
          Flag_print_ref  = 0;
      
    }
  }

//------------------------------------------------------------------------------------------
  if (tela == 8){
    Timer3.stop();
          if ((millis() - atual_busso) >= 1000){
            if(Flag_bussola == 0) {
              //inicia_bussola();
              //le_bussola();

              compass.init();
              delay(50);
              compass.read();
              delay(100);
              compass.setCalibration(calibrationData[0][0], calibrationData[0][1], calibrationData[1][0],calibrationData[1][1], calibrationData[2][0], calibrationData[2][1]);

              #if LCDType == 16 
                lcd->setCursor(0,1);
                lcd->print("Azimute");

                Flag_bussola = 1;

              #elif LCDType == 20
                lcd->setCursor(0,1);
                lcd->print("Azimute         ");

                Flag_bussola = 1;
                lcd->setCursor(0,3);
                lcd->print("                    ");
              #endif              
            }
              else le_bussola();
              
            atual_busso = millis();
          }
    Timer3.start();
  }
//------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------
  if (tela == 9){
    Timer3.stop();
    
    if (flag_BPM == 0) setup_bat();
    
    loop_bat();
    Timer3.start();
  }
//------------------------------------------------------------------------------------------
  
  
//------------------------------------------------------------------------------------------ 
  if( (millis() - tempoold >= intervalo)&&(tela == 2)&&(tela != 6) ) {
    Timer3.stop();  
      menu2_atual(seq_uso [menu_2]);
      menu2(seq_uso [menu_2]);   
    Timer3.start();
    tempoold = millis();
    }
//------------------------------------------------------------------------------------------ 
    
//---------------------------------- SELECIONA QUAIS DADOS SERÃO ENVIADOS PELA SERIAL --------------------------------------------------------   
  if( (millis() - tempoold2 >= intervalo2)&&(tela == 4)&&(tela != 6) ) {
    Timer3.stop();
    contagem += 1;
    if (contagem > menu_2max) contagem = 1;  
      menu2_atual(seq_uso [contagem]);  
    Timer3.start();
    tempoold2 = millis();
    }
//------------------------------------------------------------------------------------------ 

//-------------------------------- ENVIA VALORES PELA SERIAL ---------------------------------------------------------- 
  if( (millis() - tempoold3 >= intervalo3)&&(tela == 4)&&(tela != 6)) {
    Timer3.stop();

    for(env = 1; env <= (seq_uso [0]); env++){     
      var_out(seq_uso[env],dados_out[env]);
    }

    Serial.println(dataString);        
    dataString = "";
    Timer3.start();
    tempoold3 = millis();
    }    
//------------------------------------------------------------------------------------------ 



//------------------------------------------- CRIA A SEQUENCIA DAS ATIVIDADES -------------------------------------------
#if LCDType == 20

if(((millis() - Tarefa) > T_CARD) && (tela != 6)){   
  //if ((Flag_card == 1)&&(Flag_play == 0)&&(Flag_edit == 0)){
  if ((tela == 5)&&(Flag_play == 0)&&(Flag_edit == 0)){
      Timer3.stop();

        if ((N_CARD >= 0)&&(N_CARD <= 13)){
          mfrc522.PCD_Reset();            // FAZ O RESET DO CONTROLADOR RFID PARA TENTAR EVITAR O TRAVAMENTO QUE ESTAVA OCORRENDO DE FORMA INESPERADA
          delay(50);
          mfrc522.PCD_Init();             // REINICIA O CONTROLADOR DO RFID APÓS O RESET
          mfrc522.PCD_AntennaOn();        // MESMO REINICIADO, FORÇA A LIGAR A ANTENA
          mfrc522.PCD_SetAntennaGain(mfrc522.RxGain_43dB);              // AUMENTA O GANHO DE ANTENA DO MRFC522 PARA O MÁXIMO

          le_cartao();                    // FUNÇÃO PARA LEITURA DO CARTÃO RFID
        }


      if ((Flag_read == true)&&((N_CARD >= 0)&&(N_CARD <= 13))){    // VAI DE 0 A 13, GERANDO 14 SEQUENCIAS DE ATIVIDADE
        
        switch(N_CARD){
          case 0: 
            if (pos_card != 1){
              rfid_card="";
              //N_CARD = 0;
              Flag_read = false;
              tone(BUZ,500,100);
              delay(300);
              tone(BUZ,500,100);
            }
            else if (pos_card == 1){
                  lcd->setCursor(0,3);
                  lcd->print(F("ESCOLHA A COMPARACAO"));              
            }
            break;

          case 1: 
            if (pos_card != 2){
              rfid_card="";
              //N_CARD = 0;
              Flag_read = false;
              tone(BUZ,500,100);
              delay(300);
              tone(BUZ,500,100);
            }
            else if (pos_card == 2){
                  Flag_print_ref  = 1;
                  
                  lcd->setCursor(0,3);
                  lcd->print(F("+ OU - AJUSTA VALOR "));              
            }
            break; 

          case 3: 
            if (pos_card != 4){
              rfid_card="";
              //N_CARD = 0;
              Flag_read = false;
              tone(BUZ,500,100);
              delay(300);
              tone(BUZ,500,100);
            }
            else if (pos_card == 4){
                  //Flag_print_ref  = 1;
                  
                  lcd->setCursor(0,3);
                  lcd->print(F("ON OU OFF,BUZ OU LED"));              
            }
            break; 

          case 4: 
            if (pos_card != 5){
              rfid_card="";
              //N_CARD = 0;
              Flag_read = false;
              tone(BUZ,500,100);
              delay(300);
              tone(BUZ,500,100);
            }
            else if (pos_card == 5){
                  //Flag_print_ref  = 1;
                  
                  lcd->setCursor(0,3);
                  lcd->print(F(" PLAY, OU ADD PAUSA "));              
            }
            break;  

          case 5: 
            if (pos_card != 6){
              rfid_card="";
              //N_CARD = 0;
              Flag_read = false;
              tone(BUZ,500,100);
              delay(300);
              tone(BUZ,500,100);
            }
            else if (pos_card == 6){
                  //Flag_print_ref  = 1;
                  lcd->setCursor(0,3);
                  lcd->print(F("  ESCOLHA O TEMPO   "));              
            }
            break;  

          case 6: 
            if (pos_card != 7){
              rfid_card="";
              //N_CARD = 0;
              Flag_read = false;
              tone(BUZ,500,100);
              delay(300);
              tone(BUZ,500,100);
            }
            else if (pos_card == 7){
                  //Flag_print_ref  = 1;
                  lcd->setCursor(0,3);
                  lcd->print(F("ENTER INICIA O PLAY "));              
            }
            break;                                                  

          default: 
              //flag_val_ref = 0;
              rfid_card="";
              Flag_read = false;
              tone(BUZ,500,100);
              delay(300);
              tone(BUZ,500,100);
            break;                          
        }
          
        }

               
      
      if ((Flag_read == true)&&((N_CARD >= 0)&&(N_CARD <= 13))){    // VAI DE 0 A 13, GERANDO 14 SEQUENCIAS DE ATIVIDADE


        Serial.print("Posição do cartão = ");
        Serial.println(pos_card);

        Serial.print("Valor de referencia = ");
        Serial.println(val_ref_sensor);

        Serial.println(""); 


        //tamanho = Nome_card(rfid_card,1).length();
        byte recebe_cartao = 0;
        byte card_prog = 0;
        byte card_eprom = 0;
        byte ep_min = 0;
        byte ep_max = 0;
        
        //seq_cartao_tft(N_CARD,Nome_card(rfid_card,1));              // IMPRIME O NOME DO CARTÃO NA TELA TFT

      //-------------------------------------------
        if(Nome_card(rfid_card,1).length() == 13){
          //Serial.println("PROGRAMAVEL");
          if(Nome_card(rfid_card,1)[12] == '1'){
            ep_min = 10;
            ep_max = 22;
          }
          if(Nome_card(rfid_card,1)[12] == '2'){
            ep_min = 30;
            ep_max = 42;            
          }
          if(Nome_card(rfid_card,1)[12] == '3'){
            ep_min = 50;
            ep_max = 62;            
          }
          if(Nome_card(rfid_card,1)[12] == '4'){
            ep_min = 70;
            ep_max = 82;            
          }
          
          
          for (int i = 0; i <= 13; i++){          // VERIFICA SE O CARTÃO LIDO POSSUI VALORES GRAVADOS, CASO TENHA ELE INICIA OS VALORES DA MEMORIA NA VARIÁVEL PLAY 
            recebe_cartao = le_progx(ep_min + i);
            if(recebe_cartao != 0) break;
              }
              if (recebe_cartao == 0) card_prog = 1;            // CARTÃO ESTA VAZIO, PODE SER USADO PARA GRAVAR
                else if(recebe_cartao != 0) card_prog = 2;      // CARTÃO ESTA CHEIO, VAI SER CRIADO A SEQUENCIA GRAVADA
                
          if (card_prog == 1 && N_CARD > 0 && flag_apaga == 0){          // INICIA GRAVAÇÃO DA SEQUENCIA PLAY PARA O CARTÃO
          for (int i = 0; i <= 13; i++){
              grava_progx(ep_min + i, Seq_PLAY [i]);  
              }
              card_prog = 0;
              }

          if (card_prog == 2 && flag_apaga == 0){
            N_CARD = 0;
            tamanho_total = 0;
            tamanho_total2 = 0;
            tamanho_total3 = 0;
            tamanho = 0;
            lcd->setCursor(0,1);
            lcd->print(F(":                   "));
            lcd->setCursor(0,2);
            lcd->print(F("                    "));
            lcd->setCursor(0,3);
            lcd->print(F("                    "));                        
            for (int i = ep_min; i <= ep_max; i++){
              card_eprom = EEPROM.read(i);
              if (card_eprom == 0) break;
              tamanho = Nome_card(vetor_card [card_eprom],1).length();
              rfid_card = vetor_card [card_eprom];
              escreve_cards();
            }
            card_prog = 0;
          }else if(flag_apaga == 1){
                  for (int i = 0; i <= 13; i++){
                  grava_progx(ep_min + i, "0");  
              }
              lcd->setCursor(6,0);
              lcd->print(F("      "));
              flag_apaga = 0;
          }
              
          }
      //-------------------------------------------
          else{
                                         
        //Serial.println("cartão normal ");
        tamanho = Nome_card(rfid_card,1).length();
        escreve_cards();

        if (Flag_print_ref  == 1){
          convert_val = String(val_ref_sensor,1);
          
          //Serial.print("convert = ");
          //Serial.println(convert_val);

          //N_CARD -= 1;
          tamanho = (convert_val.length() +1);
          escreve_cards();
          
          //Serial.print("tamanho = ");
          //Serial.println(tamanho);
          
          Flag_print_ref  = 0;
          flag_val_ref = 1;
        }

          }
        rfid_card="";
        tone(BUZ,2000,50);
        Flag_read = false;       
        }
        
      Timer3.start();  
  }
    Tarefa = millis();
}

#endif
//-------------------------------------------FIM DO CRIA A SEQUENCIA DAS ATIVIDADES -------------------------------------------

//------------------------------------------- INICIA A SEQUENCIA DAS ATIVIDADES (PLAY) -------------------------------------------
#if LCDType == 20

if ((Flag_play == 1)&&((N_PLAY >= 0)&&(N_PLAY <= 13))){

  //Serial.print("N_PLAY = ");
  //Serial.println(N_PLAY);
  
  play_atual(Seq_PLAY [0]);
  PLAY(Seq_PLAY [N_PLAY]); 
  }
  else if ((Flag_play == 1)&&(N_PLAY >= 14)){
          PLAY("60");
          }

#endif          
//------------------------------------------- FIM INICIA A SEQUENCIA DAS ATIVIDADES (PLAY) -------------------------------------------

  if (tela == 11){
    Timer3.stop();
    while(1){
      tach();
      }
    }

}   // FIM DO LOOP
