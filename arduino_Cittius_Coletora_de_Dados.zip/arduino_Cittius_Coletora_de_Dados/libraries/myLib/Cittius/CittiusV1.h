#define DEBUG1 // Usado para debug via Serial

#include "pins_arduino.h"
#include "Arduino.h"
// Bibliotecas

#include "OneButton.h"         //Biblioteca para eventos para botões
#include <Wire.h>              //Biblioteca nativa da IDE
#include <LiquidCrystal_I2C.h> //Biblioteca para o display I2C
#include <EEPROM.h>
#include "rsteck.h" //Incluir a biblioteca do chip PCA9685

#include <MPU6050_light.h>
MPU6050 mpu(Wire);
#include <NewTone.h>

#include <OneWire.h>
#include <DallasTemperature.h>

#define CUSTOM_SETTINGS
#define INCLUDE_GAMEPAD_MODULE
#include <Dabble.h>

// Display I2C para o display 16x2
#define linha 4
#define colunas 20

OneWire oneWire_A15_(A15);
DallasTemperature sensors_A15_temp(&oneWire_A15_);
DeviceAddress insideThermometer_;

// Variaveis Globais
byte lcdAddress = 0x3F;        // Variavel que recebe o endereço I2C do chip de expansão de IO, os endereços possíveis são 0x27 ou 0x3F
LiquidCrystal_I2C *lcd = NULL; // Não sei o que significa, mas cria um objeto "Livre" para o display. É bem interessante e deve ser estudado para Sensores do médio em robotica

OneButton btnEnter(49, true);  // Botão Enter da placa v1 e V2
OneButton btnVoltar(48, true); // Botão Enter da placa v1 e V2
OneButton btnMais(47, true);   // Botão Enter da placa v1 e V2
OneButton btnMenos(38, true);  // Botão Enter da placa v1 e V2

// Variaveis Globais
boolean flagSetupMenu = false, // Setup da Tela
    flagSetupProgram = false,  // Setup da Tela Akuno
    flagSetupAluno = false,    // Setup da Tela Akuno
    flagLoopAluno = false;     // Setup da Tela Akuno

long millisTarefa1;
char txt0[50];

int padding;
boolean enableReadSensor = false;

byte menu = 1, menuSensores = 1;

float temperaturaI1(int w)
{
  sensors_A15_temp.requestTemperatures();
  if (w == 0)
  {
    return sensors_A15_temp.getTempC(insideThermometer_);
  }
  else
  {
    return sensors_A15_temp.getTempF(insideThermometer_);
  }
}

void getAddressDisplay()
{
  int nDevices = 0;
  static byte address = 1;
#ifdef DEBUG
  Serial.println("Produrando...");
#endif
  for (address = 1; address < 127; ++address)
  {

    Wire.beginTransmission(address);
    byte error = Wire.endTransmission();

    if (error == 0)
    {
#ifdef DEBUG
      Serial.print("I2C device found at address 0x");
#endif
      if (address < 16)
      {
#ifdef DEBUG
        Serial.print("0");
#endif
      }

#ifdef DEBUG
      Serial.print(address, HEX);
      Serial.println("  !");
#endif

      if (address == 0x27)
      {
#ifdef DEBUG
        Serial.println("");
        Serial.println("Endereço selecionado foi 0x27");
#endif
        lcdAddress = 0x27;
      }
      else if (address == 0x3F)
      {
#ifdef DEBUG
        Serial.println("");
        Serial.println("Endereço selecionado foi 0x3F");
#endif
        lcdAddress = 0x3F;
      }

      ++nDevices;
    }
    else if (error == 4)
    {
#ifdef DEBUG
      Serial.print("Unknown error at address 0x");
#endif
      if (address < 16)
      {
#ifdef DEBUG
        Serial.print("0");
#endif
      }
#ifdef DEBUG
      Serial.println(address, HEX);
#endif
    }
  }

  if (nDevices == 0)
  {
#ifdef DEBUG
    Serial.println("No I2C devices found\n");
#endif
  }
  else
  {
#ifdef DEBUG
    Serial.println("done\n");
#endif
  }
}

void _loop()
{
}

void _delay(float seconds)
{                                           // Valores em Segundos
  long endTime = millis() + seconds * 1000; // Converter valores Segundos em millis
  while (millis() < endTime)
    _loop(); // Chamar funções dos eventos a todos momento.
}

void pageSensores()
{
  if (enableReadSensor)
  {
    switch (menuSensores)
    {
    case 0x01:
      lcd->setCursor(0, 0);
      lcd->print("Temperatura   I1");
      lcd->setCursor(0, 1);

      if (temperaturaI1(0) == (-127.00))
      {
        lcd->print("ERROR     ");
      }
      else
      {
        sprintf(txt0, "%02d.%02d", (int)temperaturaI1(0), (int)(temperaturaI1(0) * 100) % 100);
        lcd->print(txt0);
        lcd->write(B11011111);
        lcd->print("C");
      }

      break;

    case 0x02:
      lcd->setCursor(0, 0);
      lcd->print("Temp/Umidade  I2");
      // lcd->setCursor(0, 1);
      break;

    case 0x03:
      lcd->setCursor(0, 0);
      lcd->print("Utrassonico   I3");

      break;

    case 0x04:
      lcd->setCursor(0, 0);
      lcd->print("Umidade.Solo  I4");

      break;

    case 0x05:
      lcd->setCursor(0, 0);
      lcd->print("Efeito HALL   M1");

      break;

    case 0x06:
      lcd->setCursor(0, 0);
      lcd->print("Colorimetro   M2");

      break;
    }

    Serial.print(temperaturaI1(0));
    // Serial.print(",");
  }
}

void eventoSimplesEnter()
{

  if (flagSetupAluno == false && enableReadSensor == false)
  {
    NewTone(26, 784, 30);
  }
  if (menu == 1)
  {
    NewTone(26, 784, 30);
    lcd->clear();
    flagSetupProgram = true;
  }
  else
  {

    lcd->clear();
    enableReadSensor = true;
  }
}

void eventoMenos2()
{
}

void eventoMenos()
{

  if (flagSetupAluno == false && enableReadSensor == false)
  {
    NewTone(26, 784, 30);
    menu = !menu;
    if (menu == 1)
    {
      lcd->setCursor(0, 0);
      lcd->print("> 1.Programacao ");
      lcd->setCursor(0, 1);
      lcd->print("  2.Ler Sensores");
    }
    else
    {
      lcd->setCursor(0, 0);
      lcd->print("  1.Programacao ");
      lcd->setCursor(0, 1);
      lcd->print("> 2.Ler Sensores"); // menuSensores
    }
  }

  if (flagSetupAluno == false && enableReadSensor == true)
  {
    NewTone(26, 784, 30);
    menuSensores++;
    if (menuSensores >= 7)
    {
      menuSensores = 1;
    }
  }
}

void eventoMais2()
{
}

void eventoMais()
{

  if (flagSetupAluno == false && enableReadSensor == false)
  {
    NewTone(26, 784, 30);
    menu = !menu;
    if (menu == 1)
    {
      lcd->setCursor(0, 0);
      lcd->print("> 1.Programacao ");
      lcd->setCursor(0, 1);
      lcd->print("  2.Ler Sensores");
    }
    else
    {
      lcd->setCursor(0, 0);
      lcd->print("  1.Programacao ");
      lcd->setCursor(0, 1);
      lcd->print("> 2.Ler Sensores");
    }
  }
  if (flagSetupAluno == false && enableReadSensor == true)
  {
    NewTone(26, 784, 30);
    menuSensores--;
    if (menuSensores <= 1)
    {
      menuSensores = 7;
    }
  }
}

void eventoDeVoltar()
{
  for (byte x = 0; x < 3; x++)
  {
    NewTone(26, 784, 30);
    NewTone(26, 250, 60);
  }

  if (flagSetupProgram == 1)
  {
    flagSetupProgram = false;
    flagSetupAluno = false;
  }

  if (enableReadSensor = true)
  {
    enableReadSensor = false;
  }

  lcd->clear();
  if (menu == 1)
  {
    lcd->setCursor(0, 0);
    lcd->print("> 1.Programacao ");
    lcd->setCursor(0, 1);
    lcd->print("  2.Ler Sensores");
  }
  else
  {
    lcd->setCursor(0, 0);
    lcd->print("  1.Programacao ");
    lcd->setCursor(0, 1);
    lcd->print("> 2.Ler Sensores");
  }
}

void eventoDeVoltar2()
{
}

void pageMenu()
{
}

void pageAluno()
{
}

void printGiroInterno()
{

  // sprintf(txt0, "%03d",-180);
  // tft.drawRightString(txt0,120,70,1);
}

void inicializacaoAluno()
{
  //_delay(0.25);

  flagSetupAluno = true;
  flagLoopAluno = true;
}

// Configuração Inicial para Sistema Cittius
void initSetup()
{
  Wire.begin();

  sensors_A15_temp.getAddress(insideThermometer_, 0);
  sensors_A15_temp.setResolution(insideThermometer_, 9);

  Serial.begin(9600); // Configura a taxa de transmissão em 115200, esse valor não pode ser alterado
  Dabble.begin(9600); // Enter baudrate of your bluetooth.Connect bluetooth on Bluetooth port present on evive.

  pinMode(26, OUTPUT);

  getAddressDisplay();

  pinMode(A1, OUTPUT); // pino do RFID como saida digital
  pinMode(A2, OUTPUT);

  // Nesse momento não sei quem é RST ou CS do RFID
  digitalWrite(A1, 0x01); // pino do RFID para Alta para elevar CS do chip
  digitalWrite(A2, 0x01); // pino do RFID para Alta para elevar CS do chip

  lcd = new LiquidCrystal_I2C(lcdAddress, colunas, linha);

  lcd->init();
  lcd->backlight();
  lcd->setCursor(0, 0);
  lcd->print("    CITTIUS    ");

  lcd->setCursor(0, 1);
  lcd->print("COLETOR DE DADOS");
  delay(1000);

  lcd->clear();

  lcd->setCursor(0, 0);
  lcd->print("     V2.0    ");

  delay(1000);

  lcd->clear();

  if (menu == 1)
  {
    lcd->setCursor(0, 0);
    lcd->print("> 1.Programacao ");
    lcd->setCursor(0, 1);
    lcd->print("  2.Ler Sensores");
  }
  else
  {
    lcd->setCursor(0, 0);
    lcd->print("  1.Programacao ");
    lcd->setCursor(0, 1);
    lcd->print("> 2.Ler Sensores");
  }

  delay(200);
  mpu.begin();
  delay(200);
  mpu.calcOffsets(); // gyro and accelero

  btnEnter.attachClick(eventoSimplesEnter);       // Simples Click no botão enter chama a função 1
  btnVoltar.attachClick(eventoDeVoltar2);         // Simples Click no botão enter chama a função 1
  btnVoltar.attachLongPressStart(eventoDeVoltar); // Simples Click no botão enter chama a função 1
  btnMais.attachDuringLongPress(eventoMais2);     // Simples Click no botão enter chama a função 1
  btnMais.attachClick(eventoMais);                // Simples Click no botão enter chama a função 1
  btnMenos.attachClick(eventoMenos);              // Simples Click no botão enter chama a função 1
  btnMenos.attachDuringLongPress(eventoMenos2);   // Simples Click no botão enter chama a função 1
}

void updateLoop()
{
  btnEnter.tick();
  btnVoltar.tick();
  btnMais.tick();
  btnMenos.tick();

  pageSensores();
  _loop();
}
