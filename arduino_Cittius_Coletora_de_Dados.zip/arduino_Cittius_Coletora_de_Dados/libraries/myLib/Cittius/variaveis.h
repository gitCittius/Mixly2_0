


#if LCDType == 16 
  String  Vsoft       = "      V3.0      "; //VERSÃO DA PROGRAMAÇÃO
#elif LCDType == 20
  String  Vsoft       = "        V6.0        "; //VERSÃO DA PROGRAMAÇÃO
#endif


boolean  flagSetupAluno=false, flagSetupProgram=false,flagLoopAluno=false;
unsigned long myDalaypreviousMillis = 0;
char strNumero[20]; // matriz para armazenar os valores atuais exibidos no display

//LiquidCrystal_I2C lcd(0x3F,16,2);  // set the LCD address to 0x27 for a 16 chars and 2 line display acrescentado para teste na placa RAFAEL




 byte SIMB1[8] = {
B00100,
B01110,
B11111,
B00100,
B00100,
B00100,
B00100,
B00100
};

 byte SIMB2[8] = {
B00100,
B00100,
B00100,
B00100,
B00100,
B11111,
B01110,
B00100
};


// push buttons
#define Button_dn     digitalRead(38)
#define Button_up     digitalRead(47)
#define Button_enter  digitalRead(49)
#define Button_voltar digitalRead(48)

String port_in [9] = { "I1", "I2", "I3", "I4", "M1", "M2", "M3", "M4"};
String materia_X [6] = { "                    ", "   ( MATEMATICA )   ", "     ( FISICA )     ", "     ( QUIMICA )    ", "    ( BIOLOGIA )    " };

byte seq_mat [10] = { 8, 1, 2, 3, 6,  7,  9, 10, 12};
byte seq_fis [11] = { 9, 1, 2, 3, 6,  7,  8,  9, 10, 12};
byte seq_bio [7] =  { 5, 1, 2, 3, 5, 10};
byte seq_qui [9] =  { 7, 1, 2, 3, 4,  5,  7, 10};

#if LCDType == 16 
  byte seq_uso [11] = {9, 1, 2, 3, 4, 5, 6, 7, 8, 9};
#elif LCDType == 20
  byte seq_uso [12] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
#endif


String Seq_CARD [15];               // RECEBE A SEQUENCIA DOS NOMES DOS CARTOES PASSADOS -----------------------> VAI PODER RETIRAR NO FIM DA PROGRAMAÇÃO 
String Seq_PLAY [15] = {"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"};               // RECEBE A SEQUENCIA DAS FUNÇOES A SEREM EXECUTADAS
//byte PLAY_atualiza [ ] = { };
String vetor_card [25] = {"0", "*1ON*", "*1OF*", "*2AG*", "*2T1*", "*2T3*", "*2T5*", "*3BZ*", "*3LD*", "*4MA*", "*4ME*", "*4IG*", "*5BU*", "*5TH*", "*5TM*", "*5CE*", "*5FC*", "*5PD*", "*5US*", "*5EH*", "*5DS*", "*5SF*", "*5SU*", "*5PH*"};
byte env = 0;
String dataString = "";


byte materia = 0;
boolean dados_out [12] = {0,0,0,0,0,0,0,0,0,0,0};
boolean falha_rfid = 0;
unsigned int tamanho_total = 0;
unsigned int tamanho_total2 = 0;
unsigned int tamanho_total3 = 0;
unsigned int tamanho = 0;
boolean flag_apaga = 0;

// FLAGS BUTTONS
boolean Flag_Button_dn    = 0;
boolean Flag_Button_up    = 0;
boolean Flag_Button_enter = 0;
boolean Flag_Button_voltar = 0;
//boolean Flag_read        = false;

// FLAG SENSOR DIGITAL
boolean Flag_balanca = 0;
boolean Flag_bussola = 0;

// outputs
const byte BUZ           = 27;       // PROJETO CITTIUS

long DEBOUNCING    = 250000;     // TEMPO DE VARREDURA DA INTERRUPÇÃO EM us

//UTILIZADO PARA CONTROLE DO MENU INICIAL
#if LCDType == 16 
  byte tela = 0;
  byte menu_1 = 1;
  byte menu_1min = 1;
  byte menu_1max = 5;
  
#elif LCDType == 20
  byte tela = 0;
  byte menu_1 = 1;
  byte menu_1min = 1;
  byte menu_1max = 8;
  
#endif

//UTILIZADO PARA CONTROLE DO MENU "LER SENSORES"
byte menu_2 = 1;
byte menu_2min = 1;
byte menu_2max = 0;

//UTILIZADO PARA CONTROLE DO MENU "SETUP DOS DADOS"
#if LCDType == 16 
  byte menu_3 = 1;
  byte menu_3min = 1;
  byte menu_3max = 0;
  boolean Flag_menu3ok = 0;
  
#elif LCDType == 20
  byte menu_3 = 1;
  byte menu_3min = 1;
  byte menu_3max = 0;
  boolean Flag_menu3ok = 0;
  
#endif

//UTILIZADO PARA CONTROLE DO MENU "SENSORES ESPECIAIS"
#if LCDType == 16 
  byte menu_4 = 1;
  byte menu_4min = 1;
  byte menu_4max = 2;
  boolean Flag_menu4ok = 0;
  
#elif LCDType == 20
  byte menu_4 = 1;
  byte menu_4min = 1;
  byte menu_4max = 3;
  boolean Flag_menu4ok = 0;
  
#endif

//UTILIZADO PARA CONTROLE DO MENU "SETUP DOS SENSORES"
#if LCDType == 16 
  byte menu_5 = 1;
  byte menu_5min = 1;
  byte menu_5max = 3;
  boolean Flag_menu5ok = 0;
  
#elif LCDType == 20
  byte menu_5 = 1;
  byte menu_5min = 1;
  byte menu_5max = 4;
  boolean Flag_menu5ok = 0;
  
#endif

//ATUALIZA VALORES
unsigned long tempoold = 0;
const long intervalo = 1000;
boolean Flag_menu2ok = 0;

//EEPROM DA BUSSOLA
byte EPM_X [7] = {0, 0, 1, 1, 2, 2};
byte EPM_Y [7] = {0, 1, 0, 1, 0, 1};
byte xy = 0;
int xy_load = 0;

//ENVIA DADOS
unsigned long tempoold2 = 0;
const long intervalo2 = 300;
unsigned long tempoold3 = 0;
const long intervalo3 = 100;
byte contagem = 0;

unsigned long atual_pf = 0;
unsigned long atual_dht = 0;
unsigned long atual_busso = 0;

//VARIAVEIS PARA CONTROLE DE PULSOS RPM
long RPM = 0;
byte pulso_volta = 1;
unsigned long tempo_rpmold = 0;
const long inter_rpm = 1000;
boolean Flag_rpm = 0;

//SELEÇÃO DO SENSOR DE CORRENTE
float cal_30A = 34;
float cal_100A_v1 = 6.5;
float cal_100A_v2 = 7.9;
byte sensorAC = 0;

//VARIAVEIS PARA CALIBRAÇAO PH
int adc_4710 [3] = {0,0,0};
float graf4_7 [2] = {0.001, 0.001};   //graf4_7 [2] = {A; B}; 
float graf7_10 [2] = {0.001, 0.001};  //graf7_10 [2] = {A; B};
float ponto4 = 4.00;
float ponto7 = 7.00;
float ponto10 = 10.00;
boolean flag = 0;
boolean flag_pos = 0;
boolean PH_padrao = 0;

//VARIAVEIS PARA LEITURA DE CARTÃO
unsigned long Tarefa = 0;           // RECEBE MILLIS DO CARD
const short T_CARD        = 1000;      // TEMPO DE VARREDURA DA LEITURA DO CARTÃO
boolean Flag_card        = 0;
boolean Flag_play        = 0;
boolean Flag_read        = false;
boolean Flag_edit        = 0;
boolean Flag_edit_card   = 0;
boolean Flag_print_ref   = 0; 
byte N_CARD = 0;                    // QUANTIDADE DE PASSAGEM DE CARTÃO
byte N_PLAY = 0;                    // CONTAGEM DA SEQUENCIA DO PLAY
byte pos_card = 0;
boolean flag_val_ref = 0;
float val_ref_sensor = 0.0;
float val_ref_old = 0.0;
float val_ref_senmax = 0.0;
float val_ref_senmin = 0.0;
float val_sensor_play = 0;
boolean flag_comparacao = 0;
boolean flagSetupDC = false;
byte flag_on_off = 0;
//boolean flag_off = 0;
String convert_val = "";

//VARIÁVEIS DOS SENSORES
String TENSAO = "0.00";
String CORRENTE = "0.00";
String TEMPERATURA = "0.00";
String PH = "0.00";
String SOLO = "0";
String ULTRA = "0.00";
String FORCA = "0.00";
String BUSSOLA_ang = "0";
String BUSSOLA_pos = "0";
String PRES_DIF = "0.00";
String HALL = "0";
String DHTH = "0";
String DHTT = "0.00";
String BPM2 = "0";
String SEN_SOM = "0";

unsigned int pingSpeed = 50; // How frequently are we going to send out a ping (in milliseconds). 50ms would be 20 times a second.
unsigned long pingTimer;     // Holds the next ping time.
unsigned distanciaSensor;