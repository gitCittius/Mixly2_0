
float tch = 0;
boolean flag_tch = 0;
boolean inicia_tch = 0;
int RPM_tch = 0;
int ad_tch = 0;
unsigned long tempo1_tch = 0;
unsigned long tempo2_tch = 0;

unsigned long tempo_tch = 0;
const long intervalo_tch = 1000;



void tach(){



  ad_tch = analogRead(68);

  if((ad_tch < 300)&&(flag_tch == 0)){
    //tch += 1;
    flag_tch = 1;
    inicia_tch = !inicia_tch;

    if(inicia_tch == 1){
      tempo1_tch = micros();
    }else{
      tempo2_tch = micros();
      tch = (tempo2_tch - tempo1_tch) / 1000.000;
      RPM_tch = (1000.000/tch) * 60.00;
    }
  }else if((ad_tch >600)&&(flag_tch == 1)){
    flag_tch = 0;
  }

//------------------------------------------------------------------------------------------ 
  if( (millis() - tempo_tch >= intervalo_tch) ){
       //Serial.print("rpm = ");
       //Serial.println(RPM_tch);

      #if LCDType == 16 
        lcd->setCursor(0,1);
        lcd->print(String (RPM_tch) + " RPM   ");
      #elif LCDType == 20
        lcd->setCursor(3,2);
        lcd->print(String (RPM_tch) + " RPM   ");
      #endif
       
       
    tempo_tch = millis();
    }
//------------------------------------------------------------------------------------------ 



  }
