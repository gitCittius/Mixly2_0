#define N_ 41
#define I4 12


char txt[50];
double semFiltro[N_], comFiltro[N_], pico1, pico2;
int idx, idxAnt,controleIdx = 0;
uint32_t anterior, atual, tempo = 0;
uint32_t tempIni = 0;
bool  pico = 0;
double maior = 0;
bool subida = 0;
uint8_t BPM = 0;
uint16_t resetar = 0;
boolean flag_BPM = 0;
int inclinacao = 0;
uint32_t indice = 0;

/*
Filter specifications:
Filter type          : Lowpass
Sample Rate          : 500 Hz
Passband gain        : 1 dB
Stopband gain        : -42 dB
Low band edge        : 7 Hz
High band edge       : 27 Hz

Filter design results:
Filter order         : 40
Passband weight      : 0,086596
*/

static const double h[N_] =
{
  -0.0036812107021623355,
    7.983176687685282E-4,
    0.0015315752997004711,
    0.0027645423285466157,
    0.00451529828171688,
    0.006786931328546203,
    0.009591652839413503,
    0.01289694778075608,
    0.01667209775826196,
    0.02086046138615463,
    0.025358639748616626,
    0.030060840755923524,
    0.0348372871789272,
    0.03954665865477868,
    0.04403802458268503,
    0.04815434930327632,
    0.051753457817100064,
    0.0547036812430348,
    0.05689423794961615,
    0.05824145110597307,
    0.05869596496335026,
    0.05824145110597307,
    0.05689423794961615,
    0.0547036812430348,
    0.051753457817100064,
    0.04815434930327632,
    0.04403802458268503,
    0.03954665865477868,
    0.0348372871789272,
    0.030060840755923524,
    0.025358639748616626,
    0.02086046138615463,
    0.01667209775826196,
    0.01289694778075608,
    0.009591652839413503,
    0.006786931328546203,
    0.00451529828171688,
    0.0027645423285466157,
    0.0015315752997004711,
    7.983176687685282E-4,
    -0.0036812107021623355,
};


uint8_t calculaBPM(uint32_t atu, uint32_t ant){

  return (uint8_t)(60000/(atu - ant));

}


double filter(const double x_in)
{
    static int n = 0;
    static double x[N_];
    int i;
    double y = 0.0;

    // Store the current input, overwriting the oldest input
    x[n] = x_in;

    // Multiply the filter coefficients by the previous inputs and sum
    for (i=0; i<N_; i++)
    {
        y += h[i] * x[((N_ - i) + n) % N_];
    }

    // Increment the input buffer index to the next location
    n = (n + 1) % N_;

    return y;
}

bool calibracao (){

  tempIni = micros();
  semFiltro[idx] = analogRead(I4);
  comFiltro[idx] = filter(semFiltro[idx]);
  idx = (idx + 1) % N_;
  double picos[10] = {0,0,0,0,0,0,0,0,0,0};
  uint32_t tempos[10] = {0,0,0,0,0,0,0,0,0,0};
  uint8_t p = 0;
  double menor = 0xFFFFFF;
  uint8_t sequenciaPicos, sequenciaTempos = 0;
  maior = 0;
  resetar = 0;
  subida = 0;
  inclinacao = 0;
  while((micros() - tempIni) < 2000){}

  while(p < 10){
    tempIni = micros();
    semFiltro[idx] = analogRead(I4);
    comFiltro[idx] = filter(semFiltro[idx]);
    if(idx == 0){
      idxAnt = N_ - 1;
    }else{
      idxAnt = idx - 1;
    }


    if(comFiltro[idx] < comFiltro[idxAnt] && subida == 1 ){
      picos[p] = comFiltro[idxAnt];
      tempos[p] = millis();
      //Serial.println(tempos[p]);
      p++;
      inclinacao = 0;
      subida = 0;
    }
    else if(comFiltro[idx] > comFiltro[idxAnt] && inclinacao > 9){
      subida = 1;
    }
    
    else if(comFiltro[idx] > comFiltro[idxAnt] && subida == 0 && (comFiltro[idx] - comFiltro[idxAnt]) > 0.10 && (comFiltro[idx] - comFiltro[idxAnt]) < 0.95){
      if(idx - controleIdx > 1){
        inclinacao = 0;
        controleIdx = idx;
      }
      else{
        inclinacao ++;
        controleIdx = idx;
      }
    }

    idx = (idx + 1) % N_;

    while((micros() - tempIni) < 2000){}


  }


  tempIni = micros();
  semFiltro[idx] = analogRead(I4);
  comFiltro[idx] = filter(semFiltro[idx]);
  idx = (idx + 1) % N_;

  if(picos[0] > picos[1]){
    p = 1;
    for(int l = 0; l < 9 ; l = l + 2){
      if(picos[l] > picos[l+1]){
        sequenciaPicos++;
      }
    }
  }
  else{
    p = 0;
    for(int l = 0; l < 9 ; l = l + 2){
      if(picos[l] < picos[l+1]){
        sequenciaPicos ++;
      }
    }
  }

  if(sequenciaPicos < 4){
    while((micros() - tempIni) < 2000){}
    return false;
  }


  if(p==1){
    p = 0;
    while(p < 7){
      if(tempos[p+2] - tempos[p] > 300 && tempos[p+2] - tempos[p] < 1500){
        sequenciaTempos ++;
      }
      p = p + 2;
    }
    p = 1;
  }
  else{
    p = 1;
    while(p < 8){

      if(tempos[p+2] - tempos[p] > 300 && tempos[p+2] - tempos[p] < 1500){
        sequenciaTempos ++;
      }
      p = p + 2;
    }
    p = 0;
  }

  if(sequenciaTempos < 4){
    while((micros() - tempIni) < 2000){}
    return false;
  }

  while (p < 10){
    if(picos[p] > maior){
      maior = picos[p];
    }
    if(picos[p] < menor){
      menor = picos[p];
    }
    p = p + 2;
  }

  

  if((maior - menor) < 3 ){
    while((micros() - tempIni) < 2000){}
    return true;
  }
  else{
    while((micros() - tempIni) < 2000){}
    return false;
  }
Serial.println("cal fim");
}

void setup_bat() {
  // put your setup code here, to run once:
//  Serial.begin(115200);
  pinMode(49, INPUT);
  pinMode(2, OUTPUT);

//  lcd->init();
  lcd->clear();        // LIMPA A TELA PARA NÃO DEIXAR RASTRO DE ESCRITA 
  lcd->backlight();
  
  lcd->setCursor(0,0);
  lcd->print("Sensor Cardiaco   I4");
  delay(3000);


  lcd->setCursor(0,2);
  lcd->print("      --- BPM       ");
  lcd->setCursor(0,3);
  lcd->print("   CALIBRANDO...    ");  

  delay(3000);

  for(int i = 0; i <= N_ ; i++){
    tempIni = micros();
    semFiltro[idx] = analogRead(I4);

    comFiltro[idx] = filter(semFiltro[idx]);

    idx = (idx + 1) % N_;

    while((micros() - tempIni) < 2000){}


  }


  while(calibracao() == false){}
  tempIni = micros();
  semFiltro[idx] = analogRead(I4);
  comFiltro[idx] = filter(semFiltro[idx]);
  idx = (idx + 1) % N_;

  while((micros() - tempIni) < 2000){}

  flag_BPM = 1;
  
  lcd->setCursor(0,3);
  lcd->print("                    "); 
}

void loop_bat() {

  tempIni = micros();

  semFiltro[idx] = analogRead(I4);
  
  comFiltro[idx] = filter(semFiltro[idx]);

  if(idx == 0){
    idxAnt = N_ - 1;
  }else{
    idxAnt = idx - 1;
  }


  
      if(comFiltro[idx] < comFiltro[idxAnt] && subida == 1 && comFiltro[idx] > maior){

          atual = millis();

          resetar = 0;
          if(BPM == 0){

            BPM = calculaBPM(atual, anterior);
          }
          else{

            BPM = calculaBPM(atual, anterior);

            lcd->setCursor(6,1);
            sprintf(txt, "%03d BPM   ",BPM);
            lcd->print(txt);
 
          }
          anterior = atual;
          subida = 0;
          inclinacao = 0;
      }
      else if(comFiltro[idx] > comFiltro[idxAnt] && inclinacao > 9){
        resetar = 0;
        subida = 1;
      }
      else if(comFiltro[idx] > comFiltro[idxAnt] && subida == 0 && (comFiltro[idx] - comFiltro[idxAnt]) > 0.10){
        
        if(idx - controleIdx > 1){
          inclinacao = 0;
          controleIdx = idx;
        }
        else{
          //resetar = 0;
          inclinacao ++;
          controleIdx = idx;
        }
      }
      else {
        resetar ++;
      }
    
  idx = (idx + 1) % N_;
  
  
  
  if (resetar > 1000){
    
    lcd->setCursor(6,2);
    lcd->print("--- BPM   ");
  }
  
  while((micros() - tempIni) < 2000){}
  
  if (resetar > 1000){
    
    while(calibracao() == false){}
  }

}
