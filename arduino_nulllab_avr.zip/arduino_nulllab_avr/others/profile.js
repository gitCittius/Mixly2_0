profile['Nulllab Mango Uno'] =
profile['Nulllab Nano/Maker-Nano'] =
profile['Nulllab Orion'] =
profile['DIY Boards'] =
profile['arduino_standard']